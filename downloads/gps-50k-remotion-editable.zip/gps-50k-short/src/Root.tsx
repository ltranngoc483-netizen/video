import React from 'react';import {Composition,Still,AbsoluteFill} from 'remotion';import {Video} from './Video';import {TrackerHook} from './TrackerHook';import {Teardown} from './Teardown';import {LbsNetwork} from './LbsNetwork';import {GpsFunnel} from './GpsFunnel';import {Photo} from './Visuals';
const Asset=({file}:{file:string})=><AbsoluteFill><Photo file={file}/></AbsoluteFill>;
export const Root=()=> <>
<Composition id="GPS50K" component={Video} width={1080} height={1920} fps={30} durationInFrames={900}/>
<Composition id="TrackerHook" component={TrackerHook} width={1080} height={1920} fps={30} durationInFrames={150}/>
<Composition id="Teardown" component={Teardown} width={1080} height={1920} fps={30} durationInFrames={300}/>
<Composition id="LbsNetwork" component={LbsNetwork} width={1080} height={1920} fps={30} durationInFrames={300}/>
<Composition id="GpsFunnel" component={GpsFunnel} width={1080} height={1920} fps={30} durationInFrames={150}/>
<Still id="Scene01Asset" component={Asset} width={1080} height={1920} defaultProps={{file:'scooter'}}/>
<Still id="Scene02Asset" component={Asset} width={1080} height={1920} defaultProps={{file:'board'}}/>
<Still id="Scene03Asset" component={Asset} width={1080} height={1920} defaultProps={{file:'city'}}/>
<Still id="Scene04Asset" component={GpsFunnel} width={1080} height={1920} defaultProps={{still:true}}/>
<Still id="Thumbnail" component={Asset} width={1080} height={1920} defaultProps={{file:'thumbnail'}}/>
</>;
