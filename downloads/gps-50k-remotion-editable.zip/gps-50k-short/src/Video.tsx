import React from 'react';import {AbsoluteFill,staticFile,useVideoConfig} from 'remotion';import {Audio} from '@remotion/media';import {TransitionSeries} from '@remotion/transitions';import {TrackerHook} from './TrackerHook';import {Teardown} from './Teardown';import {LbsNetwork} from './LbsNetwork';import {GpsFunnel} from './GpsFunnel';import {PaperTransition} from './Visuals';
export const Video=()=>{const {fps}=useVideoConfig();return <AbsoluteFill><TransitionSeries>
<TransitionSeries.Sequence name="01 Hộp GPS 50K" durationInFrames={5*fps} premountFor={fps}><TrackerHook/></TransitionSeries.Sequence>
<TransitionSeries.Overlay durationInFrames={8} premountFor={fps}><PaperTransition/></TransitionSeries.Overlay>
<TransitionSeries.Sequence name="02 Mổ xẻ bo mạch" durationInFrames={10*fps} premountFor={fps}><Teardown/></TransitionSeries.Sequence>
<TransitionSeries.Overlay durationInFrames={8} premountFor={fps}><PaperTransition/></TransitionSeries.Overlay>
<TransitionSeries.Sequence name="03 LBS và thiết bị chỉ 2G" durationInFrames={10*fps} premountFor={fps}><LbsNetwork/></TransitionSeries.Sequence>
<TransitionSeries.Overlay durationInFrames={8} premountFor={fps}><PaperTransition/></TransitionSeries.Overlay>
<TransitionSeries.Sequence name="04 Video liên quan" durationInFrames={5*fps} premountFor={fps}><GpsFunnel/></TransitionSeries.Sequence>
</TransitionSeries><Audio name="Nhạc synth và SFX, chưa có lời đọc" src={staticFile('sound-design.wav')} premountFor={fps}/></AbsoluteFill>};
