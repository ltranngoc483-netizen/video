from pathlib import Path
import json,subprocess
import numpy as np
import soundfile as sf
r=Path(__file__).resolve().parents[1];sr=48000;n=30*sr;rng=np.random.default_rng(7050);music=np.zeros(n);sfx=np.zeros(n)
def add(at,x):
 i=round(at*sr);k=min(len(x),n-i)
 if k>0:sfx[i:i+k]+=x[:k]
def click(at,freq=1300,amp=.25,d=.10):
 t=np.arange(round(d*sr))/sr;add(at,(.35*rng.normal(size=len(t))+.65*np.sin(2*np.pi*freq*t))*np.exp(-t*65)*amp)
def bass(at,amp=.35,d=.7):
 t=np.arange(round(d*sr))/sr;add(at,np.sin(2*np.pi*(62*t-14*t*t))*np.exp(-t*7)*amp)
def paper(at,d=.25,amp=.2):
 t=np.arange(round(d*sr))/sr;z=rng.normal(size=len(t));z-=np.convolve(z,np.ones(24)/24,mode='same');add(at,z*np.sin(np.pi*t/d)**2*np.exp(-t*7)*amp)
def beep(at,freq=500,d=.14,amp=.16):
 t=np.arange(round(d*sr))/sr;add(at,np.sin(2*np.pi*freq*t)*np.sin(np.pi*t/d)**2*amp)
# Quiet original dark-synth bed, leaving space for the user's later narration.
for beat in np.arange(0,29.5,.75):
 freq=[55,55,51.913,48.999][int(beat//6)%4];t=np.arange(round(.55*sr))/sr;i=round(beat*sr);k=min(len(t),n-i)
 music[i:i+k]+=.022*(np.sin(2*np.pi*freq*t[:k])+.25*np.sin(2*np.pi*freq*2*t[:k]))*np.exp(-t[:k]*5)
paper(.1,.3);click(.35);bass(.4,.4)
for at in [.6,1.35,3.3,4.1,15.2,16.1,17.1,18.1,19.1]:beep(at,850 if at<15 else 640,.10,.12)
for at in [1.8,3.2,5,7.2,9,10.6,11.7,15,17.5,20,22.5,25]:paper(max(0,at-.06),.20,.2);click(at,1500,.2)
paper(5.12,.48,.28)
for at in [6.0,6.3,6.6,9.4,10.9,11.3]:click(at,1800,.18,.07)
beep(22.2,460,.16,.2);beep(22.48,320,.20,.2);paper(22.5,.38,.4);bass(22.58,.5)
paper(25,.38,.3);bass(25,.45);paper(25.3,.2,.23);bass(26.1,.25,.38);bass(27.3,.25,.38);bass(29.3,.3,.7)
mix=music+sfx;sf.write(r/'out/sfx-raw.wav',mix,sr,subtype='FLOAT')
subprocess.run(['ffmpeg','-y','-v','error','-i',str(r/'out/sfx-raw.wav'),'-af','alimiter=limit=0.9:level=0:latency=1','-ar','48000',str(r/'public/sound-design.wav')],check=True)
caps=json.loads((r/'src/captions.json').read_text())
def tc(ms):
 ms=round(ms);return f'{ms//3600000:02}:{ms//60000%60:02}:{ms//1000%60:02},{ms%1000:03}'
(r/'out/gps-50k-vi-timing-draft.srt').write_text('\n\n'.join(f'{i+1}\n{tc(c["startMs"])} --> {tc(c["endMs"])}\n{c["text"]}' for i,c in enumerate(caps))+'\n')
print('30-second SFX/synth track and 15-cue provisional SRT ready; no narration')
