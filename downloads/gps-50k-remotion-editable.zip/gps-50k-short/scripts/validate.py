from pathlib import Path
import json,subprocess,zipfile
import numpy as np
import soundfile as sf
r=Path(__file__).resolve().parents[1];p=r/'out/gps-50k-30s-hinh-sfx.mp4'
d=json.loads(subprocess.check_output(['ffprobe','-v','error','-show_entries','format=duration,size:stream=codec_type,codec_name,width,height,r_frame_rate,nb_frames','-of','json',str(p)],text=True))
v=next(s for s in d['streams'] if s['codec_type']=='video');a=next(s for s in d['streams'] if s['codec_type']=='audio')
assert (v['width'],v['height'],v['r_frame_rate'],int(v['nb_frames']))==(1080,1920,'30/1',900)
assert v['codec_name']=='h264' and a['codec_name']=='aac';assert abs(float(d['format']['duration'])-30)<.05
subprocess.run(['ffmpeg','-v','error','-threads','2','-i',str(p),'-f','null','-'],check=True)
subprocess.run(['ffmpeg','-v','error','-y','-i',str(p),'-vn','-c:a','pcm_f32le',str(r/'out/decoded.wav')],check=True)
x,sr=sf.read(r/'out/decoded.wav',dtype='float32');peak=float(np.max(abs(x)));assert peak<1
for start,end in [(0,5),(5,15),(15,25),(25,30)]:assert float(np.sqrt(np.mean(x[int(start*sr):int(end*sr)]**2)))>.005
caps=json.loads((r/'src/captions.json').read_text());assert len(caps)==15;assert all(0<=c['startMs']<c['endMs']<=30000 for c in caps)
assert not list((r/'public').glob('*voice*'));assert not list((r/'public').glob('*narration*'))
(r/'out/validation.json').write_text(json.dumps(dict(metadata=d,audioPeak=peak,narration='NONE — user chose picture/SFX only',captionStatus='15 provisional editing cues, external SRT, not burned in',cta=[25,30]),indent=2))
print('PASS: 30 seconds, 900 frames, 1080x1920 H264/AAC, full decode; SFX in four sections; no narration; peak',round(peak,3))
