from pathlib import Path
import subprocess
r=Path(__file__).resolve().parents[1]
subprocess.run(['ffmpeg','-y','-v','warning','-i',str(r/'out/gps-50k-native.mp4'),'-i',str(r/'public/sound-design.wav'),'-map','0:v:0','-map','1:a:0','-c:v','copy','-c:a','aac','-b:a','192k','-t','30','-movflags','+faststart',str(r/'out/gps-50k-30s-hinh-sfx.mp4')],check=True)
print('30-second picture/SFX MP4 ready — no narration')
