# TECH UNMASKED — GPS mini 50K

## Style Prompt
Photographed handcrafted tactile cardboard dioramas. Torn corrugated cream edges, folded navy objects, real beige masking tape, metal pins, hard directional cast shadows, tiny cyan light ribbons. Same physical realism as Camera V3 and QR; no flat SVG scene substitutes. Camera changes every 1.5–2.5 seconds, shell separation, independent SIM/chip motion, local device scan, moving marker/error range and a breaking 2G symbol. Four independently editable scenes, 30-second timeline, CTA25–30. Video is picture/SFX only by user choice.

## Colors
#0A192F navy; #00F0FF cyan data; #F2ECDD cream paper; #D34D49 red illustrative position marker.

## Typography
Display/DejaVu Sans Bold 60–100px headings; Body/DejaVu Sans 28–34px labels; Display 48px timed script text. Essential content x80–900, y120–1530. Localized dark scrims preserve type contrast.

## What NOT to Do
No flat clipart, no generic slide boxes, no pasted thin cartoon icons as hero subjects. Do not accuse all inexpensive trackers. No claim that these images show an actual tested unit. Price and 3km are examples. No unverified assertion of an already completed national 2G shutdown or universal outage. No fake tracking of a person. No narration until user supplies the intended male recording. SRT is provisional editing timing, not an audio transcription.
