from pathlib import Path
import json,subprocess
import numpy as np
import soundfile as sf
r=Path(__file__).resolve().parents[1];p=r/'out/bell-witch-30s.mp4'
d=json.loads(subprocess.check_output(['ffprobe','-v','error','-show_entries','format=duration,size:stream=codec_name,codec_type,width,height,r_frame_rate,nb_frames','-of','json',str(p)]))
v=next(s for s in d['streams'] if s['codec_type']=='video');a=next(s for s in d['streams'] if s['codec_type']=='audio')
assert (v['width'],v['height'],v['r_frame_rate'],v['nb_frames'])==(1080,1920,'30/1','900')
assert v['codec_name']=='h264' and a['codec_name']=='aac';assert abs(float(d['format']['duration'])-30)<.05
subprocess.run(['ffmpeg','-v','error','-threads','2','-i',str(p),'-f','null','-'],check=True)
subprocess.run(['ffmpeg','-y','-v','error','-i',str(p),'-vn','-ar','16000','-ac','1',str(r/'out/decoded.wav')],check=True)
x,sr=sf.read(r/'out/decoded.wav');peak=float(np.max(abs(x)));assert .15<peak<1
caps=json.loads((r/'src/captions.json').read_text());assert len(caps)==11 and caps[0]['startMs']==100 and caps[-1]['endMs']==29950
for i,c in enumerate(caps):
 assert 0<=c['startMs']<c['endMs']<=30000
 if i:assert c['startMs']>=caps[i-1]['endMs']
 assert float(np.sqrt(np.mean(x[int(c['startMs']/1000*sr):int(c['endMs']/1000*sr)]**2)))>.01
for n in ['01_missing_verdict','02_invisible_siege','03_fatal_vial','04_related_video']:
 im=json.loads(subprocess.check_output(['ffprobe','-v','error','-show_entries','stream=width,height','-of','json',str(r/'out'/('bell_witch_'+n+'.png'))]))['streams'][0]
 assert (im['width'],im['height'])==(1080,1920)
(r/'out/validation.json').write_text(json.dumps(dict(metadata=d,audioPeak=peak,captions=11,sceneFrames=[0,150,450,750,900],voice='Kokoro am_michael local US male draft, not Marcus'),indent=2))
print('PASS:30s,900frames,1080x1920 H264/AAC,full decode,11 audible caption windows,four1080x1920PNGs;peak',round(peak,3))
