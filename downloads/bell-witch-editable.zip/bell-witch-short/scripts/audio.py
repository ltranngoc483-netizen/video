from pathlib import Path
import json,subprocess
import numpy as np
import soundfile as sf
r=Path(__file__).resolve().parents[1];sr=48000;n=30*sr;rng=np.random.default_rng(1820);vo=np.zeros(n);sfx=np.zeros(n)
for s in json.loads((r/'scripts/narration.json').read_text()):
 x,rate=sf.read(r/'public'/f'{s["id"]}.wav');assert rate==sr;i=round((s['start']+.1)*sr);k=min(len(x),n-i);vo[i:i+k]+=x[:k]
def add(at,x):
 i=round(at*sr);k=min(len(x),n-i)
 if k>0:sfx[i:i+k]+=x[:k]
def thud(at,amp=.35,d=.7):
 t=np.arange(round(d*sr))/sr;add(at,amp*np.sin(2*np.pi*(54*t-10*t*t))*np.exp(-t*6))
def click(at,amp=.2,freq=1100):
 t=np.arange(round(.085*sr))/sr;add(at,amp*(.55*rng.normal(size=len(t))+.45*np.sin(2*np.pi*freq*t))*np.exp(-t*70))
def paper(at,d=.25,amp=.18):
 t=np.arange(round(d*sr))/sr;x=rng.normal(size=len(t));x-=np.convolve(x,np.ones(24)/24,mode='same');add(at,amp*x*np.sin(np.pi*t/d)**2*np.exp(-t*5))
def knock(at,amp=.2):
 t=np.arange(round(.25*sr))/sr;add(at,amp*(np.sin(2*np.pi*185*t)+.3*np.sin(2*np.pi*390*t))*np.exp(-t*24))
t=np.arange(n)/sr;bed=(.013*np.sin(2*np.pi*43*t)+.008*np.sin(2*np.pi*57.8*t)+.003*np.sin(2*np.pi*120*t))*(.65+.35*np.sin(2*np.pi*.23*t)**2);bed*=np.minimum(1,t/.6)*np.minimum(1,(30-t)/.65);sfx+=bed
knock(.12,.45);thud(.15,.35);paper(.8,.4,.11);paper(1.4,.22,.13);paper(2.731,.25,.25);thud(2.77,.25)
for at in [4.95,5.2,7,9.135,11,12.455,14.95,17.445,19.992,22.079,24.95]:paper(at,.23,.18)
for at in [6.8,7.04,7.6,10.5,10.8,11.2]:knock(at,.18)
paper(9.14,.5,.24);thud(9.2,.2)
for at in [15.3,16.3,17.3,18.3,19.3,20.3,21.3]:thud(at,.12,.22)
tone=np.arange(round(.65*sr))/sr;add(17.65,.09*np.sin(2*np.pi*(1300*tone+200*tone*tone))*np.exp(-tone*7))
# Abstract airy noise, without intelligible invented historical dialogue.
z=rng.normal(size=round(1.1*sr));z=np.convolve(z,np.ones(10)/10,mode='same');add(20.0,z*np.sin(np.linspace(0,np.pi,len(z)))**2*.055)
for at in [25.12,25.3,25.52,25.8]:knock(at,.12)
paper(25,.4,.23);thud(25,.35);paper(25.3,.3,.18);thud(26.35,.18,.45);thud(28.15,.18,.5);thud(29.55,.15,.45)
sfx*=np.minimum(1,(30-t)/.5)
sf.write(r/'public/narration.wav',vo,sr);sf.write(r/'public/sound-design.wav',sfx,sr)
sf.write(r/'out/mix-raw.wav',vo+.24*sfx,sr,subtype='FLOAT')
subprocess.run(['ffmpeg','-y','-v','error','-i',str(r/'out/mix-raw.wav'),'-af','alimiter=limit=0.95:level=0:latency=1','-ar','48000',str(r/'out/final-audio.wav')],check=True)
caps=json.loads((r/'src/captions.json').read_text())
def tc(ms):return f'{ms//3600000:02}:{ms//60000%60:02}:{ms//1000%60:02},{ms%1000:03}'
(r/'out/bell-witch-en.srt').write_text('\n\n'.join(f'{i+1}\n{tc(c["startMs"])} --> {tc(c["endMs"])}\n{c["text"]}' for i,c in enumerate(caps))+'\n')
print('30s narration + original SFX/ambient bed;11 phrase-aligned cues')
