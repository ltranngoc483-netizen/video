import React from 'react';import {useCurrentFrame,useVideoConfig} from 'remotion';import {Art,Base,Title,Tag,Fine,Wave,stepped,mix,C} from './Visuals';import {Captions} from './Captions';
export const FatalVial=()=>{const f=useCurrentFrame();const {fps}=useVideoConfig();const t=stepped(f,fps);const shot=t<2.345?0:t<4.992?1:t<7.079?2:3;return <Base chapter="03 / THE FATAL VIAL STORY">
<Art file="vial" style={{scale:shot===0?1.16:shot===1?1.26+(t-2.345)*.02:shot===2?1.32:1.04,translate:shot===0?'-100px 40px':shot===1?'130px -100px':shot===2?'160px 190px':'0 0'}}/>
<Title>{shot===0?'JOHN BELL · 1820':shot===3?'MISSING PROOF':'THE STRANGE VIAL'}</Title>
<Tag top={1395} at={.2}>{['DEATH ≠ PROOF OF A GHOST','VIAL STORY: LEGEND','AN ALLEGED CONFESSION','NO VERIFIED AUTOPSY'][shot]}</Tag>
<div style={{position:'absolute',left:620,top:1030,width:230,padding:'20px 24px',background:C.cream,color:C.navy,fontFamily:'Mono',fontSize:25,rotate:`${-8+Math.sin(t*2)*3}deg`,translate:`0 ${Math.sin(t*2.7)*15}px`,opacity:mix(t,2.4,2.7,0,1),boxShadow:'8px 12px 16px #0007'}}>UNVERIFIED<br/>CLAIM</div>
<Wave top={1225} amp={.2} width={560} at={4.992}/><Fine top={1560}>Poisoning and the unseen confession are claims in the legend.</Fine><Captions start={15}/>
</Base>};
