import React from 'react';import {CanvasImage,staticFile,useCurrentFrame,useVideoConfig} from 'remotion';import {Art,Base,Title,Tag,Wave,stepped,C} from './Visuals';import {Captions} from './Captions';
export const InvisibleSiege=()=>{const f=useCurrentFrame();const {fps}=useVideoConfig();const t=stepped(f,fps);const shot=t<2?0:t<4.135?1:t<6?2:t<7.455?3:4;const shake=shot===1?Math.sin(t*44)*3:0;return <Base chapter="02 / THE FAMILY LEGEND">
<div style={{position:'absolute',inset:0,scale:shot===0?1+t*.02:shot===1?1.2:shot===2?1.28:shot===3?1.24:1.05+(t-7.455)*.01,translate:`${shake+(shot===2?-90:shot===3?-120:0)}px ${shake+(shot===2?-50:0)}px`}}><Art file="siege-clean"/><CanvasImage src={staticFile('blanket.png')} style={{position:'absolute',left:410,top:885,width:550,height:330,objectFit:'contain',translate:`0 ${-25+Math.sin(t*3.2)*28}px`,rotate:`${Math.sin(t*2.8)*6}deg`,filter:'drop-shadow(9px 22px 15px #0008)'}}/></div>
<Title>AN INVISIBLE<br/>SIEGE?</Title><Tag top={1400} at={.3}>{['1817 · TENNESSEE','INVISIBLE BLOWS?','MOVING BEDSHEETS','VOICES IN THE WALLS','THE STORY BECAME LEGEND'][shot]}</Tag>
<Wave top={1205} amp={.4} width={740} at={2}/>
<div style={{position:'absolute',left:615,top:730,width:100,height:210,borderRight:`${shot===3?7:3}px solid ${C.cyan}`,opacity:.3+.35*Math.sin(t*7)**2,rotate:'-15deg'}}/>
<Captions start={5}/>
</Base>};
