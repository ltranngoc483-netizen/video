import React from 'react';import {Composition,Still,Freeze} from 'remotion';import {ImageExport} from './Captions';import {Video} from './Video';import {MissingVerdict} from './MissingVerdict';import {InvisibleSiege} from './InvisibleSiege';import {FatalVial} from './FatalVial';import {JacksonFunnel} from './JacksonFunnel';
const Asset01=()=> <ImageExport.Provider value={true}><Freeze frame={106}><MissingVerdict/></Freeze></ImageExport.Provider>;
const Asset02=()=> <ImageExport.Provider value={true}><Freeze frame={155}><InvisibleSiege/></Freeze></ImageExport.Provider>;
const Asset03=()=> <ImageExport.Provider value={true}><Freeze frame={245}><FatalVial/></Freeze></ImageExport.Provider>;
const Asset04=()=> <ImageExport.Provider value={true}><Freeze frame={110}><JacksonFunnel/></Freeze></ImageExport.Provider>;
export const Root=()=> <>
<Composition id="BellWitch" component={Video} width={1080} height={1920} fps={30} durationInFrames={900}/>
<Composition id="MissingVerdict" component={MissingVerdict} width={1080} height={1920} fps={30} durationInFrames={150}/>
<Composition id="InvisibleSiege" component={InvisibleSiege} width={1080} height={1920} fps={30} durationInFrames={300}/>
<Composition id="FatalVial" component={FatalVial} width={1080} height={1920} fps={30} durationInFrames={300}/>
<Composition id="JacksonFunnel" component={JacksonFunnel} width={1080} height={1920} fps={30} durationInFrames={150}/>
<Still id="Scene01" component={Asset01} width={1080} height={1920}/>
<Still id="Scene02" component={Asset02} width={1080} height={1920}/>
<Still id="Scene03" component={Asset03} width={1080} height={1920}/>
<Still id="Scene04" component={Asset04} width={1080} height={1920}/>
</>;
