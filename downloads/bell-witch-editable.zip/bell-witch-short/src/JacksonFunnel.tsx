import React from 'react';import {useCurrentFrame,useVideoConfig} from 'remotion';import {Art,Base,Tag,stepped,mix,C} from './Visuals';import {Captions} from './Captions';
export const JacksonFunnel=()=>{const f=useCurrentFrame();const {fps}=useVideoConfig();const t=stepped(f,fps);const pulse=(t>1.2&&t<1.7)||(t>3&&t<3.5);return <Base chapter="04 / THE PRESIDENTIAL LEGEND">
<Art file="carriage" style={{scale:1.04,translate:`${-45+t*18}px 0`,opacity:mix(t,.3,.9,1,.29)}}/>
<div style={{position:'absolute',left:76,right:180,top:220,fontFamily:'Display',fontSize:77,lineHeight:1.1,color:C.cream,opacity:mix(t,.05,.35,0,1),translate:`0 ${mix(t,.05,.4,-25,0)}px`,textShadow:'0 7px 4px #000'}}>THE INVISIBLE<br/>WORLD</div>
<div style={{position:'absolute',left:80,right:180,top:450,fontFamily:'Body',fontSize:32,color:C.cream,opacity:mix(t,.2,.5,0,1)}}>Understand What You Never See</div>
<Tag top={590} at={.2}>JACKSON VISIT: UNVERIFIED</Tag>
<svg width="340" height="350" viewBox="0 0 340 350" style={{position:'absolute',left:300,top:1040,scale:mix(t,.15,.55,.7,1)*(pulse?1.08:1),opacity:mix(t,.1,.4,0,1),translate:`0 ${pulse?12:0}px`,filter:`drop-shadow(0 0 ${pulse?35:12}px ${C.cyan}88)`}}><path d="M112 10 L228 5 L229 197 L329 190 L172 337 L10 196 L114 200 Z" fill={C.cyan} stroke={C.cream} strokeWidth="3"/><path d="M127 22 L126 214 L45 215 M143 272 L174 301 L270 215" fill="none" stroke="#087986" strokeWidth="8"/></svg><Tag top={1430} at={.2}>RELATED VIDEO ↓</Tag><Captions start={25} cta/>
</Base>};
