import React from 'react';import {useCurrentFrame,useVideoConfig} from 'remotion';import {Art,Base,Title,Tag,Fine,stepped,mix,C} from './Visuals';import {Captions} from './Captions';
export const MissingVerdict=()=>{const f=useCurrentFrame();const {fps}=useVideoConfig();const t=stepped(f,fps);const shot=t<1.4?0:t<2.731?1:2;return <Base chapter="01 / THE MISSING VERDICT">
<Art file="verdict" style={{scale:shot===0?1+t*.025:shot===1?1.2+(t-1.4)*.04:1.1+(t-2.731)*.025,translate:shot===1?'-75px 110px':shot===2?'45px -10px':'0 0'}}/>
<Title>THE BELL WITCH</Title>
<Tag top={1300} at={2.731} large>NO VERIFIED<br/>VERDICT</Tag>
<svg width="1080" height="1920" style={{position:'absolute',inset:0,pointerEvents:'none'}}><ellipse cx="465" cy="1385" rx="410" ry="140" fill="none" stroke={C.cyan} strokeWidth="7" strokeDasharray="2000" strokeDashoffset={mix(t,2.8,3.5,2000,0)} transform="rotate(-3 465 1385)"/><path d="M235 1010 Q470 930 755 1090" stroke={C.cyan} strokeWidth="6" fill="none" strokeDasharray="700" strokeDashoffset={mix(t,1.4,2.5,700,0)} opacity=".8"/></svg>
<Fine top={1600}>A reconstructed folder, not an authentic court record.</Fine><Captions start={0}/>
</Base>};
