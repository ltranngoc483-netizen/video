# Bell Witch — The Invisible World
## Style Prompt
Photographed tactile paper horror: thick fibrous dark navy cardboard, torn aged cream paper, antique brass pins, yellowed masking tape, realistic macro depth and strong shadows. Cyan light suggests haunting, not scientific proof. Maintain material continuity across reconstructed legal folder, log cabin, bedside vial, and carriage illustration.
## Palette
#0A192F navy board, #00F0FF cyan light, #F2ECDD paper and type, #B45D48 wax, #846E50 brass.
## Typography
DejaVu Sans Bold Display for60–80px short headings, DejaVu Sans Body for44–50px captions, DejaVu Sans Mono for22–28px provenance labels. Keep right180px and bottom330px free of essential text. Full phrases must fit comfortably at mobile size.
## Motion
15pose/sec stop-motion transforms,13–15 macro shot beats. Consistent torn-page wipes, independent animated cyan marks, blanket motion, spectral shadow, floating note cards and arrow. CTA at25–30s.
## Do not
No fake historical document or official seal; reconstructed folio must say illustrated reconstruction. No authenticated verdict, confirmed paranormal murder, verified poisoning or confirmed Jackson visit. No graphic body, injuries or blood. No fake archival footage or invented primary-source citations.
