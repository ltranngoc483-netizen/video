from pathlib import Path
import os,json,re,subprocess
os.environ['OMP_NUM_THREADS']='3'
import sherpa_onnx,numpy as np,soundfile as sf
r=Path(__file__).resolve().parents[1];m=r.parent/'.models/vi/vits-piper-vi_VN-vais1000-medium'
config=sherpa_onnx.OfflineTtsConfig(model=sherpa_onnx.OfflineTtsModelConfig(vits=sherpa_onnx.OfflineTtsVitsModelConfig(model=str(m/'vi_VN-vais1000-medium.onnx'),tokens=str(m/'tokens.txt'),data_dir=str(m/'espeak-ng-data')),num_threads=3,provider='cpu'),max_num_sentences=1)
tts=sherpa_onnx.OfflineTts(config);story=json.loads((r/'src/story.json').read_text());caps=[]
for s in story:
 parts=re.split(r'(?<=[.!?])\s+',s['text']);chunks=[];lengths=[]
 for text in parts:
  spoken=text.replace('SCB','ét xi bi').replace('Sherwood','sơ út')
  a=tts.generate(spoken,sid=0,speed=1.0);x=np.asarray(a.samples);sr=a.sample_rate
  active=np.flatnonzero(abs(x)>.004)
  if len(active):x=x[max(0,active[0]-int(.035*sr)):min(len(x),active[-1]+int(.06*sr))]
  x=np.concatenate([x,np.zeros(int(.075*sr))]);chunks.append(x);lengths.append(len(x)/sr)
 raw=r/f'out/voice-{s["id"]:02}.wav';sf.write(raw,np.concatenate(chunks),sr)
 target=s['duration']-.22;total=sum(lengths);tempo=total/target
 subprocess.run(['ffmpeg','-y','-v','error','-i',str(raw),'-af',f'atempo={tempo:.9f},loudnorm=I=-18:TP=-3:LRA=7,apad,atrim=duration={target},afade=t=in:st=0:d=0.008,afade=t=out:st={target-.025}:d=0.025','-ar','48000',str(r/f'public/voice-{s["id"]:02}.wav')],check=True)
 cursor=s['start']+.10;local=[]
 for text,length in zip(parts,lengths):
  duration=length/tempo;words=text.split();groups=[words[i:i+11] for i in range(0,len(words),11)]
  group_cursor=cursor
  for group in groups:
   d=duration*len(group)/len(words);caps.append(dict(text=' '.join(group),startMs=round(group_cursor*1000),endMs=round((group_cursor+d)*1000),timestampMs=round(group_cursor*1000),confidence=None));group_cursor+=d
  local.append(dict(text=text,start=cursor-s['start'],end=cursor+duration-s['start']));cursor+=duration
 s['cues']=local;s['tempo']=tempo
 print('Voice',s['id'],'/40',round(total,2),'->',target,'tempo',round(tempo,3),flush=True)
(r/'src/story.json').write_text(json.dumps(story,ensure_ascii=False,indent=2));(r/'src/captions.json').write_text(json.dumps(caps,ensure_ascii=False,indent=2))
print('All Vietnamese narration and captions complete.',flush=True)
