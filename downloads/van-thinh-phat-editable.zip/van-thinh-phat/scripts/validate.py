from pathlib import Path
import json,subprocess,numpy as np,soundfile as sf
r=Path(__file__).resolve().parents[1];p=r/'out/van-thinh-phat-full-11min-1080p.mp4'
d=json.loads(subprocess.check_output(['ffprobe','-v','error','-show_entries','format=duration,size:stream=codec_type,codec_name,width,height,r_frame_rate,nb_frames','-of','json',str(p)],text=True));v=next(x for x in d['streams'] if x['codec_type']=='video');a=next(x for x in d['streams'] if x['codec_type']=='audio')
assert (v['width'],v['height'],v['r_frame_rate'],v['nb_frames'])==(1920,1080,'30/1','19800');assert v['codec_name']=='h264';assert a['codec_name']=='aac';assert abs(float(d['format']['duration'])-660)<.05
subprocess.run(['ffmpeg','-v','error','-threads','2','-i',str(p),'-f','null','-'],check=True)
subprocess.run(['ffmpeg','-v','error','-y','-i',str(p),'-vn','-c:a','pcm_f32le',str(r/'out/decoded.wav')],check=True)
x,sr=sf.read(r/'out/decoded.wav',dtype='float32');peak=float(np.max(abs(x)));assert peak<1,peak
# Ensure the four acts and each individual spoken scene have non-silent audio.
for s in json.loads((r/'src/story.json').read_text()):
 a=round((s['start']+.2)*sr);b=round((s['start']+s['duration']-.2)*sr);rms=float(np.sqrt(np.mean(x[a:b]**2)));assert rms>.01,(s['id'],rms)
(r/'out/validation.json').write_text(json.dumps(dict(metadata=d,audioPeak=peak,scenes=40,chapters=4,animationCadenceFps=15,deliveryFps=30,voice='Piper vi_VN-vais1000-medium; local, not ElevenLabs'),indent=2))
print('PASS: 660 seconds, 19800 frames, 1920x1080, H264/AAC, full decode clean, all 40 scene audio windows active; peak',round(peak,3))
