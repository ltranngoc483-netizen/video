from pathlib import Path
import subprocess
r=Path(__file__).resolve().parents[1]
subprocess.run(['ffmpeg','-y','-v','warning','-threads','2','-i',str(r/'out/van-thinh-phat-native-15fps.mp4'),'-i',str(r/'out/full-audio.wav'),'-map','0:v','-map','1:a','-vf','fps=30','-t','660','-c:v','libx264','-preset','veryfast','-crf','24','-threads','3','-c:a','aac','-b:a','128k','-movflags','+faststart',str(r/'out/van-thinh-phat-full-11min-1080p.mp4')],check=True)
print('Final 30 fps MP4 complete',flush=True)
