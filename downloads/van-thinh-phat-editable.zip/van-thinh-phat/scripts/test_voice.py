from pathlib import Path
import sherpa_onnx,soundfile as sf
m=Path('/workspace/video/.models/vi/vits-piper-vi_VN-vivos-x_low')
config=sherpa_onnx.OfflineTtsConfig(model=sherpa_onnx.OfflineTtsModelConfig(vits=sherpa_onnx.OfflineTtsVitsModelConfig(model=str(m/'vi_VN-vivos-x_low.onnx'),tokens=str(m/'tokens.txt'),data_dir=str(m/'espeak-ng-data')),num_threads=3,provider='cpu'),max_num_sentences=1)
tts=sherpa_onnx.OfflineTts(config)
a=tts.generate('Một triệu tỷ đồng. Nhưng tổng giải ngân không phải là tiền bị chiếm đoạt. Đây là ba con số khác nhau.',sid=0,speed=1.0)
sf.write('/workspace/video/van-thinh-phat/out/test-voice.wav',a.samples,a.sample_rate)
print('Voice sample:',len(a.samples)/a.sample_rate,'seconds',a.sample_rate)
