from pathlib import Path
import numpy as np,soundfile as sf,json
r=Path(__file__).resolve().parents[1];sr=48000;rng=np.random.default_rng(48591);mix=np.zeros(660*sr,dtype=np.float32)
def add(at,x,g=.1):
 i=round(at*sr);n=min(len(x),len(mix)-i)
 if i>=0 and n>0:mix[i:i+n]+=x[:n]*g
def tear(at,g=.07):
 t=np.arange(int(.23*sr))/sr;n=rng.normal(0,1,len(t));add(at,n*np.sin(np.pi*t/.23)**2*np.exp(-t*7),g)
def click(at,p=800,g=.08):
 t=np.arange(int(.08*sr))/sr;add(at,(np.sin(2*np.pi*p*t)+rng.normal(0,.15,len(t)))*np.exp(-t*75),g)
def bass(at,g=.18):
 t=np.arange(int(.65*sr))/sr;add(at,np.sin(2*np.pi*(49*t-8*t*t))*np.exp(-t*8),g)
story=json.loads((r/'src/story.json').read_text())
for s in story:
 start=s['start'];bass(start+.1,.19 if s['id'] in [1,11,21,31,40] else .09);tear(start+.12,.055)
 for i,c in enumerate(s['cues']):
  at=start+c['start'];click(at,800+(i%5)*150,.04);tear(at,.025)
 if s['kind'] in ['stamp','signature','documents']:bass(start+3,.13);click(start+3,180,.12)
 if s['kind']=='truck':
  t=np.arange(int(s['duration']*sr))/sr;add(start,np.sin(2*np.pi*72*t)*np.sin(np.pi*t/s['duration'])**2,.023)
 if s['kind']=='boxes':tear(start+2,.10);click(start+2,130,.1)
 # Short, low original synthesized bed; no third-party music.
 t=np.arange(int(s['duration']*sr))/sr;add(start,np.sin(2*np.pi*36*t)*np.sin(np.pi*t/s['duration'])**2,.009)
mix[-4800:]*=np.linspace(1,0,4800)
sf.write(r/'public/sound-design.wav',mix,sr,subtype='PCM_16')
master=mix*.55
for s in story:
 x,rate=sf.read(r/f'public/voice-{s["id"]:02}.wav',dtype='float32');assert rate==sr
 i=round((s['start']+.1)*sr);n=min(len(x),len(master)-i);master[i:i+n]+=x[:n]*.9
peak=float(np.max(abs(master)));assert peak<.98,peak
sf.write(r/'out/full-audio.wav',master,sr,subtype='PCM_16');print('660-second master audio peak',peak)
