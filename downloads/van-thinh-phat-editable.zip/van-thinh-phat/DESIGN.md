# Vạn Thịnh Phát — Hồ sơ và dòng tiền

## Style Prompt
Sa bàn giấy thủ công Việt Nam: bìa carton dày, viền xé, băng dính giấy, ghim, hồ sơ đỏ, mô hình ngân hàng, xe tải và thùng xốp. Nền navy, đường tiền cyan, chữ kem dễ đọc. Từng vật thể chuyển động theo câu đọc. Đây là hình minh họa cơ chế, không phải tư liệu hiện trường.

## Colors
#0A192F nền; #00F0FF dòng tiền; #F2ECDD giấy; #CDB68F băng dính; #BC403B dấu đỏ.

## Typography
DejaVu Sans Bold (Display) và DejaVu Sans (Body), hỗ trợ đầy đủ tiếng Việt. Tiêu đề 64–84 px ở 1920×1080, phụ đề 38 px, nhãn chính 36–48 px.

## Motion
Từng câu đổi lớp giấy, đường nối hoặc góc nhìn. Nhịp hoạt hình giấy 15 fps; bản MP4 phân phối 30 fps lặp đôi từng khung để giữ chất stop-motion đều. Không chỉ pan/zoom một ảnh. 40 cảnh / 4 hồi / 11 phút.

## What NOT to Do
Không gọi tổng giải ngân là tiền chiếm đoạt. Không dùng so sánh GDP thiếu năm. Không mô tả 108 nghìn tỷ trong một chuyến xe hoặc 5,2 triệu USD trong một chiếc thùng. Không dùng hình ảnh người thật, giấy tờ giả như chứng cứ. Không tuyên bố cập nhật tình trạng tố tụng đến hiện tại khi chưa đối chiếu được nguồn mới.
