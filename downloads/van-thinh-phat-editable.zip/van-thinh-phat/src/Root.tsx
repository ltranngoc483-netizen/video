import React from 'react';import {Composition} from 'remotion';import {Video} from './Video';import {Scene} from './Scene';
export const Root=()=> <><Composition id="VanThinhPhat" component={Video} width={1920} height={1080} fps={15} durationInFrames={9900}/><Composition id="ScenePreview" component={Scene} width={1920} height={1080} fps={15} durationInFrames={270} defaultProps={{index:0}}/></>;
