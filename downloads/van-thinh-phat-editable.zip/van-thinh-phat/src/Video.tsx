import React from 'react';import {AbsoluteFill,Sequence,useVideoConfig,staticFile} from 'remotion';import {Audio} from '@remotion/media';import {Scene} from './Scene';
export const Video=()=>{const {fps}=useVideoConfig();return <AbsoluteFill style={{background:"#0A192F"}}>
<Sequence name="01 / Một triệu tỷ: con số nào?" from={0*fps} durationInFrames={15*fps} premountFor={fps}><Scene index={0}/></Sequence>
<Sequence name="02 / Ba thước đo khác nhau" from={15*fps} durationInFrames={15*fps} premountFor={fps}><Scene index={1}/></Sequence>
<Sequence name="03 / Đừng đánh tráo quy mô" from={30*fps} durationInFrames={15*fps} premountFor={fps}><Scene index={2}/></Sequence>
<Sequence name="04 / Ngân hàng giữ tiền của ai?" from={45*fps} durationInFrames={15*fps} premountFor={fps}><Scene index={3}/></Sequence>
<Sequence name="05 / Một vòng tuần hoàn bị bẻ lái" from={60*fps} durationInFrames={15*fps} premountFor={fps}><Scene index={4}/></Sequence>
<Sequence name="06 / Quyền sở hữu phía sau tên gọi" from={75*fps} durationInFrames={15*fps} premountFor={fps}><Scene index={5}/></Sequence>
<Sequence name="07 / Con số 91,5 phần trăm" from={90*fps} durationInFrames={15*fps} premountFor={fps}><Scene index={6}/></Sequence>
<Sequence name="08 / Ai điều khiển chữ ký?" from={105*fps} durationInFrames={15*fps} premountFor={fps}><Scene index={7}/></Sequence>
<Sequence name="09 / Ba cột trụ của cỗ máy" from={120*fps} durationInFrames={15*fps} premountFor={fps}><Scene index={8}/></Sequence>
<Sequence name="10 / Bóc lớp vỏ đầu tiên" from={135*fps} durationInFrames={15*fps} premountFor={fps}><Scene index={9}/></Sequence>
<Sequence name="11 / Hệ sinh thái trên giấy" from={150*fps} durationInFrames={18*fps} premountFor={fps}><Scene index={10}/></Sequence>
<Sequence name="12 / Cùng một điểm điều khiển" from={168*fps} durationInFrames={18*fps} premountFor={fps}><Scene index={11}/></Sequence>
<Sequence name="13 / Người đứng tên và người dùng tiền" from={186*fps} durationInFrames={18*fps} premountFor={fps}><Scene index={12}/></Sequence>
<Sequence name="14 / Phương án vay đến sau" from={204*fps} durationInFrames={18*fps} premountFor={fps}><Scene index={13}/></Sequence>
<Sequence name="15 / Con dấu không tạo ra giá trị" from={222*fps} durationInFrames={18*fps} premountFor={fps}><Scene index={14}/></Sequence>
<Sequence name="16 / Tài sản lớn, câu hỏi lớn" from={240*fps} durationInFrames={18*fps} premountFor={fps}><Scene index={15}/></Sequence>
<Sequence name="17 / Một dự án không phải tiền mặt" from={258*fps} durationInFrames={18*fps} premountFor={fps}><Scene index={16}/></Sequence>
<Sequence name="18 / Khoản vay mới, khoản nợ cũ" from={276*fps} durationInFrames={18*fps} premountFor={fps}><Scene index={17}/></Sequence>
<Sequence name="19 / Dấu vết nằm giữa các hồ sơ" from={294*fps} durationInFrames={18*fps} premountFor={fps}><Scene index={18}/></Sequence>
<Sequence name="20 / Từ hồ sơ đến cửa két" from={312*fps} durationInFrames={18*fps} premountFor={fps}><Scene index={19}/></Sequence>
<Sequence name="21 / Khi số trên màn hình thành tiền" from={330*fps} durationInFrames={18*fps} premountFor={fps}><Scene index={20}/></Sequence>
<Sequence name="22 / Không phải một chuyến xe" from={348*fps} durationInFrames={18*fps} premountFor={fps}><Scene index={21}/></Sequence>
<Sequence name="23 / Một chuỗi giao nhận" from={366*fps} durationInFrames={18*fps} premountFor={fps}><Scene index={22}/></Sequence>
<Sequence name="24 / Điểm đến của những kiện tiền" from={384*fps} durationInFrames={18*fps} premountFor={fps}><Scene index={23}/></Sequence>
<Sequence name="25 / Kiểm soát không được dừng ở cửa" from={402*fps} durationInFrames={18*fps} premountFor={fps}><Scene index={24}/></Sequence>
<Sequence name="26 / Người kiểm tra cũng cần bị kiểm tra" from={420*fps} durationInFrames={18*fps} premountFor={fps}><Scene index={25}/></Sequence>
<Sequence name="27 / Những chiếc thùng xốp" from={438*fps} durationInFrames={18*fps} premountFor={fps}><Scene index={26}/></Sequence>
<Sequence name="28 / Năm phẩy hai triệu đô la" from={456*fps} durationInFrames={18*fps} premountFor={fps}><Scene index={27}/></Sequence>
<Sequence name="29 / Một khoản tiền, hậu quả dây chuyền" from={474*fps} durationInFrames={18*fps} premountFor={fps}><Scene index={28}/></Sequence>
<Sequence name="30 / Lần ngược ánh sáng cyan" from={492*fps} durationInFrames={18*fps} premountFor={fps}><Scene index={29}/></Sequence>
<Sequence name="31 / Khi niềm tin bị thử thách" from={510*fps} durationInFrames={15*fps} premountFor={fps}><Scene index={30}/></Sequence>
<Sequence name="32 / Người gửi tiền không phải trái chủ" from={525*fps} durationInFrames={15*fps} premountFor={fps}><Scene index={31}/></Sequence>
<Sequence name="33 / Can thiệp và trách nhiệm" from={540*fps} durationInFrames={15*fps} premountFor={fps}><Scene index={32}/></Sequence>
<Sequence name="34 / Phong tỏa chưa phải thu hồi" from={555*fps} durationInFrames={15*fps} premountFor={fps}><Scene index={33}/></Sequence>
<Sequence name="35 / Giá trị nào có thể thực hiện?" from={570*fps} durationInFrames={15*fps} premountFor={fps}><Scene index={34}/></Sequence>
<Sequence name="36 / Bản án phải gắn với giai đoạn" from={585*fps} durationInFrames={15*fps} premountFor={fps}><Scene index={35}/></Sequence>
<Sequence name="37 / Bài học về người hưởng lợi" from={600*fps} durationInFrames={15*fps} premountFor={fps}><Scene index={36}/></Sequence>
<Sequence name="38 / Bài học về quyền phản biện" from={615*fps} durationInFrames={15*fps} premountFor={fps}><Scene index={37}/></Sequence>
<Sequence name="39 / Bài học về con số và bằng chứng" from={630*fps} durationInFrames={15*fps} premountFor={fps}><Scene index={38}/></Sequence>
<Sequence name="40 / Sau lớp giấy cuối cùng" from={645*fps} durationInFrames={15*fps} premountFor={fps}><Scene index={39}/></Sequence>
<Audio name="Hiệu ứng giấy và âm nền" src={staticFile("sound-design.wav")} volume={.55} premountFor={fps}/></AbsoluteFill>};