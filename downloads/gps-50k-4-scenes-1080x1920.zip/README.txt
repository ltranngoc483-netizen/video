TECH UNMASKED — GPS MINI 50K
4 PNG 1080 x 1920, hero frames with Vietnamese labels.
01 0–5s: scooter, tracker, illustrative 50.000Đ price.
02 5–15s: teaching diagram of an empty GPS receiver area; not an authenticated real PCB.
03 15–25s: 3 KM is explicitly an example, not a measured result.
04 25–30s: complete Related Video CTA.

The MP4 is picture/SFX only, without narration, as requested. Import your preferred male voice later. Full script captions are external, not burned in. The 15-cue SRT is provisional editing timing, not transcription; retime it against the real voice recording.

2G wording is conditional, without an independently unverified September 2026 shutdown assertion. Attach an actual matching GPS long video in YouTube Studio before using the Related Video CTA.
