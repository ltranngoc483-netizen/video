# First Brands — The hidden paper trail

## Style Prompt
A physical miniature on a deep navy cardboard board: thick corrugated paper, torn cream sheets, real beige masking tape, cyan stamped ledgers, visible edge thickness and strong directional shadows. A pristine tower becomes an invoice-financing mechanism and collapses into paper rubble. Individual moving sheets, stamps, bank chutes, currency strips and building slices carry each spoken fact. Never rely on a single slowly zooming image for a whole scene.

## Colors
- #0A192F navy board
- #00F0FF cyan financing and connective motion
- #F2ECDD cream paper and captions
- #CDB68F beige tape
- #D54840 red disputed documents and failure stamps

## Typography
Anton for headlines and numeric counters; Mono for ledger details and legal qualifiers. Local font files and licenses are included.

## Motion
Motion starts on the measured phrase cue. Stop-motion collapse quantized to three-frame steps; quick tactile stamp impacts; paper-tear transitions at scene boundaries. At least one content action per spoken phrase. Captions in short readable clauses. All images illustrative.

## What NOT to Do
- No cryptocurrency/FTX imagery.
- No assertion that allegations are convictions.
- No $0 cash card that could contradict ~$12M.
- No empty narration gaps after scenes.
- No important text in the right UI rail or bottom 300px.
