# First Brands — The hidden paper trail

56-second vertical papercraft Short, 1080 × 1920, 30 fps, H.264 / AAC. Main Remotion composition: `FirstBrandsPaperTrail`. Four connected scene compositions: `Illusion`, `AllegedScheme`, `Collapse`, `Fallout`.

## Creative and editorial

The user's attached First Brands script drives the narration and scene windows: 0–11 / 11–30 / 30–48 / 48–56 seconds. Twenty-four clause cues trigger changes in framing and animated objects. Separate invoices travel to three lenders, cash strips flow toward the empire, evidence requests fall, and twelve masked slices of the tower collapse in three-frame stop-motion steps. Captions and narration belong to their scene, so moving a scene moves all three together. Captions use the Remotion Caption JSON format. All timing is deterministic.

The tower is an AI-generated transparent cardboard illustration. All labels and invoice graphics are authored in React, preserving spelling and amounts. The supplied text named four PNG files but did not contain those actual images; this project does not claim to reproduce them. The grain overlay is deliberately subtle. Fonts are local Anton and Mono with their licenses.

## Narration and sound

Voice: Kokoro `am_michael`, a local US male draft previously authorized by the user. It is NOT ElevenLabs Marcus. No ElevenLabs tool or credential was available in the session. HyperFrames' documented local Kokoro TTS workflow informs the narration backend; Remotion is the visual composition and export engine. This is not a HyperFrames HTML project.

Each clause was generated separately, trimmed of model padding, then normalized and fit to the supplied scene windows with FFmpeg atempo (pitch preserved). `src/cues.json` records measured phrase duration after tempo fitting. The documentary delivery is deliberately paced to the requested 56 seconds; there are no long silent holds between scenes. Original synthesized paper, stamp, cash-counter, mechanical-hum and collapse effects follow the same cues. No third-party music.

## Accuracy and publication

Fraud mechanisms are described as prosecutors' allegations, not convictions. Invoice #1042 and its amounts are illustrative diagrams, marked accordingly. The figures displayed are $9B+ liabilities and approximately $12M cash. The symbolic $0 prop was omitted to avoid contradicting that reported cash balance. September 28, 2025 is the filing date in the user-supplied brief. This project follows that brief and does not claim independent verification of the introductory October 2026 procedural-status discussion, which is not included in the spoken film.

The closing arrow is an illustration. Before publishing, attach a real matching First Brands investigation as the Short's Related Video in YouTube Studio. A film about the Internet or credit-card payments would not match this CTA.

## Editing and rebuilding

Install dependencies with `npm ci`, run `npm run dev` (Studio port 3005), and `npm run check`. Rendering: `npx remotion render src/index.ts FirstBrandsPaperTrail out/first-brands-papertrail-56s-draft.mp4 --codec=h264 --crf=21 --audio-bitrate=160k`.

The existing WAVs are included, so no TTS setup is needed to edit or render. To regenerate narration, use `scripts/voice.py` first and then `scripts/fit_audio.py` once, with the official Kokoro ONNX model and voices at `../.models`, Python packages kokoro_onnx/onnxruntime/numpy/soundfile, and FFmpeg installed. Rebuild SFX with `scripts/sound.py`. Do not run fit_audio repeatedly on already fitted assets without first regenerating narration. Python scripts use the local path of their own project as root.
