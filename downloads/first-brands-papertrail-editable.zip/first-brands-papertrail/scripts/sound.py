from pathlib import Path
import numpy as np,soundfile as sf
r=Path(__file__).resolve().parents[1];sr=48000;rng=np.random.default_rng(9901);mix=np.zeros(56*sr)
def add(at,x,gain=1):
 n=round(at*sr);e=min(len(mix),n+len(x));mix[n:e]+=x[:e-n]*gain
def bass(at,gain=.23):
 t=np.arange(int(.9*sr))/sr;add(at,(np.sin(2*np.pi*(52*t-9*t*t))+.16*rng.normal(0,1,len(t))*np.exp(-t*28))*np.exp(-t*7),gain)
def tear(at,length=.35,gain=.1):
 t=np.arange(int(length*sr))/sr;n=rng.normal(0,1,len(t));n-=np.convolve(n,np.ones(17)/17,mode='same');add(at,n*np.sin(np.pi*t/length)**2*np.exp(-t*5),gain)
def whoosh(at,pitch):
 t=np.arange(int(.6*sr))/sr;n=np.convolve(rng.normal(0,1,len(t)),np.ones(19)/19,mode='same');add(at,(n+.12*np.sin(2*np.pi*(pitch*t+150*t*t)))*np.sin(np.pi*t/.6)**2,.14)
def click(at,pitch=1100):
 t=np.arange(int(.09*sr))/sr;add(at,(np.sin(2*np.pi*pitch*t)+rng.normal(0,.2,len(t)))*np.exp(-t*70),.09)

import json
cues=json.loads((r/'src/cues.json').read_text())
def cue(scene,i,base):return base+cues[scene][i]['start']
bass(.15,.26);tear(.15,.4,.10)
for scene,base in [('illusion',0),('fraud',11),('collapse',30),('fallout',48)]:
 for i,c in enumerate(cues[scene]):
  at=base+c['start'];tear(at,.24,.055)
  if i%2==0:click(at,750+i*100)
for at in [2.65,3.05,3.45,4.25]:click(at,1000)
bass(cue('illusion',3,0),.14)
for i in range(3):click(cue('fraud',2,11)+i*.27,1300+i*100)
for i in range(9):click(cue('fraud',5,11)+i*.26,800+i*40)
for scene,i,base in [('fraud',1,11),('fraud',7,11),('collapse',1,30)]:bass(cue(scene,i,base),.16)
crash=cue('collapse',3,30)
for i in range(12):tear(crash+i*.10,.3,.06);click(crash+i*.10,210+i*30)
bass(crash,.34);bass(crash+.8,.22)
for at in [cue('collapse',4,30),cue('collapse',5,30),48.1,cue('fallout',2,48),cue('fallout',3,48)]:bass(at,.21)
t=np.arange(int(55.5*sr))/sr;add(0,np.sin(2*np.pi*38*t)*np.sin(np.pi*t/55.5)**2,.014)
mix[-4800:]*=np.linspace(1,0,4800)
sf.write(r/'public/sound-design.wav',mix,sr,subtype='PCM_16')
master=mix*.6
for name,at in [('illusion',.1),('fraud',11.1),('collapse',30.1),('fallout',48.1)]:
 x,s=sf.read(r/f'public/{name}.wav');assert s==sr
 i=round(at*sr);n=min(len(x),len(master)-i);master[i:i+n]+=x[:n]
print('Master predicted peak',float(np.max(abs(master))))
