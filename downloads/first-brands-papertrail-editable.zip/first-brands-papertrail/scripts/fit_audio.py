from pathlib import Path
import json,subprocess,soundfile as sf
r=Path(__file__).resolve().parents[1]
scenes=json.loads((r/'scripts/narration.json').read_text());caps=json.loads((r/'src/captions.json').read_text());updated=[];timing={}
for s in scenes:
 p=r/f'public/{s["id"]}.wav';x,sr=sf.read(p);old=len(x)/sr;target=s['duration']-.22;factor=target/old
 temp=p.with_name(s['id']+'-fit.wav')
 subprocess.run(['ffmpeg','-y','-v','error','-i',str(p),'-af',f'atempo={1/factor:.10f},apad,atrim=duration={target},afade=t=out:st={target-.025}:d=0.025','-ar','48000',str(temp)],check=True);temp.replace(p)
 local=[]
 for c in caps:
  if s['start']*1000<=c['startMs']<(s['start']+s['duration'])*1000:
   c=c.copy();a=(c['startMs']/1000-s['start']-.1)*factor+.10;b=(c['endMs']/1000-s['start']-.1)*factor+.10
   c.update(startMs=round((s['start']+a)*1000),endMs=round((s['start']+b)*1000),timestampMs=round((s['start']+a)*1000));updated.append(c);local.append(dict(text=c['text'],start=a,end=b))
 timing[s['id']]=local
 print(s['id'],round(old,2),'->',target,'s')
(r/'src/captions.json').write_text(json.dumps(updated,indent=2));(r/'src/cues.json').write_text(json.dumps(timing,indent=2))
