from pathlib import Path
import json,subprocess,numpy as np,soundfile as sf
r=Path(__file__).resolve().parents[1];p=r/'out/first-brands-papertrail-56s-draft.mp4'
d=json.loads(subprocess.check_output(['ffprobe','-v','error','-show_entries','format=duration,size:stream=codec_type,codec_name,width,height,r_frame_rate,nb_frames','-of','json',str(p)],text=True))
v=next(x for x in d['streams'] if x['codec_type']=='video');a=next(x for x in d['streams'] if x['codec_type']=='audio')
assert (v['width'],v['height'],v['r_frame_rate'],v['nb_frames'])==(1080,1920,'30/1','1680')
assert abs(float(d['format']['duration'])-56)<.05
assert a['codec_name']=='aac'
assert v['codec_name']=='h264'
subprocess.run(['ffmpeg','-v','error','-threads','2','-i',str(p),'-f','null','-'],check=True)
subprocess.run(['ffmpeg','-y','-v','error','-i',str(p),'-vn','-c:a','pcm_f32le',str(r/'out/decoded-audio.wav')],check=True)
x,sr=sf.read(r/'out/decoded-audio.wav');peak=float(np.max(abs(x)));assert peak<1,peak
(r/'out/validation.json').write_text(json.dumps(dict(metadata=d,audioPeak=peak,voice='Kokoro am_michael local draft',ctaStartFrame=1440),indent=2))
print('PASS: 1680 frames; 1080x1920; 30 fps; H.264/AAC; full decode clean; audio peak',round(peak,3))
