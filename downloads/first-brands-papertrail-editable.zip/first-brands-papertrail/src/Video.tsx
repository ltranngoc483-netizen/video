import React from 'react';import {AbsoluteFill,staticFile,useVideoConfig} from 'remotion';import {Audio} from '@remotion/media';import {TransitionSeries,linearTiming} from '@remotion/transitions';import {PaperTear} from './PaperTear';import {Illusion} from './Illusion';import {Fraud} from './Fraud';import {Collapse} from './Collapse';import {Fallout} from './Fallout';
export const Video=()=>{const {fps}=useVideoConfig();return <AbsoluteFill style={{background:'#0A192F'}}><TransitionSeries>
<TransitionSeries.Sequence name="01 / The Illusion" durationInFrames={11*fps+6} premountFor={fps}><Illusion/></TransitionSeries.Sequence>
<TransitionSeries.Transition presentation={{component:PaperTear,props:{}}} timing={linearTiming({durationInFrames:6})}/>
<TransitionSeries.Sequence name="02 / The Alleged Scheme" durationInFrames={19*fps+6} premountFor={fps}><Fraud/></TransitionSeries.Sequence>
<TransitionSeries.Transition presentation={{component:PaperTear,props:{}}} timing={linearTiming({durationInFrames:6})}/>
<TransitionSeries.Sequence name="03 / The Collapse" durationInFrames={18*fps+6} premountFor={fps}><Collapse/></TransitionSeries.Sequence>
<TransitionSeries.Transition presentation={{component:PaperTear,props:{}}} timing={linearTiming({durationInFrames:6})}/>
<TransitionSeries.Sequence name="04 / The Fallout" durationInFrames={8*fps} premountFor={fps}><Fallout/></TransitionSeries.Sequence>
</TransitionSeries><Audio name="Paper, stamp, cash and collapse effects" src={staticFile('sound-design.wav')} volume={.6} premountFor={fps}/></AbsoluteFill>};
