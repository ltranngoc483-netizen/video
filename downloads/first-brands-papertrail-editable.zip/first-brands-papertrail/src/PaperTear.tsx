import React from 'react';
import {AbsoluteFill,useVideoConfig} from 'remotion';
import type {TransitionPresentationComponentProps} from '@remotion/transitions';
export const PaperTear:React.FC<TransitionPresentationComponentProps<Record<string,never>>>=({children,presentationProgress,presentationDirection})=>{
 const {width,height}=useVideoConfig();
 if(presentationDirection==='exiting')return <AbsoluteFill>{children}</AbsoluteFill>;
 const edge=-90+(width+180)*presentationProgress;
 const offsets=[0,18,-9,26,-15,13,-20,21,-12,16,0];
 const points=offsets.map((x,i)=>`${edge+x}px ${height*i/10}px`).join(',');
 const line=offsets.map((x,i)=>`${edge+x},${height*i/10}`).join(' ');
 return <AbsoluteFill style={{clipPath:`polygon(0px 0px,${points},0px ${height}px)`}}>{children}{presentationProgress>0&&presentationProgress<1?<svg width={width} height={height} style={{position:'absolute',left:0,top:0,pointerEvents:'none'}}><polyline points={line} fill="none" stroke="#F2ECDD" strokeWidth="18"/></svg>:null}</AbsoluteFill>;
};
