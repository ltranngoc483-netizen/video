import React from 'react';import {Composition,Folder} from 'remotion';import {Video} from './Video';import {Illusion} from './Illusion';import {Fraud} from './Fraud';import {Collapse} from './Collapse';import {Fallout} from './Fallout';
export const Root=()=> <><Composition id="FirstBrandsPaperTrail" component={Video} width={1080} height={1920} fps={30} durationInFrames={1680}/><Folder name="Scenes">
<Composition id="Illusion" component={Illusion} width={1080} height={1920} fps={30} durationInFrames={330}/>
<Composition id="AllegedScheme" component={Fraud} width={1080} height={1920} fps={30} durationInFrames={570}/>
<Composition id="Collapse" component={Collapse} width={1080} height={1920} fps={30} durationInFrames={540}/>
<Composition id="Fallout" component={Fallout} width={1080} height={1920} fps={30} durationInFrames={240}/>
</Folder></>;
