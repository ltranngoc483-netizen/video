from pathlib import Path
import json,subprocess
import numpy as np
import soundfile as sf
r=Path(__file__).resolve().parents[1];sr=48000;n=30*sr;rng=np.random.default_rng(1820);vo=np.zeros(n);sfx=np.zeros(n)
for s in json.loads((r/'scripts/narration.json').read_text()):
 x,rate=sf.read(r/'public'/f'{s["id"]}.wav');assert rate==sr;i=round((s['start']+.1)*sr);k=min(len(x),n-i);vo[i:i+k]+=x[:k]
def add(at,x):
 i=round(at*sr);k=min(len(x),n-i)
 if k>0:sfx[i:i+k]+=x[:k]
def thud(at,amp=.35,d=.7):
 t=np.arange(round(d*sr))/sr;add(at,amp*np.sin(2*np.pi*(54*t-10*t*t))*np.exp(-t*6))
def click(at,amp=.2,freq=1100):
 t=np.arange(round(.085*sr))/sr;add(at,amp*(.55*rng.normal(size=len(t))+.45*np.sin(2*np.pi*freq*t))*np.exp(-t*70))
def paper(at,d=.25,amp=.18):
 t=np.arange(round(d*sr))/sr;x=rng.normal(size=len(t));x-=np.convolve(x,np.ones(24)/24,mode='same');add(at,amp*x*np.sin(np.pi*t/d)**2*np.exp(-t*5))
def knock(at,amp=.2):
 t=np.arange(round(.25*sr))/sr;add(at,amp*(np.sin(2*np.pi*185*t)+.3*np.sin(2*np.pi*390*t))*np.exp(-t*24))
t=np.arange(n)/sr;bed=(.013*np.sin(2*np.pi*43*t)+.008*np.sin(2*np.pi*57.8*t)+.003*np.sin(2*np.pi*120*t))*(.65+.35*np.sin(2*np.pi*.23*t)**2);bed*=np.minimum(1,t/.6)*np.minimum(1,(30-t)/.65);sfx+=bed
# Haptic send, paper snap and data departure.
click(.14,.3,900);thud(.18,.28);paper(.35,.2,.16)
for at in [.7,.95,1.14,2.0,2.7,3.305]:click(at,.09,1800);paper(at,.12,.09)
for at in [4.95,7.139,9.479,13.395,14.95,17.2,19.425,21,22.406,24.95]:paper(at,.23,.18)
for at in [5.3,5.6,5.9,6.2,7.3,7.55,7.8,8.1]:knock(at,.11)
thud(7.2,.18);click(9.48,.24,950);thud(13.45,.25,.45)
for at in [15.3,16.0,17.2,18.3,19.4,20.2,21.1,22.4,23.3,24.1]:
 tone=np.arange(round(.17*sr))/sr;add(at,.06*np.sin(2*np.pi*(1200*tone+1800*tone*tone))*np.sin(np.pi*tone/.17)**2)
# Quiet, abstract underwater low-frequency bed, no invented latency measurements.
thud(19.43,.18,.8)
tone=np.arange(round(.6*sr))/sr;add(25.72,.12*(np.sin(2*np.pi*880*tone)+.45*np.sin(2*np.pi*1320*tone))*np.exp(-tone*6))
paper(25,.3,.19);paper(26.65,.28,.15);thud(26.68,.22);thud(28.15,.18,.5);thud(29.55,.16,.45)
sfx*=np.minimum(1,(30-t)/.5)
sf.write(r/'public/narration.wav',vo,sr);sf.write(r/'public/sound-design.wav',sfx,sr)
sf.write(r/'out/mix-raw.wav',vo+.22*sfx,sr,subtype='FLOAT')
subprocess.run(['ffmpeg','-y','-v','error','-i',str(r/'out/mix-raw.wav'),'-af','alimiter=limit=0.95:level=0:latency=1','-ar','48000',str(r/'out/final-audio.wav')],check=True)
caps=json.loads((r/'src/captions.json').read_text())
def tc(ms):return f'{ms//3600000:02}:{ms//60000%60:02}:{ms//1000%60:02},{ms%1000:03}'
(r/'out/message-journey-en.srt').write_text('\n\n'.join(f'{i+1}\n{tc(c["startMs"])} --> {tc(c["endMs"])}\n{c["text"]}' for i,c in enumerate(caps))+'\n')
print('30s narration + original SFX/ambient bed;12 phrase-aligned cues')
