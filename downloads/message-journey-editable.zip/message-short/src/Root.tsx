import React from 'react';import {Composition,Still,Freeze} from 'remotion';import {ImageExport} from './Captions';import {Video} from './Video';import {BinarySend} from './BinarySend';import {CryptoLock} from './CryptoLock';import {FiberFlight} from './FiberFlight';import {ReceiveFunnel} from './ReceiveFunnel';
const Asset01=()=> <ImageExport.Provider value={true}><Freeze frame={70}><BinarySend/></Freeze></ImageExport.Provider>;
const Asset02=()=> <ImageExport.Provider value={true}><Freeze frame={195}><CryptoLock/></Freeze></ImageExport.Provider>;
const Asset03=()=> <ImageExport.Provider value={true}><Freeze frame={200}><FiberFlight/></Freeze></ImageExport.Provider>;
const Asset04=()=> <ImageExport.Provider value={true}><Freeze frame={110}><ReceiveFunnel/></Freeze></ImageExport.Provider>;
export const Root=()=> <>
<Composition id="MessageJourney" component={Video} width={1080} height={1920} fps={30} durationInFrames={900}/>
<Composition id="BinarySend" component={BinarySend} width={1080} height={1920} fps={30} durationInFrames={150}/>
<Composition id="CryptoLock" component={CryptoLock} width={1080} height={1920} fps={30} durationInFrames={300}/>
<Composition id="FiberFlight" component={FiberFlight} width={1080} height={1920} fps={30} durationInFrames={300}/>
<Composition id="ReceiveFunnel" component={ReceiveFunnel} width={1080} height={1920} fps={30} durationInFrames={150}/>
<Still id="Scene01" component={Asset01} width={1080} height={1920}/>
<Still id="Scene02" component={Asset02} width={1080} height={1920}/>
<Still id="Scene03" component={Asset03} width={1080} height={1920}/>
<Still id="Scene04" component={Asset04} width={1080} height={1920}/>
</>;
