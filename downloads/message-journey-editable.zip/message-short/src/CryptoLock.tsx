import React from 'react';import {useCurrentFrame,useVideoConfig} from 'remotion';import {Art,Base,Title,Tag,Fine,stepped,mix} from './Visuals';import {Packet,Gear,DataTrace} from './DataProps';import {Captions} from './Captions';
export const CryptoLock=()=>{const f=useCurrentFrame();const {fps}=useVideoConfig();const t=stepped(f,fps);const shot=t<2.139?0:t<4.479?1:t<8.395?2:3;return <Base chapter="02 / END-TO-END ENCRYPTION">
<Art file="encryption" style={{scale:shot===0?1+t*.02:shot===1?1.22:shot===2?1.15:1.02,translate:shot===1?'65px -30px':shot===2?'-100px 30px':'0 0'}}/>
<Title>LOCKED ON<br/>YOUR PHONE</Title><Gear x={92} y={1100}/><Gear x={250} y={1145} reverse/>
<Packet x={mix(t,2.1,8.5,380,650)} y={mix(t,2.1,8.5,1030,1180)+Math.sin(t*3)*12} width={210} rotation={mix(t,2.1,4.0,-10,5)} opacity={mix(t,2.1,2.45,0,1)}/>
<DataTrace path="M95 980C270 940 320 1090 460 1050" at={.3}/>
<Tag top={1390} at={.2}>{shot<2?'SUPPORTED APPS · CONTENTS ONLY':shot===2?'SERVERS CARRY CIPHERTEXT':'E2EE IS NOT UNIVERSAL'}</Tag>
<Fine top={1550}>Only when the service supports end-to-end encryption. Message contents, not a promise of hidden metadata.</Fine><Captions start={5}/>
</Base>};
