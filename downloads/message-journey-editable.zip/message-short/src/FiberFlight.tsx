import React from 'react';import {useCurrentFrame,useVideoConfig} from 'remotion';import {Art,Base,Title,Tag,Fine,stepped,mix} from './Visuals';import {Packet,DataTrace} from './DataProps';import {Captions} from './Captions';
export const FiberFlight=()=>{const f=useCurrentFrame();const {fps}=useVideoConfig();const t=stepped(f,fps);const shot=t<2.2?0:t<4.425?1:t<6?2:t<7.406?3:4;return <Base chapter="03 / THE PHYSICAL NETWORK">
<Art file="network" style={{scale:shot===0?1.18:shot===1?1.1:shot===2?1.03:shot===3?1.23:1.32,translate:shot===0?'140px 50px':shot===3?'-90px -40px':shot===4?'-145px -70px':'0 0'}}/>
<Title>{shot<2?'ROUTERS & FIBER':shot<4?'SOME ROUTES<br/>CROSS OCEANS':'PULSES OF LIGHT'}</Title>
<Packet x={mix(t,.2,2.4,90,360)} y={mix(t,.2,2.4,760,1020)} width={155} rotation={mix(t,.2,2.4,-10,15)} opacity={t<2.5?mix(t,.1,.3,0,1):0}/>
<DataTrace path="M170 790L170 975Q170 1070 350 1080L720 1120"/>
<DataTrace path="M700 1100L1020 1060M700 1130L1020 1130M700 1160L1020 1190" at={3}/>
<Tag top={1390} at={.2}>{['PACKETS THROUGH NETWORKS','REAL CABLES · REAL INFRASTRUCTURE','AN OCEAN CROSSING? SOMETIMES.','OPTICAL FIBERS','INFORMATION ENCODED AS LIGHT'][shot]}</Tag>
<Fine top={1550}>The route depends on location and infrastructure. A message does not necessarily cross an ocean.</Fine><Captions start={15}/>
</Base>};
