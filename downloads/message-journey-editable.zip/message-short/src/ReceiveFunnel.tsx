import React from 'react';import {useCurrentFrame,useVideoConfig} from 'remotion';import {Art,Base,Tag,Fine,stepped,mix,C} from './Visuals';import {Cube} from './DataProps';import {Captions} from './Captions';
export const ReceiveFunnel=()=>{const f=useCurrentFrame();const {fps}=useVideoConfig();const t=stepped(f,fps);const pulse=(t>1.2&&t<1.7)||(t>3&&t<3.5);return <Base chapter="04 / RECEIVED">
<Art file="received" style={{scale:mix(t,0,1.65,1.04,1),opacity:mix(t,1.65,2.1,1,.62)}}/>
{Array.from({length:5},(_,i)=>{const p=mix(t,.12+i*.06,1.5+i*.02,0,1);return <Cube key={i} x={680-i*75+(300-(680-i*75))*p} y={710-i*45+(1130-(710-i*45))*p} size={48} rotation={p*25} opacity={t<1.6?1:0} digit={i%2?'0':'1'}/>})}
<div style={{position:'absolute',left:76,right:180,top:210,fontFamily:'Display',fontSize:76,lineHeight:1.1,color:C.cream,opacity:mix(t,.1,.4,0,1),translate:`0 ${mix(t,.1,.4,-25,0)}px`,textShadow:'0 7px 4px #000'}}>THE INVISIBLE<br/>WORLD</div>
<div style={{position:'absolute',left:80,right:180,top:440,fontFamily:'Body',fontSize:31,color:C.cream,background:'#0A192FEF',padding:'8px 12px',opacity:mix(t,.2,.5,0,1)}}>Understand What You Never See</div>
<Tag top={585} at={.2}>MESSAGE DELIVERED</Tag>
<svg width="230" height="320" viewBox="0 0 340 350" style={{position:'absolute',left:620,top:1060,scale:mix(t,.2,.5,.7,1)*(pulse?1.08:1),opacity:mix(t,.1,.4,0,1),translate:`0 ${pulse?12:0}px`,filter:`drop-shadow(0 0 ${pulse?35:12}px ${C.cyan}88)`}}><path d="M112 10 L228 5 L229 197 L329 190 L172 337 L10 196 L114 200 Z" fill={C.cyan} stroke={C.cream} strokeWidth="3"/></svg>
<svg width="160" height="160" style={{position:'absolute',left:350,top:1220,opacity:t>1.6?mix(t,1.6,2,1,0):mix(t,.7,1,0,1),scale:mix(t,.7,1.1,.7,1)}}><path d="M20 70L60 108L135 25" fill="none" stroke={C.cyan} strokeWidth="22" strokeLinecap="square"/></svg>
<Tag top={1425} at={.2}>RELATED VIDEO ↓</Tag><Captions start={25} cta/>
</Base>};
