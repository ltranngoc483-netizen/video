import React from 'react';import {useCurrentFrame,useVideoConfig} from 'remotion';import {Art,Base,Title,Tag,Fine,stepped,mix} from './Visuals';import {Cube} from './DataProps';import {Captions} from './Captions';
export const BinarySend=()=>{const f=useCurrentFrame();const {fps}=useVideoConfig();const t=stepped(f,fps);const shot=t<1.141?0:t<3.305?1:2;return <Base chapter="01 / SEND">
<Art file="send" style={{scale:shot===0?1.07+t*.04:shot===1?1.18+(t-1.141)*.035:1.3,translate:shot===0?'0 -70px':shot===1?'0 10px':'-100px 110px'}}/>
<Title>WHAT HAPPENS<br/>AFTER SEND?</Title>
{Array.from({length:7},(_,i)=>{const p=mix(t,.6+i*.13,2.7+i*.13,0,1);return <Cube key={i} x={510+p*(220-i*55)} y={1010-p*(410+i*38)} size={60+(i%3)*10} rotation={p*(25-i*8)} digit={i%2?'0':'1'} opacity={mix(t,.6+i*.13,.8+i*.13,0,1)}/>})}
<Tag top={1400} at={.3}>{shot===0?'SEND':shot===1?'WORDS → DIGITAL DATA':'BITS, NOT A FLOATING BUBBLE'}</Tag>
<Fine top={1570}>Paper cubes visualize data; they are not physical objects inside the phone.</Fine><Captions start={0}/>
</Base>};
