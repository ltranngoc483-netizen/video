# The Invisible World — Send a Message
## Style Prompt
Photographic physical3D papercraft, thick torn navy cardboard, cream layered phones, brass pins, beige masking tape, cyan data and optical light, deep macro shadows. One continuous journey from thumb/button to envelope/vault to fiber/router to recipient. Bright cyan is information representation, never real glowing digital cubes in hardware.
## Palette
#0A192F navy, #00F0FF cyan, #F2ECDD cream, #8C7859 brass. No full-screen flat gradients or generic dashboard UI.
## Type
Local DejaVu Display bold77px short titles, Body47px English captions, Mono22–28px technical qualifiers. Right180px and bottom330px reserved for Shorts controls. Titles and captions placed above main objects.
## Motion
15pose/sec stop-motion transforms,14–16 shot beats, a consistent torn-paper wipe. Independent animated data cubes/envelope/pulses/gears/checkmark and CTA arrow. Logo/Related Video invitation in exact25–30s window.
## Avoid
No claim that SMS or all apps provide E2EE. E2EE content privacy is not a promise of hidden metadata, uninfected endpoints or zero backups. Do not show intermediary decryption. No guaranteed ocean route, latency, distance, or instantly-read receipt. No source-code-like encryption that suggests the illustration is a real protocol.
