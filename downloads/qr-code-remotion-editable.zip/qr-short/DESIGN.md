# The Invisible World — QR

## Style Prompt
Photographic tactile papercraft dioramas, thick corrugated cream cardboard, rough torn edges, real masking tape and metal pins, macro depth and strong directional shadows. Navy and cyan only, restrained ivory type. Actual independent module, finder, packet and vault animations; editorial shot change every 1.5–2 seconds during decoding and payment. Stop-motion transforms sampled at 15 steps/sec, delivered at 30 fps. Narration continues without long pauses.

## Colors
#0A192F navy board; #00F0FF cyan data; #F2ECDD textured cream paper; #B8C8CE quiet secondary type.

## Typography
Display (DejaVu Sans Bold) for 60–100px titles; Body (DejaVu Sans) for 28–36px labels; 48–54px captions. Safe text area x80–900 and y120–1550; no essential CTA below y1450.

## What NOT to Do
No flat vector scenes or plain slide backgrounds. No generated gibberish labels. No claim scanning guarantees payment. No 300ms completion claim. No encryption claim. No satellite/internet journey before local decoding. No watermarks or branded bank UI. Reserve 25–30sec for CTA.
