import React from 'react';import {Composition,Still,AbsoluteFill} from 'remotion';import {Video} from './Video';import {OpticalLock} from './OpticalLock';import {UnpackingGrid} from './UnpackingGrid';import {BankingVaults} from './BankingVaults';import {Funnel} from './Funnel';import {Photo} from './Visuals';
const Asset=({file}:{file:string})=><AbsoluteFill><Photo file={file}/></AbsoluteFill>;
export const Root=()=> <>
<Composition id="QRShort" component={Video} width={1080} height={1920} fps={30} durationInFrames={900}/>
<Composition id="OpticalLock" component={OpticalLock} width={1080} height={1920} fps={30} durationInFrames={150}/>
<Composition id="UnpackingGrid" component={UnpackingGrid} width={1080} height={1920} fps={30} durationInFrames={300}/>
<Composition id="BankingVaults" component={BankingVaults} width={1080} height={1920} fps={30} durationInFrames={300}/>
<Composition id="Funnel" component={Funnel} width={1080} height={1920} fps={30} durationInFrames={150}/>
<Still id="Scene01Asset" component={Asset} width={1080} height={1920} defaultProps={{file:'optical'}}/>
<Still id="Scene02Asset" component={Asset} width={1080} height={1920} defaultProps={{file:'grid'}}/>
<Still id="Scene03Asset" component={Asset} width={1080} height={1920} defaultProps={{file:'vaults'}}/>
<Still id="Scene04Asset" component={Funnel} width={1080} height={1920} defaultProps={{still:true}}/>
<Still id="Thumbnail" component={Asset} width={1080} height={1920} defaultProps={{file:'thumbnail'}}/>
</>;
