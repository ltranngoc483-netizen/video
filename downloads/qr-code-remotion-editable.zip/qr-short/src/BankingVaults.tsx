import React from 'react';
import {AbsoluteFill,useCurrentFrame,useVideoConfig} from 'remotion';
import {SceneBase,Photo,Cutout,Heading,Label,Captions,Trace,mix,C} from './Visuals';
export const BankingVaults=()=>{const f=useCurrentFrame();const {fps}=useVideoConfig();const t=Math.floor(f/2)*2/fps;const shot=t<2.08?0:t<4.4?1:t<6.33?2:3;const views=[{s:1,x:0,y:0},{s:1.5,x:0,y:-260},{s:1.45,x:-210,y:70},{s:1.04,x:0,y:-30}];const v=views[shot];const travel=mix(t,.55,6.1,0,1);const x=travel<.18?160:travel>.8?845:mix(travel,.18,.8,160,845);const y=travel<.18?mix(travel,0,.18,1150,1385):travel>.8?mix(travel,.8,1,1385,1140):1385;
return <AbsoluteFill style={{color:C.cream,fontFamily:'Body'}}><SceneBase><div style={{position:'absolute',inset:0,scale:v.s+mix(t%2,0,2,0,.018),translate:`${v.x}px ${v.y}px`,transformOrigin:'50% 50%'}}><Photo file="vaults"/>
<Cutout file="vaults" clip="circle(68px at 220px 910px)" origin="220px 910px" style={{rotate:`${mix(t,1.7,4.7,0,105)}deg`}}/>
<Cutout file="vaults" clip="circle(68px at 840px 910px)" origin="840px 910px" style={{rotate:`${mix(t,3.4,6.2,0,-105)}deg`}}/>
{[335,560,800].map((gx,i)=><Cutout key={gx} file="vaults" clip={`inset(1285px ${1080-gx-45}px 600px ${gx-45}px)`} origin={`${gx}px 1320px`} style={{translate:`0 ${mix(t,2+i*.65,2.35+i*.65,0,-45)}px`}}/>)}
<Trace path="M 155 1150 C 130 1330 190 1380 280 1385 L 770 1385 Q 850 1380 850 1140"/>
<div style={{position:'absolute',left:x-20,top:y-20,width:40,height:40,background:C.cyan,rotate:'45deg',boxShadow:'0 0 28px #00F0FF',border:'4px solid #F2FFFF',opacity:t<6.35?1:0}}/>
</div></SceneBase><Heading>{['THE APP SENDS A REQUEST.','DETAILS ARE CHECKED.','AUTHORIZATION.','SCANNING ≠ MONEY MOVED'][shot]}</Heading>{shot===3?<div style={{position:'absolute',left:80,right:180,top:1260,padding:'22px 24px',fontFamily:'Display',fontSize:46,color:C.navy,background:C.cream,rotate:'-2deg',boxShadow:'8px 13px 0 #0005'}}>SCAN ≠ PAYMENT CONFIRMATION</div>:<Label y={1420}>ILLUSTRATIVE PAYMENT SYSTEMS</Label>}<Captions start={15}/></AbsoluteFill>};
