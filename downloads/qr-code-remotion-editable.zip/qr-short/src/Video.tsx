import React from 'react';
import {AbsoluteFill,staticFile,useVideoConfig} from 'remotion';
import {Audio} from '@remotion/media';
import {TransitionSeries} from '@remotion/transitions';
import {OpticalLock} from './OpticalLock';import {UnpackingGrid} from './UnpackingGrid';import {BankingVaults} from './BankingVaults';import {Funnel} from './Funnel';import {PaperTransition} from './Visuals';
export const Video=()=>{const {fps}=useVideoConfig();return <AbsoluteFill><TransitionSeries>
<TransitionSeries.Sequence name="01 Optical lock" durationInFrames={5*fps} premountFor={fps}><OpticalLock/><Audio src={staticFile('hook.wav')} premountFor={fps}/></TransitionSeries.Sequence>
<TransitionSeries.Overlay durationInFrames={8} premountFor={fps}><PaperTransition/></TransitionSeries.Overlay>
<TransitionSeries.Sequence name="02 Unpacking the grid" durationInFrames={10*fps} premountFor={fps}><UnpackingGrid/><Audio src={staticFile('grid.wav')} premountFor={fps}/></TransitionSeries.Sequence>
<TransitionSeries.Overlay durationInFrames={8} premountFor={fps}><PaperTransition/></TransitionSeries.Overlay>
<TransitionSeries.Sequence name="03 Banking systems" durationInFrames={10*fps} premountFor={fps}><BankingVaults/><Audio src={staticFile('vaults.wav')} premountFor={fps}/></TransitionSeries.Sequence>
<TransitionSeries.Overlay durationInFrames={8} premountFor={fps}><PaperTransition/></TransitionSeries.Overlay>
<TransitionSeries.Sequence name="04 Related video CTA" durationInFrames={5*fps} premountFor={fps}><Funnel/><Audio src={staticFile('cta.wav')} premountFor={fps}/></TransitionSeries.Sequence>
</TransitionSeries><Audio src={staticFile('sound-design.wav')} volume={.24} premountFor={fps}/></AbsoluteFill>};
