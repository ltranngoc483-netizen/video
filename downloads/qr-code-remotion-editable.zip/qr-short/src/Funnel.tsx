import React from 'react';
import {AbsoluteFill,useCurrentFrame,useVideoConfig} from 'remotion';
import {SceneBase,Photo,Captions,mix,C} from './Visuals';
export const Funnel=({still=false}:{still?:boolean})=>{const f=useCurrentFrame();const {fps}=useVideoConfig();const t=still?4:Math.floor(f/2)*2/fps;return <AbsoluteFill style={{color:C.cream,fontFamily:'Body'}}><SceneBase><div style={{position:'absolute',inset:0,transform:`perspective(1500px) rotateX(${mix(t,0,.5,30,0)}deg)`,transformOrigin:'50% 80%'}}><Photo file="cover"/></div></SceneBase><Captions start={25} cta/>
<div style={{position:'absolute',left:100,right:180,top:600,fontSize:92,fontFamily:'Display',lineHeight:1.01,textShadow:'7px 8px 0 #0008',opacity:mix(t,.15,.6,0,1),translate:`0 ${mix(t,.15,.6,50,0)}px`}}>THE INVISIBLE WORLD</div>
<div style={{position:'absolute',left:100,right:180,top:920,fontSize:32,color:C.cream,opacity:mix(t,.4,.9,0,1)}}>Understand What You Never See.</div>
<div style={{position:'absolute',left:100,right:180,top:1055,padding:'20px 18px',fontSize:39,fontFamily:'Display',background:C.cyan,color:C.navy,textAlign:'center',boxShadow:'8px 12px 0 #0006',opacity:mix(t,.6,1,0,1),rotate:`${mix(t,.6,1,-6,0)}deg`}}>WATCH THE FULL STORY</div>
<svg width="1080" height="1920" style={{position:'absolute',inset:0,opacity:mix(t,.85,1.15,0,1),translate:`0 ${t>1?Math.round(Math.sin(t*5)*8):0}px`}}><path d="M 440 1200 L 590 1200 L 590 1320 L 685 1320 L 515 1460 L 345 1320 L 440 1320 Z" fill="#b5a181" transform="translate(9 13)"/><path d="M 440 1200 L 590 1200 L 590 1320 L 685 1320 L 515 1460 L 345 1320 L 440 1320 Z" fill={C.cyan} stroke={C.cream} strokeWidth="6"/></svg>
<div style={{position:'absolute',left:100,right:180,top:1500,color:C.cyan,fontFamily:'Display',fontSize:35,textAlign:'center',opacity:mix(t,1,1.3,0,1)}}>RELATED VIDEO ↓</div>
</AbsoluteFill>};
