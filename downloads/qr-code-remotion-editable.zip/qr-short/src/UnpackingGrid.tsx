import React from 'react';
import {AbsoluteFill,useCurrentFrame,useVideoConfig} from 'remotion';
import {SceneBase,Photo,Cutout,Heading,Label,Captions,Trace,mix,C} from './Visuals';
export const UnpackingGrid=()=>{const f=useCurrentFrame();const {fps}=useVideoConfig();const t=Math.floor(f/2)*2/fps;
const shot=t<2.75?0:t<4.2?1:t<5.72?2:t<7.52?3:4;
const views=[{s:1.12,x:0,y:-210},{s:1.55,x:220,y:230},{s:1.5,x:-250,y:230},{s:1.42,x:0,y:-240},{s:1,x:0,y:0}];const v=views[shot];
return <AbsoluteFill style={{color:C.cream,fontFamily:'Body'}}><SceneBase><div style={{position:'absolute',inset:0,scale:v.s+mix(t%2,0,2,0,.025),translate:`${v.x}px ${v.y}px`,transformOrigin:'50% 50%'}}><Photo file="grid"/>
{Array.from({length:16},(_,i)=>{const row=Math.floor(i/4),col=i%4;const x=400+col*82,y=980+row*105;const at=.2+i*.035;return <Cutout key={i} file="grid" clip={`inset(${y}px ${1080-x-55}px ${1920-y-65}px ${x}px)`} origin={`${x+28}px ${y+32}px`} style={{translate:`${mix(t,at,at+.6,0,(col-1.5)*8)}px ${mix(t,at,at+.6,100,0)-Math.sin(t*3+i)*7}px`,rotate:`${Math.sin(t*2+i)*6}deg`,opacity:mix(t,at,at+.25,0,1)}}/>})}
<Trace path="M 530 940 Q 460 800 400 760 L 300 660" opacity={t>=2.7?1:.25}/><Trace path="M 540 930 Q 580 800 650 690 L 740 620" phase={80} opacity={t>=4.1?1:.25}/>
{t>=7.52&&<><div style={{position:'absolute',left:600,top:230,width:140,height:250,background:C.navy,opacity:.9,rotate:'12deg'}}/><div style={{position:'absolute',left:605,top:270,color:C.cyan,fontFamily:'Display',fontSize:75,rotate:'12deg'}}>01</div><div style={{position:'absolute',left:600,top:385,color:C.cyan,fontFamily:'Display',fontSize:31,rotate:'12deg'}}>DECODE</div></>}
</div></SceneBase><Heading>{['A GRID OF DATA.','A WEB ADDRESS.','PAYMENT DETAILS.','DECODED ON YOUR PHONE.','THEN THE NETWORK.'][shot]}</Heading><Label>{shot<3?'DATA, NOT MAGIC.':shot===3?'LOCAL DECODING FIRST':'NETWORK ACTIVITY DEPENDS ON THE DATA AND APP'}</Label><Captions start={5}/></AbsoluteFill>};
