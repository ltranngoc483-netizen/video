import React from 'react';
import {AbsoluteFill,useCurrentFrame,useVideoConfig} from 'remotion';
import {C,SceneBase,Photo,Heading,Label,Captions,mix} from './Visuals';
export const OpticalLock=()=>{const f=useCurrentFrame();const {fps}=useVideoConfig();const t=Math.floor(f/2)*2/fps;const close=t>=3.025;return <AbsoluteFill style={{color:C.cream,fontFamily:'Body'}}><SceneBase>
<div style={{position:'absolute',inset:0,scale:close?1.48:1+mix(t,0,3,.015,.055),translate:close?'-155px -130px':'0px 0px',transformOrigin:'55% 48%'}}>
<Photo file="optical"/>
{[[345,710,1.08],[880,700,1.35],[340,1240,1.62]].map(([x,y,at],i)=><div key={i} style={{position:'absolute',left:x-106,top:y-108,width:212,height:214,border:`${mix(t,at,at+.15,0,6)}px solid ${C.cyan}`,opacity:mix(t,at,at+.12,0,1),boxShadow:`0 0 ${20+8*Math.sin(t*5)}px rgba(0,240,255,.5)`,scale:mix(t,at,at+.18,1.25,1),rotate:'-2deg'}}/>)}
<div style={{position:'absolute',left:200,right:45,top:mix(t,.12,1.05,485,1360),height:4,background:C.cyan,boxShadow:'0 0 24px #00F0FF',opacity:t<1.05?.85:0}}/>
</div>
</SceneBase><Heading>{close?'WHAT DID YOU JUST UNLOCK?':'ONE SCAN.'}</Heading><Label y={1390}>THREE FINDER PATTERNS</Label><Captions start={0}/></AbsoluteFill>};
