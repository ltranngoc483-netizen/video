from pathlib import Path
import json,subprocess
import numpy as np
import soundfile as sf
r=Path(__file__).resolve().parents[1];sr=48000;n=30*sr
vo=np.zeros(n);sfx=np.zeros(n);rng=np.random.default_rng(572)
data=json.loads((r/'scripts/narration.json').read_text())
for scene in data:
 x,rate=sf.read(r/'public'/f'{scene["id"]}.wav');assert rate==sr
 i=round(scene['start']*sr);length=min(len(x),n-i);vo[i:i+length]+=x[:length]
def add(at,x):
 i=round(at*sr);length=min(len(x),n-i)
 if length>0:sfx[i:i+length]+=x[:length]
def click(at,freq=1500,amp=.4,d=.075):
 t=np.arange(round(d*sr))/sr;x=(.35*rng.normal(size=len(t))+.65*np.sin(2*np.pi*freq*t))*np.exp(-t*65)*amp;add(at,x)
def bass(at,amp=.4,d=.6):
 t=np.arange(round(d*sr))/sr;add(at,np.sin(2*np.pi*(64*t-18*t*t))*np.exp(-t*7)*amp)
def paper(at,d=.22,amp=.22):
 t=np.arange(round(d*sr))/sr;z=rng.normal(size=len(t));hp=z-np.convolve(z,np.ones(24)/24,mode='same');add(at,hp*np.sin(np.pi*np.minimum(1,t/d))**2*np.exp(-t*7)*amp)
click(.12,1800,.6);bass(.18,.5)
for at in [1.08,1.35,1.62]:click(at,950,.65,.11)
for at in [3.025,5,7.75,9.2,10.72,12.52,15,17.08,19.4,21.33,25]:paper(at-.05);click(at,1400,.26)
for at in np.arange(5.3,7.5,.18):click(float(at),2200,.14,.05)
for at in [15.5,17.9,18.55,19.2,20.6]:click(at,740,.32,.12)
bass(15,.35);bass(21.33,.38);bass(25,.5);paper(25.2,.35,.3)
for at in [26.2,27.3]:bass(at,.2,.35)
t=np.arange(round(.35*sr))/sr;add(20.65,.18*(np.sin(2*np.pi*660*t)+.5*np.sin(2*np.pi*990*t))*np.exp(-t*12));bass(29.35,.4,.65)
sf.write(r/'public/narration.wav',vo,sr);sf.write(r/'public/sound-design.wav',sfx,sr)
raw=r/'out/mix-raw.wav';sf.write(raw,vo+.24*sfx,sr,subtype='FLOAT')
subprocess.run(['ffmpeg','-y','-v','error','-i',str(raw),'-af','alimiter=limit=0.95:level=0:latency=1','-ar','48000',str(r/'out/final-audio.wav')],check=True)
caps=json.loads((r/'src/captions.json').read_text())
def tc(ms):
 ms=round(ms);return f'{ms//3600000:02}:{ms//60000%60:02}:{ms//1000%60:02},{ms%1000:03}'
(r/'out/qr-short-en.srt').write_text('\n\n'.join(f'{i+1}\n{tc(c["startMs"])} --> {tc(c["endMs"])}\n{c["text"]}' for i,c in enumerate(caps))+'\n')
print('30-second audio mix and 16-cue SRT ready')
