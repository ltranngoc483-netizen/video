# TECH UNMASKED — Bút ghi âm 150K
## Style Prompt
Photographed handcrafted 3D cardboard dioramas, thick torn edges, masking tape, deep shadows. Navy #0A192F, cyan #00F0FF audio, cream #F2ECDD labels and red #E55441 friction noise. Stop-motion at 15 poses per second with fast paper wipes.
## Typography
DejaVu Sans Bold Display, DejaVu Sans Body and DejaVu Sans Mono for method notes; local full Vietnamese coverage. Headlines 77px, labels 37–65px, fine print 27px. Right 180px and bottom 330px reserved for Shorts overlays.
## What NOT to Do
No invented battery capacities, measured test recordings, verified 48-hour operation, or claims about every cheap recorder. Cyan is a sound metaphor, never a real scanner. All hardware is an illustrative model.
