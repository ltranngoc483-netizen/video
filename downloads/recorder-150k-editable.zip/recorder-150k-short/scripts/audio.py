from pathlib import Path
import json,subprocess
import numpy as np
import soundfile as sf
r=Path(__file__).resolve().parents[1];sr=48000;n=30*sr;rng=np.random.default_rng(150707)
music=np.zeros(n);sfx=np.zeros(n)
def add(at,x):
 i=round(at*sr);k=min(len(x),n-i)
 if k>0:sfx[i:i+k]+=x[:k]
def click(at,freq=1300,amp=.18,d=.1):
 t=np.arange(round(d*sr))/sr;add(at,(.35*rng.normal(size=len(t))+.65*np.sin(2*np.pi*freq*t))*np.exp(-t*65)*amp)
def bass(at,amp=.3,d=.7):
 t=np.arange(round(d*sr))/sr;add(at,np.sin(2*np.pi*(63*t-14*t*t))*np.exp(-t*7)*amp)
def paper(at,d=.25,amp=.16):
 t=np.arange(round(d*sr))/sr;z=rng.normal(size=len(t));z-=np.convolve(z,np.ones(24)/24,mode='same');add(at,z*np.sin(np.pi*t/d)**2*np.exp(-t*7)*amp)
def beep(at,freq=700,d=.12,amp=.09):
 t=np.arange(round(d*sr))/sr;add(at,np.sin(2*np.pi*freq*t)*np.sin(np.pi*t/d)**2*amp)
for beat in np.arange(0,29.5,.75):
 freq=[55,51.913,48.999,55][int(beat//7.5)%4];t=np.arange(round(.55*sr))/sr;i=round(beat*sr);k=min(len(t),n-i)
 music[i:i+k]+=.018*(np.sin(2*np.pi*freq*t[:k])+.25*np.sin(2*np.pi*freq*2*t[:k]))*np.exp(-t[:k]*5)
click(.15,900,.3);bass(.2,.3);paper(.4)
for at in [1.7,3.5,5,7,9,11,13,15,17.5,20,22.5,25]:paper(max(0,at-.05),.22);click(at,1500,.13)
paper(5.05,.45,.23)
for at in [5.2,5.4,5.6,7.15,9.15,11.15]:click(at,1700,.1,.07)
# Synthetic fabric contact: an illustrative effect, not a hardware test recording.
for at,d,amp in [(15.85,.32,.19),(16.3,.45,.13),(17.6,.5,.12),(18.6,.6,.1)]:
 t=np.arange(round(d*sr))/sr;z=rng.normal(size=len(t));z=np.convolve(z,np.ones(10)/10,mode='same');add(at,z*np.sin(np.pi*t/d)**2*(1+.4*np.sin(t*150))*amp)
bass(15.9,.3);beep(22.55,560,.13,.13);beep(22.8,360,.16,.1)
paper(25,.38,.25);bass(25,.38);paper(25.35,.25,.18);bass(26.1,.18,.4);bass(27.6,.18,.4);bass(29.25,.25,.7)
fade=np.minimum(1,(np.arange(n)[::-1]/sr)/.45);music*=fade;sfx*=fade
for filename,data in [('music-bed.wav',music),('sfx-only.wav',sfx),('sound-design.wav',np.tanh((music+sfx)*1.15)*.85)]:sf.write(r/'public'/filename,data,sr,subtype='PCM_16')
caps=json.loads((r/'src/captions.json').read_text())
def tc(t):
 ms=round(t*1000);return f'{ms//3600000:02}:{ms//60000%60:02}:{ms//1000%60:02},{ms%1000:03}'
(r/'out/recorder-150k-vi-timing-draft.srt').write_text('\n\n'.join(f'{i+1}\n{tc(c["start"])} --> {tc(c["end"])}\n{c["text"]}' for i,c in enumerate(caps))+'\n')
print('30s mix + separated SFX/music and 13-cue draft SRT; no voice')
