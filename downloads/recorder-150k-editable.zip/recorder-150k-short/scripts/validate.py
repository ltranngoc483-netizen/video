from pathlib import Path
import json,subprocess,re
import numpy as np
import soundfile as sf
r=Path(__file__).resolve().parents[1];p=r/'out/recorder-150k-30s-hinh-sfx.mp4'
meta=json.loads(subprocess.check_output(['ffprobe','-v','error','-show_entries','format=duration,size:stream=codec_name,codec_type,width,height,r_frame_rate,nb_frames','-of','json',str(p)]))
v=next(s for s in meta['streams'] if s['codec_type']=='video');a=next(s for s in meta['streams'] if s['codec_type']=='audio')
assert (v['width'],v['height'],v['r_frame_rate'],v['nb_frames'])==(1080,1920,'30/1','900')
assert v['codec_name']=='h264' and a['codec_name']=='aac'
assert abs(float(meta['format']['duration'])-30)<.05
subprocess.run(['ffmpeg','-v','error','-i',str(p),'-f','null','-'],check=True)
subprocess.run(['ffmpeg','-y','-v','error','-i',str(p),'-vn','-ar','16000','-ac','1',str(r/'out/check-audio.wav')],check=True)
y,sr=sf.read(r/'out/check-audio.wav');peak=float(np.max(np.abs(y)));assert .05<peak<.99
caps=json.loads((r/'src/captions.json').read_text());assert len(caps)==13 and caps[0]['start']==0 and caps[-1]['end']==30
for i,c in enumerate(caps):
 assert c['start']<c['end']<=30
 if i:assert c['start']>=caps[i-1]['end']
(r/'out/validation.json').write_text(json.dumps({'file':p.name,'metadata':meta,'audioPeak':peak,'cueCount':len(caps),'narration':False,'srt':'editorial timing draft'},indent=2))
print('PASS: 30.00s, 900 frames,1080x1920,H264/AAC, full decode, audio peak',round(peak,3),'13 draft SRT cues')
