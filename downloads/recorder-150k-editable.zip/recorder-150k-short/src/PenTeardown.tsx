import React from 'react';import {CanvasImage,staticFile,useCurrentFrame,useVideoConfig} from 'remotion';import {Art,Base,Title,Tag,Fine,Ring,stepped,C} from './RecorderVisuals';
export const PenTeardown=()=>{const f=useCurrentFrame();const {fps}=useVideoConfig();const t=stepped(f,fps);const shot=t<2?0:t<4?1:t<6?2:t<8?3:4;const labels=['BÓC VỎ','MICRO','PIN TÍ HON','CHIP / BỘ NHỚ','PHẢI KIỂM TRA TỪNG MẪU'];const xs=[540,340,720,490,540],ys=[970,790,1160,1050,950];const scale=shot===0||shot===4?1+t*.008:1.3+(t%2)*.04;return <Base chapter="02 / MỔ XẺ">
<Art file="teardown" style={{scale,translate:shot===1?'120px 100px':shot===2?'-180px -80px':shot===3?'20px 0':'0 0',transformOrigin:'50% 50%'}}/>
<Title>BÊN TRONG<br/>CÓ GÌ?</Title><Tag top={1375} large={shot<4} key={shot} at={shot*2}>{labels[shot]}</Tag>
{shot===3?<Ring key={shot} x={670} y={1005} at={shot*2}/>:null}
<div style={{position:'absolute',left:shot===2?620:230,top:shot===2?790:940,width:230,height:230,border:`17px solid ${C.cream}`,borderRadius:'50%',boxShadow:'10px 15px 15px #0009',opacity:shot===1||shot===2?1:0,rotate:`${-15+t*2}deg`}}><div style={{position:'absolute',left:170,top:180,width:42,height:150,background:C.cream,rotate:'-35deg'}}/><div style={{overflow:'hidden',position:'absolute',inset:0,borderRadius:'50%'}}><CanvasImage src={staticFile('teardown.png')} style={{position:'absolute',width:1458,height:2592,left:shot===2?-1107:-378,top:shot===2?-1073:-1255}}/></div></div>
<Fine top={1565}>Dung lượng pin? Lọc ồn?<br/>Chưa đo thử thì chưa thể kết luận.</Fine>
</Base>};
