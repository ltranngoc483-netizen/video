import React from 'react';import {useCurrentFrame,useVideoConfig} from 'remotion';import {Art,Base,Title,Tag,Fine,Wave,Ring,stepped} from './RecorderVisuals';
export const PenHook=()=>{const f=useCurrentFrame();const {fps}=useVideoConfig();const t=stepped(f,fps);const shot=t<1.7?0:t<3.5?1:2;return <Base chapter="01 / QUẢNG CÁO">
<Art file="hook" style={{scale:shot===0?1+t*.045:shot===1?1.22+(t-1.7)*.04:1.42+(t-3.5)*.04,translate:shot===0?'0 0':shot===1?'-100px 30px':'-155px 140px',transformOrigin:'60% 43%'}}/>
<Title>BÚT GHI ÂM<br/>150K?</Title><Tag top={1315} large at={.32}>150.000Đ</Tag><Tag top={1460} at={1.7} red width={760}>XUYÊN TƯỜNG? · 48 GIỜ?</Tag>
<Wave top={1050} amp={.35} width={540} at={.5}/><Ring x={674} y={730} at={2}/><Fine top={1575}>Lời quảng cáo cần kiểm chứng.<br/>Sóng cyan là hiệu ứng minh họa âm thanh.</Fine>
</Base>};
