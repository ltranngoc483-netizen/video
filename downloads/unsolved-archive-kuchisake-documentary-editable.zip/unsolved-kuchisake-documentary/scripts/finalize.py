from pathlib import Path
import json,subprocess
r=Path(__file__).resolve().parents[1];story=json.loads((r/'src/scenes.json').read_text());files=[]
for s in story:
 p=r/'out/clips'/f'scene-{s["id"]:02d}.mp4';assert p.with_suffix('.done').exists(),s['id']
 d=json.loads(subprocess.check_output(['ffprobe','-v','error','-show_entries','format=duration:stream=codec_type,width,height,r_frame_rate,nb_frames','-of','json',str(p)],text=True));v=next(x for x in d['streams'] if x['codec_type']=='video')
 assert (v['width'],v['height'],v['r_frame_rate'],int(v['nb_frames']))==(1920,1080,'30/1',s['duration']*30),s['id']
 assert abs(float(d['format']['duration'])-s['duration'])<.05,s['id'];files.append(f"file '{p}'")
concat=r/'out/concat.txt';concat.write_text('\n'.join(files)+'\n')
out=r/'out/unsolved-archive-kuchisake-full-11min-1080p.mp4'
subprocess.run(['ffmpeg','-y','-v','warning','-f','concat','-safe','0','-i',str(concat),'-i',str(r/'out/full-audio.wav'),'-map','0:v:0','-map','1:a:0','-c:v','copy','-c:a','aac','-b:a','128k','-t','660','-movflags','+faststart',str(out)],check=True)
assert out.stat().st_size<100*1024*1024,out.stat().st_size
print('FULL 11-MINUTE MP4 COMPLETE:',out.stat().st_size,'bytes',flush=True)
