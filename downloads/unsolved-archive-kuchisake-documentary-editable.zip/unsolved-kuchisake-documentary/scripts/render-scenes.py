from pathlib import Path
import json,subprocess,concurrent.futures,time,sys,os,threading
r=Path(__file__).resolve().parents[1];os.chdir(r);scenes=json.loads((r/'src/scenes.json').read_text());caps=json.loads((r/'src/captions.json').read_text());(r/'out/captions').mkdir(exist_ok=True)
cache_lock=threading.Lock();(r/'out/raw-cache').mkdir(exist_ok=True)
def raw_input(src,w=1920,h=1080):
 out=r/'out/raw-cache'/(src.stem+'.rgba')
 with cache_lock:
  if not out.exists() or out.stat().st_size!=w*h*4:
   tmp=out.with_suffix('.tmp');subprocess.run(['ffmpeg','-y','-v','error','-i',str(src),'-vf',f'scale={w}:{h}:force_original_aspect_ratio=increase,crop={w}:{h}','-frames:v','1','-pix_fmt','rgba','-f','rawvideo',str(tmp)],check=True);tmp.replace(out)
 return ['-stream_loop','-1','-f','rawvideo','-pixel_format','rgba','-video_size',f'{w}x{h}','-framerate','12','-i',str(out)]
def stamp(ms):
 cs=round(ms/10);return f'{cs//360000}:{cs//6000%60:02}:{cs//100%60:02}.{cs%100:02}'
def ass(s):
 text='''[Script Info]
ScriptType: v4.00+
PlayResX: 1920
PlayResY: 1080
WrapStyle: 0
ScaledBorderAndShadow: yes
[V4+ Styles]
Format: Name, Fontname, Fontsize, PrimaryColour, SecondaryColour, OutlineColour, BackColour, Bold, Italic, Underline, StrikeOut, ScaleX, ScaleY, Spacing, Angle, BorderStyle, Outline, Shadow, Alignment, MarginL, MarginR, MarginV, Encoding
Style: Caption,DejaVu Sans,40,&H00DDECF2,&H00DDECF2,&H001A0D03,&H601A0D03,-1,0,0,0,100,100,0,0,3,10,2,2,160,160,95,1
Style: Progress,DejaVu Sans,1,&H00FFF000,&H00FFF000,&H00FFF000,&H00FFF000,0,0,0,0,100,100,0,0,1,0,0,7,0,0,0,1
[Events]
Format: Layer, Start, End, Style, Name, MarginL, MarginR, MarginV, Effect, Text
'''
 for c in caps:
  if s['start']*1000<=c['startMs']<(s['start']+s['duration'])*1000:
   content=c['text'].replace('\\','\\\\').replace('{','\\{').replace('}','\\}')
   text+=f'Dialogue: 2,{stamp(c["startMs"]-s["start"]*1000)},{stamp(c["endMs"]-s["start"]*1000)},Caption,,0,0,0,,{content}\n'
 for sec in range(s['duration']):
  w=round(1770*(s['start']+sec+1)/660);text+=f'Dialogue: 1,{stamp(sec*1000)},{stamp((sec+1)*1000)},Progress,,0,0,0,,{{\\an7\\pos(75,1045)\\p1}}m 0 0 l {w} 0 {w} 3 0 3\n'
 p=r/'out/captions'/f'{s["id"]:02d}.ass';p.write_text(text);return p
def pose(l,d):
 delay=l['delay'];p=f'clip((t-{delay})/.4,0,1)';q=f'clip((t-{delay})/{max(.1,d-delay)},0,1)';end='0' if l.get('exitAt') is None else f'clip((t-{l["exitAt"]})/.4,0,1)'
 return f'{l["entryX"]}*(1-({p}))+{l["dx"]}*({q})+600*({end})',f'{l["entryY"]}*(1-({p}))+{l["dy"]}*({q})+180*({end})'
def render(s):
 tag=f'{s["id"]:02d}';out=r/'out/clips'/f'scene-{tag}.mp4';done=out.with_suffix('.done')
 if done.exists() and out.exists():print('Reused scene',tag,flush=True);return
 d=s['duration'];args=['ffmpeg','-y','-v','error','-filter_complex_threads','1']+raw_input(r/'public'/f'{s["background"]}.png')
 for k in range(len(s['layers'])):args+=raw_input(r/'out/layers'/f'{tag}-{k}.png')
 hud=len(s['layers'])+1;wipe=hud+1;args+=raw_input(r/'out/layers'/f'{tag}-hud.png')+raw_input(r/'out/layers/wipe.png',2300,1080)
 filters=['[0:v]scale=1920:1080:force_original_aspect_ratio=increase,crop=1920:1080,setsar=1,format=rgba[v0]'];prev='v0'
 for k,l in enumerate(s['layers']):
  f=f'[{k+1}:v]format=rgba,fade=t=in:st={l["delay"]}:d=0.4:alpha=1'
  if l.get('exitAt') is not None:f+=f',fade=t=out:st={l["exitAt"]}:d=0.4:alpha=1'
  f+=f'[l{k}]';filters.append(f);x,y=pose(l,d);nxt=f'v{k+1}';filters.append(f"[{prev}][l{k}]overlay=x='{x}':y='{y}':shortest=1:format=auto[{nxt}]");prev=nxt
 z="if(lt(mod(on,180),36),1,if(lt(mod(on,180),72),1.10,if(lt(mod(on,180),108),1.03,if(lt(mod(on,180),144),1.12,1.04))))+.008*mod(on,36)/36"
 focus="if(lt(mod(on,180),36),.5,if(lt(mod(on,180),72),.56,if(lt(mod(on,180),108),.44,.5)))"
 filters.append(f"[{prev}]format=yuv420p,zoompan=z='{z}':x='(iw-iw/zoom)*({focus})':y='(ih-ih/zoom)*.52':d=1:s=1920x1080:fps=12[cam]")
 filters.append(f'[cam][{hud}:v]overlay=0:0:shortest=1:format=auto[headed]');ass(s)
 filters.append(f"[headed]subtitles=out/captions/{tag}.ass:fontsdir=public,format=yuv420p[capped]")
 intro="if(lt(t,.25),-200-2100*t/.25,-2600)" if s['id']!=1 else '-2600'
 wx=f"if(gte(t,{d}-.333333),1920-2120*clip((t-({d}-.333333))/.25,0,1),{intro})" if s['id']!=40 else intro
 filters.append(f"[capped][{wipe}:v]overlay=x='{wx}':y=0:shortest=1:format=auto,format=yuv420p[finished]")
 if s['id']==1:filters.append('[finished]fade=t=in:st=0:d=0.25:color=0x0A192F[final]')
 elif s['id']==40:filters.append(f'[finished]fade=t=out:st={d-.45}:d=0.45:color=0x0A192F[final]')
 else:filters.append('[finished]null[final]')
 filters.append('[final]fps=30[delivery]')
 filt=r/'out'/f'filter-{tag}.txt';filt.write_text(';\n'.join(filters))
 args+=['-filter_complex_script',str(filt),'-map','[delivery]','-t',str(d),'-frames:v',str(d*30),'-an','-r','30','-c:v','libx264','-preset','fast','-b:v','950k','-maxrate','1100k','-bufsize','2200k','-g','90','-threads','2','-pix_fmt','yuv420p','-movflags','+faststart',str(out)]
 started=time.monotonic();log=r/'out'/f'ffmpeg-{tag}.log'
 with log.open('w') as f:subprocess.run(args,stdout=f,stderr=f,check=True)
 done.write_text('complete');print('Rendered',tag,'/40 in',round(time.monotonic()-started,1),'s',flush=True)
if '--test' in sys.argv:
 render(next(s for s in scenes if not (r/'out/clips'/f'scene-{s["id"]:02d}.done').exists()));sys.exit()
pending=list(scenes);running={}
with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
 while pending or running:
  for future in list(running):
   if future.done():future.result();running.pop(future)
  ready=[s for s in pending if (r/'out/layers'/f'{s["id"]:02d}.done').exists()]
  while ready and len(running)<2:
   s=ready.pop(0);pending.remove(s);running[pool.submit(render,s)]=s['id']
  if pending or running:time.sleep(.5)
print('All forty 1080p scene clips complete',flush=True)
