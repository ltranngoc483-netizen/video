from pathlib import Path
import json,subprocess
import numpy as np,soundfile as sf
r=Path(__file__).resolve().parents[1];p=r/'out/unsolved-archive-kuchisake-full-11min-1080p.mp4';story=json.loads((r/'src/scenes.json').read_text());caps=json.loads((r/'src/captions.json').read_text())
d=json.loads(subprocess.check_output(['ffprobe','-v','error','-show_entries','format=duration,size:stream=codec_type,codec_name,width,height,r_frame_rate,nb_frames','-of','json',str(p)],text=True));v=next(x for x in d['streams'] if x['codec_type']=='video');a=next(x for x in d['streams'] if x['codec_type']=='audio')
assert (v['width'],v['height'],v['r_frame_rate'],int(v['nb_frames']))==(1920,1080,'30/1',19800)
assert v['codec_name']=='h264' and a['codec_name']=='aac';assert abs(float(d['format']['duration'])-660)<.05;assert len(story)==40 and sum(s['duration'] for s in story)==660
assert [s['start'] for s in story if s['id'] in [1,11,21,31]]==[0,150,330,510]
assert len(caps)==254 and all(0<=c['startMs']<c['endMs']<=660000 for c in caps)
subprocess.run(['ffmpeg','-v','error','-threads','2','-i',str(p),'-f','null','-'],check=True)
subprocess.run(['ffmpeg','-y','-v','error','-i',str(p),'-vn','-ar','16000','-ac','1',str(r/'out/decoded-audio.wav')],check=True)
x,sr=sf.read(r/'out/decoded-audio.wav',dtype='float32');peak=float(np.max(abs(x)));assert peak<1
levels=[]
for s in story:
 section=x[round((s['start']+.15)*sr):round((s['start']+s['duration']-.4)*sr)];rms=float(np.sqrt(np.mean(section**2)));assert rms>.01,(s['id'],rms);levels.append(rms)
assert p.stat().st_size<100*1024*1024
(r/'out/validation.json').write_text(json.dumps(dict(metadata=d,audioPeak=peak,scenes=40,captionCues=254,chapterStarts=[0,150,330,510],voice='Local US male Kokoro am_michael draft, not ElevenLabs Marcus',sceneRms=levels),indent=2))
print('PASS: 11:00, 19800 frames, 1920x1080 H264/AAC, full decode, forty audible scenes, 254 cues; peak',round(peak,3),flush=True)
