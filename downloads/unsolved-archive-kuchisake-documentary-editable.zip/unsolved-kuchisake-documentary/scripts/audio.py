from pathlib import Path
import json,subprocess
import numpy as np,soundfile as sf
r=Path(__file__).resolve().parents[1];story=json.loads((r/'src/scenes.json').read_text());caps=json.loads((r/'src/captions.json').read_text());sr=48000;rng=np.random.default_rng(1979)
with sf.SoundFile(r/'out/full-audio-raw.wav','w',samplerate=sr,channels=1,subtype='FLOAT') as out, sf.SoundFile(r/'public/ambience.flac','w',samplerate=sr,channels=1,subtype='PCM_16',format='FLAC') as ambience:
 for s in story:
  n=s['duration']*sr;t=np.arange(n,dtype=np.float32)/sr;vo=np.zeros(n,dtype=np.float32);x,rate=sf.read(r/'public'/f'voice-{s["id"]:02d}.wav',dtype='float32');assert rate==sr;vo[:min(n,len(x))]=x[:n]
  bed=(.006*np.sin(2*np.pi*(40+s['act']*2)*t)+.004*np.sin(2*np.pi*57.8*t))*(.6+.4*np.sin(t*1.2)**2);fx=np.zeros(n,dtype=np.float32)
  def add(at,x):
   i=round(at*sr);k=min(len(x),n-i)
   if k>0:fx[i:i+k]+=x[:k]
  def click(at,amp=.05,freq=1200):
   tt=np.arange(int(.08*sr))/sr;add(at,amp*(.4*rng.normal(size=len(tt))+.6*np.sin(2*np.pi*freq*tt))*np.exp(-tt*75))
  def paper(at,amp=.05):
   tt=np.arange(int(.24*sr))/sr;z=rng.normal(size=len(tt));z-=np.convolve(z,np.ones(24)/24,mode='same');add(at,amp*z*np.sin(np.pi*tt/.24)**2*np.exp(-tt*5))
  def bass(at,amp=.08):
   tt=np.arange(int(.65*sr))/sr;add(at,amp*np.sin(2*np.pi*(54*tt-10*tt*tt))*np.exp(-tt*6))
  paper(.10,.07);bass(.16,.08);paper(s['duration']-.32,.09)
  for k,l in enumerate(s['layers']):paper(min(s['duration']-.5,l['delay']+.05),.045);click(min(s['duration']-.5,l['delay']+.12),.04)
  if s['background'] in ['street','school','garden']:
   for at in np.arange(2,s['duration']-1,1.1):paper(float(at),.015)
  if s['id'] in [3,9,16,26,28,29]:
   for at in [2.2,2.5,2.8,3.1]:click(at,.04,1800)
  if s['id'] in [5,13,19,32,33,34]:
   tt=np.arange(int(.7*sr))/sr;add(s['duration']*.45,.035*np.sin(2*np.pi*1700*tt)*np.exp(-tt*6));paper(s['duration']*.48,.1)
  if s['id'] in [8,21,23,27]:
   tt=np.arange(int(1.2*sr))/sr;add(2,.035*(np.sin(2*np.pi*880*tt)+.4*np.sin(2*np.pi*1320*tt))*np.exp(-tt*4))
  y=vo+bed+fx
  if s['id']==40:y*=np.minimum(1,(s['duration']-t)/.4)
  out.write(y);ambience.write(bed+fx)
subprocess.run(['ffmpeg','-y','-v','error','-i',str(r/'out/full-audio-raw.wav'),'-af','alimiter=limit=0.95:level=0:latency=1','-ar','48000',str(r/'out/full-audio.wav')],check=True)
def tc(ms):
 ms=round(ms);return f'{ms//3600000:02}:{ms//60000%60:02}:{ms//1000%60:02},{ms%1000:03}'
(r/'out/kuchisake-documentary-en.srt').write_text('\n\n'.join(f'{i+1}\n{tc(c["startMs"])} --> {tc(c["endMs"])}\n{c["text"]}' for i,c in enumerate(caps))+'\n')
print('660-second narration/SFX mix and',len(caps),'SRT cues ready',flush=True)
