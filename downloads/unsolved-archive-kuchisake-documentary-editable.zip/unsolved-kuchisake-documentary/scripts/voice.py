from pathlib import Path
import os,json,re,subprocess
os.environ.setdefault('OMP_NUM_THREADS','3')
import numpy as np,soundfile as sf,onnxruntime as ort
from kokoro_onnx import Kokoro
r=Path(__file__).resolve().parents[1];story=json.loads((r/'src/story.json').read_text());opts=ort.SessionOptions();opts.intra_op_num_threads=3
session=ort.InferenceSession(str(r.parent/'.models/kokoro.onnx'),sess_options=opts,providers=['CPUExecutionProvider']);engine=Kokoro.from_session(session,str(r.parent/'.models/voices.bin'))
caps=[];reports=[]
pron={'Kuchisake-onna':'koo chee sah keh oh nah','Iikura':'Ee koo rah','Gifu':'Gee foo','Himeji':'hee meh jee','bekkōame':'beck koh ah meh','kagi-kko':'kah gee koh','onryō':'on ree oh','juku':'joo koo'}
for s in story:
 out=r/'public'/f'voice-{s["id"]:02d}.wav';meta=r/'out'/f'voice-{s["id"]:02d}.json'
 if out.exists() and meta.exists():
  m=json.loads(meta.read_text());caps+=m['captions'];reports.append(m['report']);print('Reused',s['id'],flush=True);continue
 parts=[p.strip() for p in re.split(r'(?<=[.!?])\s+|\.{3}\s*',s['text']) if p.strip()];chunks=[];lengths=[]
 for phrase in parts:
  spoken=phrase
  for a,b in pron.items():spoken=spoken.replace(a,b)
  x,sr=engine.create(spoken,voice='am_michael',speed=1.0,lang='en-us');active=np.flatnonzero(abs(x)>.006)
  if len(active):x=x[max(0,active[0]-int(.035*sr)):min(len(x),active[-1]+int(.055*sr))]
  x=np.concatenate([x,np.zeros(int(.075*sr))]);chunks.append(x);lengths.append(len(x)/sr)
 target=s['duration']-.28;tempo=sum(lengths)/target
 raw=r/'out'/f'voice-{s["id"]:02d}-raw.wav';sf.write(raw,np.concatenate(chunks),sr)
 subprocess.run(['ffmpeg','-y','-v','error','-i',str(raw),'-af',f'atempo={tempo:.9f},loudnorm=I=-18:TP=-3:LRA=7,apad,atrim=duration={target},afade=t=out:st={target-.025}:d=0.025','-ar','48000',str(out)],check=True)
 cursor=s['start'];local=[]
 for phrase,length in zip(parts,lengths):
  dur=length/tempo;words=phrase.split();groups=[words[i:i+10] for i in range(0,len(words),10)];cc=cursor
  for group in groups:
   gd=dur*len(group)/len(words);local.append(dict(text=' '.join(group),startMs=round(cc*1000),endMs=round((cc+gd-.025)*1000),timestampMs=round(cc*1000),confidence=None));cc+=gd
  cursor+=dur
 report=dict(scene=s['id'],sourceDuration=sum(lengths),tempo=tempo,target=target);meta.write_text(json.dumps(dict(captions=local,report=report),indent=2));caps+=local;reports.append(report);raw.unlink()
 print('Voice',s['id'],'/40',round(sum(lengths),2),'->',target,'tempo',round(tempo,3),flush=True)
(r/'src/captions.json').write_text(json.dumps(caps,ensure_ascii=False,indent=2));(r/'out/voice-report.json').write_text(json.dumps(reports,indent=2));print('40 scene voices complete;',len(caps),'caption cues',flush=True)
