from pathlib import Path
import json
r=Path(__file__).resolve().parents[1];story=json.loads((r/'src/story.json').read_text());caps=json.loads((r/'src/captions.json').read_text())
titles=['THE FEAR WAS REAL','REPORTED RUMOR · LATE 1978','A PUBLISHED RUMOR','A DESCRIPTION THAT CHANGES','AM I PRETTY?','EVEN LIKE THIS?','A STORY CROSSES JAPAN','THE WALK HOME','BUILT BY RETELLING','A DIFFERENT ORIGIN STORY','A FEUDAL HOUSEHOLD','BETRAYAL — IN THE LEGEND','A PORTRAIT TORN IN TWO','WHO CONTROLS THE FACE?','ONRYŌ: A LITERARY LENS','NO VERIFIED HISTORICAL LINK','A MOTIF IS NOT A FAMILY TREE','THREE STORIES. NO PROVEN CAUSE.','AN ORDINARY MASK','WHY 1979?','THE EVENING JOURNEY','KAGI-KKO: SOCIAL CONTEXT','JUKU: CONNECTING NEIGHBORHOODS','FEAR AFTER DARK','EACH RETELLING ADDS A DETAIL','THE FEEDBACK LOOP','PRECAUTION IS NOT PROOF','A REPORTED HUMAN IMITATOR','THE RUMOR LOSES FORCE','A SHARED EXPECTATION OF DANGER','THE FIRST QUESTION','THE RULES CHANGE','THE YES BRANCH','THE NO BRANCH','THE SO-SO LOOPHOLE','BEKKŌAME','POMADE. POMADE. POMADE.','THE RULES WERE NEVER FIXED','A NEW DELIVERY SYSTEM','THE FACE WE GAVE TO FEAR']
def card(text,x=130,y=310,w=760,h=230,sub='',**kw):return dict(kind='card',text=text,sub=sub,x=x,y=y,w=w,h=h,delay=.3,entryX=-150,entryY=35,dx=8,dy=-12,rot=-2,**kw)
def prop(asset,x=1050,y=300,w=650,**kw):return dict(kind='prop',asset=asset,x=x,y=y,w=w,h=500,delay=.5,entryX=120,entryY=60,dx=-25,dy=-12,rot=0,**kw)
def photo(file='close-masked',x=1080,y=190,w=720,h=650,**kw):return dict(kind='photo',file=file,x=x,y=y,w=w,h=h,delay=.15,entryX=70,entryY=0,dx=-15,dy=0,rot=1,**kw)
def diagram(mode,x=230,y=230,w=1460,h=600,**kw):return dict(kind='diagram',mode=mode,x=x,y=y,w=w,h=h,delay=.3,entryX=0,entryY=70,dx=0,dy=-8,rot=0,**kw)
def change(o,**kw):return dict(o,**kw)
def cue(s,needle,default):
 for c in caps:
  if s['start']*1000<=c['startMs']<(s['start']+s['duration'])*1000 and needle.lower() in c['text'].lower():return max(.15,c['startMs']/1000-s['start'])
 return default
scenes=[]
for s,title in zip(story,titles):
 i=s['id'];bg='archive';label='ILLUSTRATED RECONSTRUCTION';layers=[]
 if i==1:bg='street';layers=[change(prop('woman',1190,230,360),delay=.2,entryX=-130,dx=35,dy=30),card('JAPAN · 1979',140,310,830,220,sub='THE FEAR WAS REAL. THE APPARITION WAS UNVERIFIED.'),change(prop('car',170,670,560),delay=2,entryX=-650,dx=300,dy=0)]
 elif i==2:bg='garden';label='REPORTED RUMOR · RECONSTRUCTION';layers=[change(prop('woman',1280,240,280),delay=2,entryX=-40,dx=15,dy=0),card('LATE 1978',180,340,720,210,sub='GIFU · WITNESS STORY UNCONFIRMED')]
 elif i==3:label='LIBRARY REFERENCE · PUBLICATION ≠ PARANORMAL PROOF';layers=[card('JANUARY 26, 1979',180,290,1040,260,sub='A NEWSPAPER REFERENCE TO A RUMOR'),prop('reel',1230,480,440)]
 elif i==4:label='CONFLICTING RUMOR DESCRIPTIONS · NOT AN IDENTIFIED PERSON';layers=[photo(),card('LONG HAIR · MASK',130,310,780,210,sub='BEIGE OR RED COAT?'),change(card('175 CM?',280,590,530,170,sub='ONE RUMORED MEASUREMENT'),delay=4)]
 elif i==5:bg='street';label='FOLKLORE ENCOUNTER · NO VERIFIED ATTACK';layers=[photo('close-unmasked'),card('AM I PRETTY?',130,350,790,190,sub='THE FIRST QUESTION'),change(prop('mask',1180,630,500),delay=0,entryX=0,entryY=0,dx=0,dy=0,exitAt=s['duration']*.58)]
 elif i==6:bg='decision';label='LEGEND VERSIONS DIFFER';layers=[card('YES',230,330,480,170),change(card('NO',1180,330,480,170),delay=2,entryX=140),change(card('EVEN LIKE THIS?',550,600,820,180),delay=4)]
 elif i==7:label='ILLUSTRATIVE RUMOR NETWORK · NOT VERIFIED SIGHTINGS';layers=[diagram('map'),change(prop('telephone',1370,560,360),delay=4),change(card('GIFU → OTHER COMMUNITIES',110,260,650,180),delay=.6)]
 elif i==8:bg='school';layers=[change(prop('escort',600,330,780),delay=.4,entryY=90,dx=0,dy=-65),change(prop('car',130,650,480),delay=3,entryX=-520,dx=200,dy=0)]
 elif i==9:label='CONTRADICTORY DETAILS WITHIN THE LEGEND';layers=[prop('scissors',1060,350,650),card('SCISSORS? SICKLE?',150,310,800,220,sub='FASTER THAN ANY RUNNER?'),change(card('ORIGINAL INCIDENT: UNVERIFIED',300,610,1050,150),delay=5)]
 elif i==10:bg='feudal';label='A LATER-ASSOCIATED ORIGIN LEGEND';layers=[photo('origin',110,240,700,610),card('AN OLDER STORY',950,470,760,230,sub='A HISTORICAL FOUNDATION?')]
 elif i==11:bg='feudal';label='FOLKLORE DRAMATIZATION';layers=[card('WIFE? CONCUBINE?',160,500,820,220,sub='DETAILS CHANGE BETWEEN TELLINGS')]
 elif i==12:bg='feudal';label='UNVERIFIED LEGEND · SYMBOLIC RECONSTRUCTION';layers=[card('BETRAYAL',150,460,780,260,sub='AN ACCUSATION WITHIN THE STORY')]
 elif i==13:bg='feudal';label='SYMBOLIC PAPER PORTRAIT · NO REALISTIC INJURY';layers=[change(photo('close-unmasked',1080,190,700,650),dx=40,dy=5),card('A FACE TORN IN TWO',130,370,800,250,sub='THE LEGEND’S CENTRAL CRUELTY')]
 elif i==14:bg='feudal';label='LITERARY INTERPRETATION';layers=[photo('close-unmasked',1100,200,650,620),diagram('mirror',120,280,860,450)]
 elif i==15:bg='feudal';label='ONRYŌ: FOLKLORE ARCHETYPE · NOT PROOF OF AN ORIGIN';layers=[change(prop('woman',1200,200,370),delay=1,entryY=130,dx=-20,dy=-45),card('ONRYŌ',170,360,780,270,sub='RESENTMENT · A VENGEFUL SPIRIT ARCHETYPE')]
 elif i==16:label='NO ESTABLISHED CHAIN OF HISTORICAL EVENTS';layers=[diagram('timelines'),change(card('NO VERIFIED LINK',490,640,980,150),delay=5)]
 elif i==17:label='RESEMBLANCE ≠ PROVEN DIRECT DESCENT';layers=[photo('origin',180,220,690,620),change(photo('close-masked',1080,220,650,620),delay=2),card('OLDER MOTIF',230,720,560,120),change(card('MODERN CONFIGURATION',1120,720,600,120),delay=2)]
 elif i==18:label='COMPETING ORIGIN STORIES · NONE CONFIRMED AS THE FIRST CAUSE';layers=[card('SAMURAI',120,350,510,250,sub='FOLKLORE'),change(card('SURGERY',710,350,510,250,sub='ANOTHER VERSION'),delay=1.7),change(card('UNKNOWN',1300,350,510,250,sub='NO HUMAN PAST'),delay=3.4)]
 elif i==19:bg='street';label='THE FAMILIAR BECOMES UNCANNY · SYMBOLIC VISUAL';layers=[prop('mask',280,330,820),change(prop('scissors',1100,520,540),delay=3)]
 elif i==20:bg='school';label='SHIFTING FROM ORIGIN LEGEND TO SOCIAL CONTEXT';layers=[photo('origin',130,240,680,610),card('WHY 1979?',980,430,730,240,sub='THE SOCIETY THAT CARRIED THE RUMOR')]
 elif i==21:bg='school';label='LATE-1970s SOCIAL SETTING · RECONSTRUCTION';layers=[diagram('schedules',180,300,1450,420)]
 elif i==22:bg='garden';label='POSSIBLE SOCIAL ANXIETY · NOT A PROVEN UNIVERSAL CAUSE';layers=[prop('key',1120,400,600),card('KAGI-KKO',150,350,800,250,sub='CHANGING FAMILY SCHEDULES')]
 elif i==23:bg='classroom';label='COMMUNICATION BETWEEN SCHOOL DISTRICTS';layers=[diagram('juku')]
 elif i==24:bg='street';label='PSYCHOLOGICAL INTERPRETATION · NO CONFIRMED STRANGER ATTACK';layers=[change(prop('woman',1270,230,350),delay=4,entryX=0,dx=-30,dy=20,opacity=.4),card('AN UNFAMILIAR ADULT',140,340,900,260,sub='ANXIETY GIVEN A VISIBLE SHAPE')]
 elif i==25:bg='classroom';label='RUMOR MUTATION · NOT A DOCUMENTED INCIDENT';layers=[prop('scissors',260,390,400),change(prop('scissors',850,350,590),delay=2.5),change(prop('scissors',1320,300,570),delay=5),card('ONE DETAIL BECOMES ANOTHER',330,650,1200,130)]
 elif i==26:label='MEDIA FEEDBACK LOOP · ILLUSTRATIVE DIAGRAM';layers=[diagram('feedback'),prop('telephone',115,470,450),change(prop('phone',1410,380,430),delay=3)]
 elif i==27:bg='school';label='SAFETY PRECAUTIONS ≠ CONFIRMATION OF A GHOST';layers=[prop('escort',650,340,730),change(prop('car',100,630,500),delay=2,entryX=-550,dx=200),card('PRECAUTION IS NOT PROOF',190,270,1040,170)]
 elif i==28:label='SECONDARY ACCOUNT · PRIMARY RECORD NOT ESTABLISHED HERE';layers=[card('REPORTED IMITATOR',210,340,1150,300,sub='HIMEJI · 1979 · AN ALLEGATION ABOUT A HUMAN'),change(card('NOT THE APPARITION',640,650,1050,140),delay=6)]
 elif i==29:bg='school';label='LIBRARY-REFERENCED REPORTING · LOCAL DECLINE, NOT A NATIONAL END DATE';layers=[prop('calendar',180,280,650),card('JUNE 15, 1979',930,360,820,230,sub='REPORTING THAT THE DISTURBANCE WAS SUBSIDING LOCALLY')]
 elif i==30:bg='classroom';label='SYMBOLIC VISUAL · A SHARED EXPECTATION OF DANGER';layers=[change(prop('woman',1220,170,400),opacity=.2,entryX=0,dx=10,dy=-30),prop('mask',440,560,800)]
 elif i==31:bg='street';label='WITHIN THE LEGEND';layers=[prop('woman',1190,210,370),card('AM I PRETTY?',140,350,850,210,sub='THE FIRST QUESTION')]
 elif i==32:bg='street';label='FOLKLORE REVEAL · CYAN PAPER SEAM, NOT A REAL WOUND';layers=[photo('close-unmasked'),card('EVEN LIKE THIS?',130,350,830,220),change(prop('mask',1180,630,500),delay=0,entryX=0,entryY=0,dx=0,dy=0,exitAt=s['duration']*.45)]
 elif i==33:bg='decision';label='ONE VARIANT · FICTIONAL CONSEQUENCES';layers=[card('YES',160,350,670,220,sub='AGREEING DOES NOT ENSURE SAFETY'),change(prop('scissors',1060,390,690),delay=3)]
 elif i==34:bg='decision';label='OTHER VARIANTS · NOT VERIFIED SURVIVAL ADVICE';layers=[card('NO',170,350,680,220,sub='HONESTY OR AGREEMENT?'),change(card('THE TRAP RESETS',1000,540,760,180),delay=3)]
 elif i==35:bg='decision';label='A STORYTELLING LOOPHOLE · SOME VERSIONS ONLY';layers=[card('SO-SO',360,380,1150,250,sub='NEITHER BEAUTIFUL NOR UGLY')]
 elif i==36:bg='decision';label='BEKKŌAME: A DETAIL IN SOME TELLINGS, NOT A PROTECTIVE MEASURE';layers=[prop('candy',1050,380,730),card('BEKKŌAME',150,360,780,240,sub='AMBER-COLORED HARD CANDY')]
 elif i==37:bg='decision';label='POMADE IS A HAIR PRODUCT · THE RULE IS FICTIONAL';layers=[prop('pomade',1170,300,500),card('POMADE',150,280,720,170),change(card('POMADE',260,470,720,170),delay=2),change(card('POMADE',370,660,720,150),delay=4)]
 elif i==38:bg='decision';label='THE RULES CHANGE BETWEEN REGIONS AND RETELLINGS';layers=[card('YES / NO',170,300,660,180),change(card('SO-SO',1070,300,650,180),delay=1),change(card('CANDY / POMADE',440,570,1050,220,sub='CONTRADICTORY PATHS'),delay=3)]
 elif i==39:label='CONTEMPORARY MEDIA · FICTIONAL POSTS';layers=[prop('phone',1190,230,570),card('A NEW DELIVERY SYSTEM',150,350,890,270,sub='FILMS · GAMES · ILLUSTRATIONS · ONLINE STORIES')]
 elif i==40:label='THE EVIDENCE CONCERNS HUMAN FEAR AND RUMOR';layers=[prop('mask',1050,420,700),card('THE UNSOLVED ARCHIVE',120,320,980,310,sub='KUCHISAKE-ONNA · FEAR, REPETITION, IMAGINATION')]
 for k,l in enumerate(layers):
  l['name']=f'Scene {i:02d} layer {k+1}';l.setdefault('opacity',1);l.setdefault('exitAt',None)
 scenes.append(dict(s,title=title,background=bg,label=label,layers=layers))
(r/'src/scenes.json').write_text(json.dumps(scenes,ensure_ascii=False,indent=2))
assets={
 'mask':dict(file='props1',top=0,bottom=.25),'scissors':dict(file='props1',top=.25,bottom=.52),'candy':dict(file='props1',top=.52,bottom=.70),'pomade':dict(file='props1',top=.70,bottom=1),
 'car':dict(file='props2',top=0,bottom=.25),'telephone':dict(file='props2',top=.25,bottom=.51),'reel':dict(file='props2',top=.51,bottom=.77),'key':dict(file='props2',top=.77,bottom=1),
 'woman':dict(file='woman',top=0,bottom=1),'escort':dict(file='escort-group',top=.32,bottom=.70),'phone':dict(file='phone-calendar',top=0,bottom=.53),'calendar':dict(file='phone-calendar',top=.53,bottom=1)}
(r/'src/assets.json').write_text(json.dumps(assets,indent=2))
print('Forty scene layouts:',sum(len(s['layers']) for s in scenes),'independent foreground layers')
