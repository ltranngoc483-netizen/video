THE INVISIBLE WORLD — KUCHISAKE-ONNA
Four labelled PNG images, 1080 x 1920 each.
01 encounter 0–5 seconds
02 unverified origin legend 5–15 seconds
03 illustrated 1979 rumor panic/community escorts 15–25 seconds
04 qualified folklore rule and Related Video CTA 25–30 seconds

The samurai-wife story is an unverified legend. Newspaper-like sheets are modern illustrative graphics, not archival documents. 'Don't answer directly' is explicitly only advice in some versions, not a universal survival rule or evidence of a ghost.

The full MP4 has independent paper-figure, mask, page and scroll movement plus captions and sound. These PNGs are still hero artwork for CapCut. Narrator in the draft MP4 is local US male Kokoro am_michael, not ElevenLabs Marcus. Attach an actual matching long video in YouTube Studio before publishing the Related Video CTA.
