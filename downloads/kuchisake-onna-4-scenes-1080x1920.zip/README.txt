THE UNSOLVED ARCHIVE — KUCHISAKE-ONNA
Four labelled PNGs, 1080 x 1920 each. Channel name updated in all four images and the Related Video CTA.
01 encounter: 0–5s
02 unverified origin legend: 5–15s
03 illustrated 1979 rumor panic and community escorts: 15–25s
04 qualified folklore rule and Related Video CTA: 25–30s

Narration and editorial timing are unchanged. The draft MP4 uses local US male Kokoro am_michael, not Marcus. The samurai-wife story is explicitly unverified; pages are illustrated facsimiles, not archival documents. Escape advice applies only in some versions. Attach an actual matching long video in YouTube Studio before using the Related Video CTA.
