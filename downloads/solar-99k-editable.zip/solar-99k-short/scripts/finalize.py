from pathlib import Path
import subprocess
r=Path(__file__).resolve().parents[1]
subprocess.run(['ffmpeg','-y','-v','error','-i',str(r/'out/solar-99k-native.mp4'),'-i',str(r/'public/sound-design.wav'),'-map','0:v:0','-map','1:a:0','-c:v','copy','-c:a','aac','-b:a','192k','-t','30','-movflags','+faststart',str(r/'out/solar-99k-30s-hinh-sfx.mp4')],check=True)
print('30-second MP4 picture/SFX ready — NO NARRATION')
