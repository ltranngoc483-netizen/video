from pathlib import Path
import json,subprocess
import numpy as np
import soundfile as sf
r=Path(__file__).resolve().parents[1];sr=48000;n=30*sr;rng=np.random.default_rng(150707)
music=np.zeros(n);sfx=np.zeros(n)
def add(at,x):
 i=round(at*sr);k=min(len(x),n-i)
 if k>0:sfx[i:i+k]+=x[:k]
def click(at,freq=1300,amp=.18,d=.1):
 t=np.arange(round(d*sr))/sr;add(at,(.35*rng.normal(size=len(t))+.65*np.sin(2*np.pi*freq*t))*np.exp(-t*65)*amp)
def bass(at,amp=.3,d=.7):
 t=np.arange(round(d*sr))/sr;add(at,np.sin(2*np.pi*(63*t-14*t*t))*np.exp(-t*7)*amp)
def paper(at,d=.25,amp=.16):
 t=np.arange(round(d*sr))/sr;z=rng.normal(size=len(t));z-=np.convolve(z,np.ones(24)/24,mode='same');add(at,z*np.sin(np.pi*t/d)**2*np.exp(-t*7)*amp)
def beep(at,freq=700,d=.12,amp=.09):
 t=np.arange(round(d*sr))/sr;add(at,np.sin(2*np.pi*freq*t)*np.sin(np.pi*t/d)**2*amp)
for beat in np.arange(0,29.5,.75):
 freq=[55,51.913,48.999,55][int(beat//7.5)%4];t=np.arange(round(.55*sr))/sr;i=round(beat*sr);k=min(len(t),n-i)
 music[i:i+k]+=.018*(np.sin(2*np.pi*freq*t[:k])+.25*np.sin(2*np.pi*freq*2*t[:k]))*np.exp(-t[:k]*5)
beep(.2,950,.12,.11);bass(.24,.3);paper(.45,.2,.15)
for at in [1.5,3.6,5,6.2,7.4,9.6,12.9,15,17.6,20,22.5,25]:paper(max(0,at-.05),.22);click(at,1450,.14)
paper(5.03,.42,.24)
# Original granular-paper sound, not a recording of real product contents.
for at in [6.25,6.55,6.9]:paper(at,.35,.18)
for at in [7.5,7.75,8.0]:click(at,530,.2,.13)
beep(9.65,1100,.08,.08);bass(17.65,.24,.45)
for at in [20.1,20.65,21.2,21.75]:beep(at,860,.08,.05)
beep(22.55,570,.13,.14);beep(22.82,370,.16,.11);bass(22.6,.25)
paper(25,.4,.24);bass(25,.34);paper(25.3,.2,.17);bass(26.1,.18,.4);bass(27.6,.18,.4);bass(29.25,.25,.7)
fade=np.minimum(1,(np.arange(n)[::-1]/sr)/.45);music*=fade;sfx*=fade
for filename,data in [('music-bed.wav',music),('sfx-only.wav',sfx),('sound-design.wav',np.tanh((music+sfx)*1.15)*.85)]:sf.write(r/'public'/filename,data,sr,subtype='PCM_16')
caps=json.loads((r/'src/captions.json').read_text())
def tc(t):
 ms=round(t*1000);return f'{ms//3600000:02}:{ms//60000%60:02}:{ms//1000%60:02},{ms%1000:03}'
(r/'out/solar-99k-vi-timing-draft.srt').write_text('\n\n'.join(f'{i+1}\n{tc(c["start"])} --> {tc(c["end"])}\n{c["text"]}' for i,c in enumerate(caps))+'\n')
print('30s mix + separated SFX/music and 13-cue draft SRT; no voice')
