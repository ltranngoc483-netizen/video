import React from 'react';import {useCurrentFrame,useVideoConfig} from 'remotion';import {Art,Base,Title,Tag,Fine,stepped,mix,C} from './RecorderVisuals';
export const SolarOffer=()=>{const f=useCurrentFrame();const {fps}=useVideoConfig();const t=stepped(f,fps);const shot=t<1.5?0:t<3.6?1:2;return <Base chapter="01 / QUẢNG CÁO CHƯA ĐO">
<Art file="offer" style={{scale:shot===0?1+t*.035:shot===1?1.18:1.27,translate:shot===1?'-20px 55px':shot===2?'-65px 5px':'0 0'}}/>
<Title>50.000mAh<br/>CHỈ 99K?</Title><Tag top={1325} large at={.2}>99.000Đ</Tag><Tag top={1470} at={1.5}>SOLAR TÍ HON · HỨA HẸN LỚN?</Tag>
<div style={{position:'absolute',left:710,top:1165,width:21,height:21,borderRadius:'50%',background:C.red,opacity:.35+.65*Math.sin(t*9)**2,boxShadow:'0 0 25px #E55441'}}/>
<Fine top={1575}>Giá và dung lượng là thông tin quảng cáo trong kịch bản, chưa phải số đo thực tế.</Fine>
</Base>};
