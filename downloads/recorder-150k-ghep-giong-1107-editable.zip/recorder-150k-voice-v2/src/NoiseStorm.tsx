import React from 'react';import {useCurrentFrame,useVideoConfig} from 'remotion';import {Art,Base,Title,Tag,Fine,Wave,Ring,stepped,C} from './RecorderVisuals';
export const NoiseStorm=()=>{const f=useCurrentFrame();const {fps}=useVideoConfig();const t=stepped(f,fps);const shot=t<1.24?0:t<3.36?1:t<4.96?2:3;const shake=t>.6&&t<1?Math.sin(t*90)*12:0;return <Base chapter="03 / CHẤT LƯỢNG THU">
<Art file="noise" style={{objectFit:'contain',scale:shot===0?1.07+t*.025:shot===1?1.27:shot===2?1.12:1.04+(t-4.96)*.035,translate:`${shake+(shot===1?100:shot===2?-100:0)}px ${shake/2}px`}}/>
<Title>{shot<2?'MỘT CÚ CỌ ÁO…':shot===2?'GIỌNG NÓI NHỎ DẦN':'XUYÊN TƯỜNG?'}</Title><Wave top={1115} color={C.red} amp={t<1?.12:1.1} at={.7}/><Wave top={1260} amp={t<3.36?.45:.15} at={.15}/>
<Tag top={1405} key={shot} at={[.1,1.24,3.36,4.96][shot]} red={shot<2}>{['MỘT CÚ CỌ ÁO…','SỘT SOẠT ÁT LỜI NÓI','CÀNG XA · ÂM CÀNG YẾU','NGHE THỬ TRƯỚC KHI TIN'][shot]}</Tag>
{shot===0?<Ring x={550} y={915} color={C.red} at={.6}/>:null}<Fine top={1555}>Tạp âm là SFX minh họa,<br/>không phải bản ghi thử thiết bị thật.</Fine>
</Base>};
