import React from 'react';import {Composition,Still,Freeze} from 'remotion';import {RecorderVideo} from './RecorderVideo';import {PenHook} from './PenHook';import {PenTeardown} from './PenTeardown';import {NoiseStorm} from './NoiseStorm';import {PenFunnel} from './PenFunnel';
const Asset01=()=> <Freeze frame={35}><PenHook/></Freeze>;
const Asset02=()=> <Freeze frame={45}><PenTeardown/></Freeze>;
const Asset03=()=> <Freeze frame={38}><NoiseStorm/></Freeze>;
const Asset04=()=> <Freeze frame={80}><PenFunnel/></Freeze>;
export const Root=()=> <>
<Composition id="Recorder150KVoice" component={RecorderVideo} width={1080} height={1920} fps={30} durationInFrames={739}/>
<Composition id="PenHook" component={PenHook} width={1080} height={1920} fps={30} durationInFrames={148}/>
<Composition id="PenTeardown" component={PenTeardown} width={1080} height={1920} fps={30} durationInFrames={255}/>
<Composition id="NoiseStorm" component={NoiseStorm} width={1080} height={1920} fps={30} durationInFrames={219}/>
<Composition id="PenFunnel" component={PenFunnel} width={1080} height={1920} fps={30} durationInFrames={117}/>
<Still id="Scene01" component={Asset01} width={1080} height={1920}/>
<Still id="Scene02" component={Asset02} width={1080} height={1920}/>
<Still id="Scene03" component={Asset03} width={1080} height={1920}/>
<Still id="Scene04" component={Asset04} width={1080} height={1920}/>
<Still id="Thumbnail" component={Asset01} width={1080} height={1920}/>
</>;
