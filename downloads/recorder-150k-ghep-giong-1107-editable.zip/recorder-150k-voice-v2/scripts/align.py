from pathlib import Path
import json,math,subprocess
r=Path(__file__).resolve().parents[1]
# ASR token onsets from the actual supplied MP3; correct the recognized
# micro/lọc ồn/cọ áo spelling against the supplied narration script.
phrases=[
('Bút ghi âm một trăm năm mươi nghìn…',[0,.28,.48,.72,.88,1.12,1.32,1.56],1.94),
('xuyên tường,',[2.08,2.36],2.72),
('chạy bốn mươi tám giờ?',[2.8,3.12,3.36,3.6,3.84],4.08),
('Thật sao?',[4.2,4.48],4.84),
('Bóc vỏ:',[4.92,5.28],5.56),
('micro, mạch ghi và pin tí hon.',[5.72,6.64,6.92,7.12,7.28,7.52,7.76],8.1),
('Dung lượng thật bao nhiêu?',[8.28,8.52,8.76,9,9.28],9.55),
('Có lọc ồn hay không?',[9.64,9.84,10.04,10.28,10.52],10.8),
('Không thể biết…',[10.88,11.16,11.4],11.67),
('nếu chưa kiểm tra từng mẫu.',[11.76,12.04,12.32,12.52,12.76,13],13.32),
('Chỉ một cú cọ áo…',[13.44,13.64,13.92,14.12,14.36],14.59),
('tiếng sột soạt có thể át cả lời nói.',[14.68,14.96,15.16,15.4,15.52,15.72,15.92,16.12,16.4],16.66),
('Càng xa, âm càng yếu.',[16.8,17.12,17.4,17.68,17.92],18.23),
('Xuyên tường?',[18.4,18.72],19.04),
('Hãy nghe thử trước khi tin.',[19.12,19.4,19.6,20,20.08,20.32],20.59),
('Muốn thấy toàn bộ bo mạch?',[20.72,20.96,21.24,21.4,21.68,21.88],22.13),
('Bấm Video liên quan…',[22.24,22.52,23.04,23.28],23.55),
('ngay bên dưới.',[23.68,23.96,24.28],24.59),
]
caps=[]
for text,times,end in phrases:
 words=text.split();assert len(words)==len(times),text
 caps.append(dict(text=text,startMs=round(times[0]*1000),endMs=round(end*1000),words=[dict(text=w,startMs=round(t*1000)) for w,t in zip(words,times)]))
(r/'src/captions.json').write_text(json.dumps(caps,ensure_ascii=False,indent=2))
duration=float(subprocess.check_output(['ffprobe','-v','error','-show_entries','format=duration','-of','default=nw=1:nk=1',str(r/'public/narration.mp3')]))
timing=dict(sourceDuration=duration,deliveryFrames=math.ceil(duration*30),sceneFrames=[0,148,403,622,math.ceil(duration*30)],hookCuts=[2.08,4.2],teardownCuts=[.8,2.36,3.36,5.96],noiseCuts=[1.24,3.36,4.96])
(r/'src/timing.json').write_text(json.dumps(timing,indent=2))
def tc(ms):return f'{ms//3600000:02}:{ms//60000%60:02}:{ms//1000%60:02},{ms%1000:03}'
(r/'out/recorder-150k-phu-de-1107.srt').write_text('\n\n'.join(f'{i+1}\n{tc(c["startMs"])} --> {tc(c["endMs"])}\n{c["text"]}' for i,c in enumerate(caps))+'\n',encoding='utf-8-sig')
print('18 MP3-aligned caption cues;',timing)
