from pathlib import Path
import json,subprocess,hashlib
import numpy as np
import soundfile as sf
r=Path(__file__).resolve().parents[1];p=r/'out/recorder-150k-hoan-chinh-1107.mp4'
assert hashlib.sha256((r/'public/narration.mp3').read_bytes()).hexdigest()=='2f6a9da1a7a2767ee3861a76e5ef444ee01e39ac635b7b398d9db21712ff921e'
d=json.loads(subprocess.check_output(['ffprobe','-v','error','-show_entries','format=duration,size:stream=codec_type,codec_name,width,height,r_frame_rate,nb_frames','-of','json',str(p)],text=True))
v=next(s for s in d['streams'] if s['codec_type']=='video');a=next(s for s in d['streams'] if s['codec_type']=='audio')
assert (v['width'],v['height'],v['r_frame_rate'],int(v['nb_frames']))==(1080,1920,'30/1',739)
assert v['codec_name']=='h264' and a['codec_name']=='aac';assert abs(float(d['format']['duration'])-739/30)<.05
subprocess.run(['ffmpeg','-v','error','-threads','2','-i',str(p),'-f','null','-'],check=True)
for inp,out in [(p,'decoded.wav'),(r/'public/narration.mp3','source-48k.wav')]:
 subprocess.run(['ffmpeg','-v','error','-y','-i',str(inp),'-vn','-ar','48000','-ac','2','-c:a','pcm_f32le',str(r/'out'/out)],check=True)
x,sr=sf.read(r/'out/decoded.wav',dtype='float32');source,_=sf.read(r/'out/source-48k.wav',dtype='float32');peak=float(np.max(abs(x)));assert .1<peak<1
length=min(len(x),len(source));correlation=float(np.corrcoef(x[:length:20].mean(axis=1),source[:length:20].mean(axis=1))[0,1]);assert correlation>.97,correlation
caps=json.loads((r/'src/captions.json').read_text());assert len(caps)==18
for i,c in enumerate(caps):
 assert 0<=c['startMs']<c['endMs']<=24608
 if i:assert c['startMs']>=caps[i-1]['endMs']
 assert all(c['startMs']<=w['startMs']<c['endMs'] for w in c['words'])
 assert float(np.sqrt(np.mean(x[int(c['startMs']/1000*sr):int(c['endMs']/1000*sr)]**2)))>.004
(r/'out/validation.json').write_text(json.dumps(dict(metadata=d,audioPeak=peak,narration='User-supplied 1107 (1)(1).MP3, original tempo/pitch',sourceCorrelation=correlation,captions=18,sceneFrames=[0,148,403,622,739]),indent=2))
print('PASS:739frames,24.633s,1080x1920 H264/AAC,full decode,18 speech/caption windows; voice correlation',round(correlation,4),'peak',round(peak,3))
