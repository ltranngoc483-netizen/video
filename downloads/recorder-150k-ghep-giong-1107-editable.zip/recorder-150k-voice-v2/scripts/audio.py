from pathlib import Path
import json,subprocess
import numpy as np
import soundfile as sf
r=Path(__file__).resolve().parents[1];sr=48000;n=round(739/30*sr);rng=np.random.default_rng(150707)
music=np.zeros(n);sfx=np.zeros(n)
def add(at,x):
 i=round(at*sr);k=min(len(x),n-i)
 if k>0:sfx[i:i+k]+=x[:k]
def click(at,freq=1300,amp=.18,d=.1):
 t=np.arange(round(d*sr))/sr;add(at,(.35*rng.normal(size=len(t))+.65*np.sin(2*np.pi*freq*t))*np.exp(-t*65)*amp)
def bass(at,amp=.3,d=.7):
 t=np.arange(round(d*sr))/sr;add(at,np.sin(2*np.pi*(63*t-14*t*t))*np.exp(-t*7)*amp)
def paper(at,d=.25,amp=.16):
 t=np.arange(round(d*sr))/sr;z=rng.normal(size=len(t));z-=np.convolve(z,np.ones(24)/24,mode='same');add(at,z*np.sin(np.pi*t/d)**2*np.exp(-t*7)*amp)
def beep(at,freq=700,d=.12,amp=.09):
 t=np.arange(round(d*sr))/sr;add(at,np.sin(2*np.pi*freq*t)*np.sin(np.pi*t/d)**2*amp)
for beat in np.arange(0,739/30-.5,.75):
 freq=[55,51.913,48.999,55][int(beat//7.5)%4];t=np.arange(round(.55*sr))/sr;i=round(beat*sr);k=min(len(t),n-i)
 music[i:i+k]+=.018*(np.sin(2*np.pi*freq*t[:k])+.25*np.sin(2*np.pi*freq*2*t[:k]))*np.exp(-t[:k]*5)
click(.15,900,.3);bass(.2,.3);paper(.4)
for at in [2.08,4.2,4.933,5.733,7.293,8.293,10.893,13.433,14.68,16.8,18.4,20.733]:paper(max(0,at-.05),.22);click(at,1500,.13)
paper(4.98,.45,.23)
for at in [5.15,5.35,5.55,5.8,7.35,8.35]:click(at,1700,.1,.07)
# Synthetic fabric contact: an illustrative effect, not a hardware test recording.
for at,d,amp in [(14.12,.32,.19),(14.55,.45,.13),(15.05,.5,.12),(15.65,.6,.1)]:
 t=np.arange(round(d*sr))/sr;z=rng.normal(size=len(t));z=np.convolve(z,np.ones(10)/10,mode='same');add(at,z*np.sin(np.pi*t/d)**2*(1+.4*np.sin(t*150))*amp)
bass(14.12,.3);beep(18.5,560,.13,.13);beep(18.75,360,.16,.1)
paper(20.733,.38,.25);bass(20.733,.38);paper(21.08,.25,.18);bass(21.83,.18,.4);bass(23.33,.18,.4);bass(24.05,.25,.7)
fade=np.minimum(1,(np.arange(n)[::-1]/sr)/.45);music*=fade;sfx*=fade
for filename,data in [('music-bed.wav',music),('sfx-only.wav',sfx),('sound-design.wav',np.tanh((music+sfx)*1.15)*.85)]:sf.write(r/'public'/filename,data,sr,subtype='PCM_16')
print('24.633s original sound design retimed to supplied voice; narration remains separate')
