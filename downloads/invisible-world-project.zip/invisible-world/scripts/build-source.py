from pathlib import Path
import json,random,struct,zlib
r=Path(__file__).resolve().parents[1]
rows='''ONE SMALL MOVEMENT.|A card. A reader. An invisible exchange.|tap
NO BATTERY. STILL ALIVE.|The reader supplies energy through a magnetic field.|radio
THE SIGNAL RETURNS.|The chip communicates back to the reader.|radio
ONE BEEP. MANY SYSTEMS.|A second or two is illustrative, not a guarantee.|tap
BEYOND THE TERMINAL.|The local tap starts a wider network journey.|network
THREE PIECES OF PROOF.|Credential. Transaction data. Cryptographic proof.|packet
WHO SAYS YES?|The issuer typically makes the banking decision.|bank
13.56 MEGAHERTZ.|Near Field Communication: just a few centimeters.|radio
POWER THROUGH THE AIR.|Inductive coupling supplies energy to the chip.|card
THE CHIP WAKES UP.|Compatible payment applications begin their exchange.|chip
A NUMBER IS NOT ENOUGH.|A credential identifies an account. Proof adds confidence.|card
A MATHEMATICAL SEAL.|A dynamic cryptogram authenticates transaction data.|chip
TOKEN ≠ CRYPTOGRAM.|A substitute credential is not a fresh cryptographic seal.|token
DIFFERENT PROTECTIONS.|Tokens and dynamic cryptograms do different jobs.|token
READY TO ASK.|The terminal usually does not decide alone.|packet
A $25 REQUEST.|Authorization requests a decision, not final settlement.|packet
CHOOSE A CONNECTION.|Broadband, Wi-Fi or cellular: routes vary.|network
THE GATEWAY.|Processors prepare and forward payment messages.|network
MEET THE ACQUIRER.|The acquiring side serves the merchant.|bank
ONTO THE NETWORK.|Routing depends on the payment arrangement.|network
NO GIANT COMPUTER.|Distributed infrastructure carries separate requests.|network
FIND THE RIGHT ISSUER.|Token services may help map the underlying account.|token
THE ISSUING BANK.|Should this particular transaction be allowed?|bank
FOUR LINES OF DEFENSE.|Account. Funds or credit. Authentication. Risk.|risk
FAST IS NOT GUARANTEED.|Approvals, declines, extra checks and timeouts.|decision
THE ANSWER COMES BACK.|Issuer → network → acquirer → terminal.|network
APPROVED ≠ SETTLED.|Clearing and settlement generally happen later.|settle
INSIDE THE ISSUER.|One request among thousands of separate decisions.|bank
CHECK THE SEAL.|Authentication data supports a legitimate transaction.|chip
CHECK THE ACCOUNT.|Active card? Available funds? Sufficient credit?|risk
LOOK FOR ANOMALIES.|Rules, statistical models and sometimes machine learning.|risk
UNUSUAL ≠ FRAUDULENT.|Security must balance risk and legitimate activity.|risk
APPROVE. CHALLENGE. DECLINE.|Illustrative decisions. Actual issuer policies vary.|decision
OUR $25 PURCHASE: YES.|An approval may reserve funds or available credit.|decision
WHEN THE ANSWER IS NO.|A blocked card or unavailable funds may trigger a decline.|decision
ONE RESPONSE. ONE RESULT.|The outcome travels back to the merchant.|network
COUNTLESS SEPARATE TAPS.|Each request stays tied to its own transaction.|network
WHAT IF THE LINK BREAKS?|The local NFC field can remain active.|offline
LOCAL IS NOT ONLINE.|Reading the card and reaching the issuer are different.|offline
OFFLINE IS CONDITIONAL.|Card, terminal, scheme and configuration set limits.|offline
A PIN IS NOT APPROVAL.|Offline PIN verification does not authorize payment.|offline
THREE POSSIBLE PATHS.|Offline approval, deferred submission, or another method.|offline
CONNECTED AGAIN.|Deferred processing is not a promise of payment.|offline
EVERY SYSTEM HAS LIMITS.|A healthy card can meet a failed connection.|network
UNDERSTAND THE INVISIBLE.|A simple tap. A coordinated exchange. Subscribe.|tap'''
acts=['I / THE HOOK','II / THE QUESTION','III / THE PRINCIPLE','IV / THE JOURNEY','V / INSIDE THE BANK','VI / WHEN THE LINK FAILS','VII / THE INVISIBLE WORLD']
head=[]
for i,line in enumerate(rows.splitlines(),1):
 title,note,kind=line.split('|');a=0 if i<=3 else 1 if i<=7 else 2 if i<=15 else 3 if i<=27 else 4 if i<=37 else 5 if i<=44 else 6
 head.append(dict(title=title,note=note,kind=kind,act=acts[a]))
(r/'src/headings.json').write_text(json.dumps(head,indent=2))
story=json.loads((r/'src/story.json').read_text());assert len(head)==len(story)==45
lines=["import React from 'react';","import {AbsoluteFill,Sequence,staticFile,useVideoConfig} from 'remotion';","import {Audio} from '@remotion/media';","import {TransitionSeries,linearTiming} from '@remotion/transitions';","import {wipe} from '@remotion/transitions/wipe';","import {PaperScene} from './PaperScene';","import {Captions} from './Captions';","export const Video=()=>{const {fps}=useVideoConfig();return <AbsoluteFill><TransitionSeries>"]
for i,s in enumerate(story):
 lines.append('<TransitionSeries.Sequence name="Scene %02d" durationInFrames={%d*fps%s} premountFor={fps}><PaperScene index={%d}/></TransitionSeries.Sequence>'%(s['id'],s['duration'],'' if i==44 else '+12',i))
 if i<44:lines.append('<TransitionSeries.Transition presentation={wipe({direction:"from-bottom-left"})} timing={linearTiming({durationInFrames:12})}/>')
lines.append('</TransitionSeries>')
for s in story:lines.append('<Sequence name="Voice / Scene %02d" from={%d*fps} durationInFrames={%d*fps} premountFor={fps}><Audio src={staticFile("voice-%02d.wav")} from={Math.round(.15*fps)} premountFor={fps}/></Sequence>'%(s['id'],s['start'],s['duration'],s['id']))
lines.append('<Captions/><Audio src={staticFile("sound-design.wav")} volume={.5} premountFor={fps}/></AbsoluteFill>};')
(r/'src/Video.tsx').write_text('\n'.join(lines))
lines=["import React from 'react';","import {Composition,Folder} from 'remotion';","import {Video} from './Video';","import {PaperScene} from './PaperScene';",'export const Root=()=> <><Composition id="InvisibleWorld" component={Video} width={1920} height={1080} fps={30} durationInFrames={18000}/><Folder name="Scenes">']
for i,s in enumerate(story):lines.append('<Composition id="Scene%02d" component={PaperScene} width={1920} height={1080} fps={30} durationInFrames={%d} defaultProps={{index:%d}}/>'%(s['id'],s['duration']*30,i))
lines.append('</Folder></>;');(r/'src/Root.tsx').write_text('\n'.join(lines))
rng=random.Random(17);w=h=180;raw=b''.join(b'\x00'+bytes(rng.randrange(70,230) for _ in range(w)) for _ in range(h))
def ch(t,d):return struct.pack('!I',len(d))+t+d+struct.pack('!I',zlib.crc32(t+d)&0xffffffff)
(r/'public/grain.png').write_bytes(b'\x89PNG\r\n\x1a\n'+ch(b'IHDR',struct.pack('!IIBBBBB',w,h,8,0,0,0,0))+ch(b'IDAT',zlib.compress(raw))+ch(b'IEND',b''))
print('Built 45 scenes and registrations.')
