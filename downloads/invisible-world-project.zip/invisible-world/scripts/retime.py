from pathlib import Path
import json,math,subprocess
r=Path(__file__).resolve().parents[1];old=json.loads((r/'src/story.json').read_text());report=json.loads((r/'out/voice-report.json').read_text());caps=json.loads((r/'src/captions.json').read_text())
raw=[x['tempo']*(s['duration']-(2.2 if s['id']==45 else .35)) for x,s in zip(report,old)]
pads=[2.2 if s['id']==45 else .35 for s in old];available=600-sum(pads);ideals=[x/sum(raw)*available+p for x,p in zip(raw,pads)]
durations=[math.floor(x) for x in ideals]
for i in sorted(range(45),key=lambda i:ideals[i]-durations[i],reverse=True)[:600-sum(durations)]:durations[i]+=1
new=[];newcaps=[];newreport=[];start=0
for i,s in enumerate(old):
 duration=durations[i];p=r/'public'/('voice-%02d.wav'%s['id']);tmp=p.with_suffix('.new.wav');oldtarget=s['duration']-pads[i];target=duration-pads[i];ratio=oldtarget/target
 subprocess.run(['ffmpeg','-y','-loglevel','error','-i',str(p),'-af',f'atempo={ratio:.8f}',str(tmp)],check=True);tmp.replace(p)
 scene_caps=[]
 for c in caps:
  if s['start']*1000<=c['startMs']<(s['start']+s['duration'])*1000:
   x=dict(c)
   for key in ['startMs','endMs']:x[key]=round((start+.15)*1000+(c[key]-(s['start']+.15)*1000)/ratio)
   scene_caps.append(x)
 (r/'public'/('captions-%02d.json'%s['id'])).write_text(json.dumps(scene_caps,indent=2));newcaps+=scene_caps
 new.append(dict(s,start=start,duration=duration));start+=duration;newreport.append(dict(scene=s['id'],tempo=raw[i]/target,duration=duration))
(r/'out/original-timing.json').write_text(json.dumps(old,indent=2));(r/'out/voice-report-original.json').write_text(json.dumps(report,indent=2));(r/'out/voice-report.json').write_text(json.dumps(newreport,indent=2));(r/'src/story.json').write_text(json.dumps(new,indent=2));(r/'src/captions.json').write_text(json.dumps(newcaps,indent=2))
print('Retimed 45 scenes:',sum(durations),'seconds; voice tempo range',round(min(x['tempo'] for x in newreport),2),round(max(x['tempo'] for x in newreport),2))
