from pathlib import Path
import os
os.environ['OMP_NUM_THREADS']='4'
import json,re,subprocess
import numpy as np,soundfile as sf,onnxruntime as ort
from kokoro_onnx import Kokoro
root=Path(__file__).resolve().parents[1];story=json.loads((root/'src/story.json').read_text());sr=24000
opts=ort.SessionOptions();opts.intra_op_num_threads=4
session=ort.InferenceSession(str(root.parent/'.models/kokoro.onnx'),sess_options=opts,providers=['CPUExecutionProvider'])
model=Kokoro.from_session(session,str(root.parent/'.models/voices.bin'))
allcaps=[]; report=[]
for scene in story:
 out=root/'public'/f'voice-{scene["id"]:02}.wav';cp=root/'public'/f'captions-{scene["id"]:02}.json'
 if out.exists() and cp.exists():
  allcaps.extend(json.loads(cp.read_text()));print('Reused',scene['id'],flush=True);continue
 pieces=re.split(r'(?<=[.!?])\s+',scene['voice'].replace('...','…'))
 chunks=[];lengths=[]
 for text in pieces:
  a,rate=model.create(text,voice='am_michael',speed=1.0,lang='en-us')
  nz=np.flatnonzero(np.abs(a)>.005)
  if len(nz):a=a[max(0,nz[0]-700):min(len(a),nz[-1]+1700)]
  a=np.concatenate([a,np.zeros(int(.12*sr))]);chunks.append(a);lengths.append(len(a)/sr)
 audio=np.concatenate(chunks);target=scene['duration']-(2.2 if scene['id']==45 else .35);tempo=len(audio)/sr/target
 raw=root/'out'/f'raw-{scene["id"]}.wav';sf.write(raw,audio,sr)
 subprocess.run(['ffmpeg','-y','-loglevel','error','-i',str(raw),'-af',f'atempo={tempo:.8f},loudnorm=I=-17:TP=-2:LRA=7','-ar','48000',str(out)],check=True);raw.unlink()
 caps=[];cursor=scene['start']+.15
 for text,l in zip(pieces,lengths):
  # Split each exactly timed synthesized sentence into readable phrase pages.
  words=text.split(); groups=[];g=[]
  for w in words:
   if len(' '.join(g+[w]))>63 and g:groups.append(' '.join(g));g=[]
   g.append(w)
  if g:groups.append(' '.join(g))
  total=sum(len(x) for x in groups);duration=l/tempo
  for g in groups:
   d=duration*len(g)/total;caps.append(dict(text=g,startMs=round(cursor*1000),endMs=round((cursor+d)*1000),timestampMs=None,confidence=None));cursor+=d
 cp.write_text(json.dumps(caps,indent=2));allcaps.extend(caps);report.append(dict(scene=scene['id'],tempo=tempo));print('Generated',scene['id'],'tempo',round(tempo,2),flush=True)
(root/'src/captions.json').write_text(json.dumps(allcaps,indent=2))
(root/'out/voice-report.json').write_text(json.dumps(report,indent=2))
print('DONE: 45 voices and caption JSON.',flush=True)
