from pathlib import Path
import json
import numpy as np,soundfile as sf
r=Path(__file__).resolve().parents[1];story=json.loads((r/'src/story.json').read_text());caps=json.loads((r/'src/captions.json').read_text());assert len(story)==45 and sum(s['duration'] for s in story)==600
missing=[];maxpeak=0
for s in story:
 p=r/'public'/('voice-%02d.wav'%s['id'])
 if not p.exists(): missing.append(s['id']);continue
 a,sr=sf.read(p);dur=len(a)/sr;peak=float(np.max(np.abs(a)));maxpeak=max(maxpeak,peak)
 assert dur+.15<s['duration'],(s['id'],dur,s['duration'])
 assert peak<1,(s['id'],'clipping')
assert not missing,('Missing voice files',missing)
assert caps and max(x['endMs'] for x in caps)<600000
assert all(x['endMs']>x['startMs'] for x in caps)
print('PASS: 45 valid voice clips; 600-second timeline;',len(caps),'caption pages; max voice peak',round(maxpeak,3))
