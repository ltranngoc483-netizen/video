from pathlib import Path
import json
import numpy as np,soundfile as sf
root=Path(__file__).resolve().parents[1];sr=24000;rng=np.random.default_rng(123)
a=np.zeros(600*sr,dtype=np.float32)
def add(at,x,gain):
 s=round(at*sr);e=min(len(a),s+len(x));a[s:e]+=x[:e-s]*gain
def paper(at):
 t=np.arange(int(.32*sr))/sr;n=rng.normal(0,1,len(t));n-=np.convolve(n,np.ones(15)/15,mode='same');add(at,n*np.sin(np.pi*t/.32)**2*np.exp(-t*8),.055)
def beep(at,base=880):
 t=np.arange(int(.20*sr))/sr;add(at,np.sin(2*np.pi*base*t)*np.sin(np.pi*t/.2)**2,.09)
def thud(at):
 t=np.arange(int(.7*sr))/sr;add(at,np.sin(2*np.pi*(55*t-15*t*t))*np.exp(-8*t),.17)
for scene in json.loads((root/'src/story.json').read_text()):
 s=scene['start'];paper(s);paper(s+.4)
 if scene['id'] in [3,26,34,36,45]:beep(s+1)
 if scene['id'] in [1,8,16,28,38,45]:thud(s+.15)
 if scene['id'] in [2,8,9,10,12,29]:
  t=np.arange(2*sr)/sr;add(s+.4,np.sin(2*np.pi*110*t)*np.sin(np.pi*t/2)**2,.025)
 if scene['id']==35:beep(s+1,340)
# Quiet original ambient harmonic bed, with a breathable 12-second envelope.
t=np.arange(len(a),dtype=np.float32)/sr
a+=(np.sin(2*np.pi*55*t)+.3*np.sin(2*np.pi*82.5*t))*.005*(.65+.35*np.sin(t*2*np.pi/12))
a[-2*sr:]*=np.linspace(1,0,2*sr)
sf.write(root/'public/sound-design.wav',a,sr,subtype='PCM_16');print('Original sound bed: 600 seconds')
