const {bundle}=require('@remotion/bundler');
const {selectComposition,renderStill,openBrowser}=require('@remotion/renderer');
const path=require('path');
const story=require('../src/story.json');
(async()=>{
 const serveUrl=await bundle({entryPoint:path.resolve('src/index.ts'),onProgress:()=>{}});
 const browser=await openBrowser('chrome',{browserExecutable:'/usr/bin/chromium',chromiumOptions:{gl:'swiftshader'}});
 try{
 const composition=await selectComposition({serveUrl,id:'InvisibleWorld',puppeteerInstance:browser});
 console.log('Composition:',composition.id,composition.width,composition.height,composition.durationInFrames,composition.fps);
 for(const [name,sec] of [['hook',0],['nfc',7],['token',12],['network',19],['risk',30],['offline',40],['outro',44]].map(([name,i])=>[name,story[i].start+Math.min(story[i].duration-1,4)])){
 await renderStill({composition,serveUrl,output:`out/${name}.png`,frame:Math.round(sec*30),scale:.5,puppeteerInstance:browser,logLevel:'error'});
 console.log('Inspected',name,sec);
 }
 }finally{await browser.close({silent:true})}
})().catch(e=>{console.error(e);process.exit(1)});
