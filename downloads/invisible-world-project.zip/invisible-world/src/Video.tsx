import React from 'react';
import {AbsoluteFill,Sequence,staticFile,useVideoConfig} from 'remotion';
import {Audio} from '@remotion/media';
import {TransitionSeries,linearTiming} from '@remotion/transitions';
import {wipe} from '@remotion/transitions/wipe';
import {PaperScene} from './PaperScene';
import {Captions} from './Captions';
export const Video=()=>{const {fps}=useVideoConfig();return <AbsoluteFill><TransitionSeries>
<TransitionSeries.Sequence name="Scene 01" durationInFrames={7*fps+12} premountFor={fps}><PaperScene index={0}/></TransitionSeries.Sequence>
<TransitionSeries.Transition presentation={wipe({direction:"from-bottom-left"})} timing={linearTiming({durationInFrames:12})}/>
<TransitionSeries.Sequence name="Scene 02" durationInFrames={6*fps+12} premountFor={fps}><PaperScene index={1}/></TransitionSeries.Sequence>
<TransitionSeries.Transition presentation={wipe({direction:"from-bottom-left"})} timing={linearTiming({durationInFrames:12})}/>
<TransitionSeries.Sequence name="Scene 03" durationInFrames={6*fps+12} premountFor={fps}><PaperScene index={2}/></TransitionSeries.Sequence>
<TransitionSeries.Transition presentation={wipe({direction:"from-bottom-left"})} timing={linearTiming({durationInFrames:12})}/>
<TransitionSeries.Sequence name="Scene 04" durationInFrames={8*fps+12} premountFor={fps}><PaperScene index={3}/></TransitionSeries.Sequence>
<TransitionSeries.Transition presentation={wipe({direction:"from-bottom-left"})} timing={linearTiming({durationInFrames:12})}/>
<TransitionSeries.Sequence name="Scene 05" durationInFrames={9*fps+12} premountFor={fps}><PaperScene index={4}/></TransitionSeries.Sequence>
<TransitionSeries.Transition presentation={wipe({direction:"from-bottom-left"})} timing={linearTiming({durationInFrames:12})}/>
<TransitionSeries.Sequence name="Scene 06" durationInFrames={8*fps+12} premountFor={fps}><PaperScene index={5}/></TransitionSeries.Sequence>
<TransitionSeries.Transition presentation={wipe({direction:"from-bottom-left"})} timing={linearTiming({durationInFrames:12})}/>
<TransitionSeries.Sequence name="Scene 07" durationInFrames={8*fps+12} premountFor={fps}><PaperScene index={6}/></TransitionSeries.Sequence>
<TransitionSeries.Transition presentation={wipe({direction:"from-bottom-left"})} timing={linearTiming({durationInFrames:12})}/>
<TransitionSeries.Sequence name="Scene 08" durationInFrames={16*fps+12} premountFor={fps}><PaperScene index={7}/></TransitionSeries.Sequence>
<TransitionSeries.Transition presentation={wipe({direction:"from-bottom-left"})} timing={linearTiming({durationInFrames:12})}/>
<TransitionSeries.Sequence name="Scene 09" durationInFrames={15*fps+12} premountFor={fps}><PaperScene index={8}/></TransitionSeries.Sequence>
<TransitionSeries.Transition presentation={wipe({direction:"from-bottom-left"})} timing={linearTiming({durationInFrames:12})}/>
<TransitionSeries.Sequence name="Scene 10" durationInFrames={16*fps+12} premountFor={fps}><PaperScene index={9}/></TransitionSeries.Sequence>
<TransitionSeries.Transition presentation={wipe({direction:"from-bottom-left"})} timing={linearTiming({durationInFrames:12})}/>
<TransitionSeries.Sequence name="Scene 11" durationInFrames={14*fps+12} premountFor={fps}><PaperScene index={10}/></TransitionSeries.Sequence>
<TransitionSeries.Transition presentation={wipe({direction:"from-bottom-left"})} timing={linearTiming({durationInFrames:12})}/>
<TransitionSeries.Sequence name="Scene 12" durationInFrames={18*fps+12} premountFor={fps}><PaperScene index={11}/></TransitionSeries.Sequence>
<TransitionSeries.Transition presentation={wipe({direction:"from-bottom-left"})} timing={linearTiming({durationInFrames:12})}/>
<TransitionSeries.Sequence name="Scene 13" durationInFrames={18*fps+12} premountFor={fps}><PaperScene index={12}/></TransitionSeries.Sequence>
<TransitionSeries.Transition presentation={wipe({direction:"from-bottom-left"})} timing={linearTiming({durationInFrames:12})}/>
<TransitionSeries.Sequence name="Scene 14" durationInFrames={13*fps+12} premountFor={fps}><PaperScene index={13}/></TransitionSeries.Sequence>
<TransitionSeries.Transition presentation={wipe({direction:"from-bottom-left"})} timing={linearTiming({durationInFrames:12})}/>
<TransitionSeries.Sequence name="Scene 15" durationInFrames={15*fps+12} premountFor={fps}><PaperScene index={14}/></TransitionSeries.Sequence>
<TransitionSeries.Transition presentation={wipe({direction:"from-bottom-left"})} timing={linearTiming({durationInFrames:12})}/>
<TransitionSeries.Sequence name="Scene 16" durationInFrames={15*fps+12} premountFor={fps}><PaperScene index={15}/></TransitionSeries.Sequence>
<TransitionSeries.Transition presentation={wipe({direction:"from-bottom-left"})} timing={linearTiming({durationInFrames:12})}/>
<TransitionSeries.Sequence name="Scene 17" durationInFrames={12*fps+12} premountFor={fps}><PaperScene index={16}/></TransitionSeries.Sequence>
<TransitionSeries.Transition presentation={wipe({direction:"from-bottom-left"})} timing={linearTiming({durationInFrames:12})}/>
<TransitionSeries.Sequence name="Scene 18" durationInFrames={15*fps+12} premountFor={fps}><PaperScene index={17}/></TransitionSeries.Sequence>
<TransitionSeries.Transition presentation={wipe({direction:"from-bottom-left"})} timing={linearTiming({durationInFrames:12})}/>
<TransitionSeries.Sequence name="Scene 19" durationInFrames={16*fps+12} premountFor={fps}><PaperScene index={18}/></TransitionSeries.Sequence>
<TransitionSeries.Transition presentation={wipe({direction:"from-bottom-left"})} timing={linearTiming({durationInFrames:12})}/>
<TransitionSeries.Sequence name="Scene 20" durationInFrames={16*fps+12} premountFor={fps}><PaperScene index={19}/></TransitionSeries.Sequence>
<TransitionSeries.Transition presentation={wipe({direction:"from-bottom-left"})} timing={linearTiming({durationInFrames:12})}/>
<TransitionSeries.Sequence name="Scene 21" durationInFrames={18*fps+12} premountFor={fps}><PaperScene index={20}/></TransitionSeries.Sequence>
<TransitionSeries.Transition presentation={wipe({direction:"from-bottom-left"})} timing={linearTiming({durationInFrames:12})}/>
<TransitionSeries.Sequence name="Scene 22" durationInFrames={15*fps+12} premountFor={fps}><PaperScene index={21}/></TransitionSeries.Sequence>
<TransitionSeries.Transition presentation={wipe({direction:"from-bottom-left"})} timing={linearTiming({durationInFrames:12})}/>
<TransitionSeries.Sequence name="Scene 23" durationInFrames={12*fps+12} premountFor={fps}><PaperScene index={22}/></TransitionSeries.Sequence>
<TransitionSeries.Transition presentation={wipe({direction:"from-bottom-left"})} timing={linearTiming({durationInFrames:12})}/>
<TransitionSeries.Sequence name="Scene 24" durationInFrames={10*fps+12} premountFor={fps}><PaperScene index={23}/></TransitionSeries.Sequence>
<TransitionSeries.Transition presentation={wipe({direction:"from-bottom-left"})} timing={linearTiming({durationInFrames:12})}/>
<TransitionSeries.Sequence name="Scene 25" durationInFrames={13*fps+12} premountFor={fps}><PaperScene index={24}/></TransitionSeries.Sequence>
<TransitionSeries.Transition presentation={wipe({direction:"from-bottom-left"})} timing={linearTiming({durationInFrames:12})}/>
<TransitionSeries.Sequence name="Scene 26" durationInFrames={16*fps+12} premountFor={fps}><PaperScene index={25}/></TransitionSeries.Sequence>
<TransitionSeries.Transition presentation={wipe({direction:"from-bottom-left"})} timing={linearTiming({durationInFrames:12})}/>
<TransitionSeries.Sequence name="Scene 27" durationInFrames={17*fps+12} premountFor={fps}><PaperScene index={26}/></TransitionSeries.Sequence>
<TransitionSeries.Transition presentation={wipe({direction:"from-bottom-left"})} timing={linearTiming({durationInFrames:12})}/>
<TransitionSeries.Sequence name="Scene 28" durationInFrames={12*fps+12} premountFor={fps}><PaperScene index={27}/></TransitionSeries.Sequence>
<TransitionSeries.Transition presentation={wipe({direction:"from-bottom-left"})} timing={linearTiming({durationInFrames:12})}/>
<TransitionSeries.Sequence name="Scene 29" durationInFrames={14*fps+12} premountFor={fps}><PaperScene index={28}/></TransitionSeries.Sequence>
<TransitionSeries.Transition presentation={wipe({direction:"from-bottom-left"})} timing={linearTiming({durationInFrames:12})}/>
<TransitionSeries.Sequence name="Scene 30" durationInFrames={13*fps+12} premountFor={fps}><PaperScene index={29}/></TransitionSeries.Sequence>
<TransitionSeries.Transition presentation={wipe({direction:"from-bottom-left"})} timing={linearTiming({durationInFrames:12})}/>
<TransitionSeries.Sequence name="Scene 31" durationInFrames={16*fps+12} premountFor={fps}><PaperScene index={30}/></TransitionSeries.Sequence>
<TransitionSeries.Transition presentation={wipe({direction:"from-bottom-left"})} timing={linearTiming({durationInFrames:12})}/>
<TransitionSeries.Sequence name="Scene 32" durationInFrames={17*fps+12} premountFor={fps}><PaperScene index={31}/></TransitionSeries.Sequence>
<TransitionSeries.Transition presentation={wipe({direction:"from-bottom-left"})} timing={linearTiming({durationInFrames:12})}/>
<TransitionSeries.Sequence name="Scene 33" durationInFrames={15*fps+12} premountFor={fps}><PaperScene index={32}/></TransitionSeries.Sequence>
<TransitionSeries.Transition presentation={wipe({direction:"from-bottom-left"})} timing={linearTiming({durationInFrames:12})}/>
<TransitionSeries.Sequence name="Scene 34" durationInFrames={14*fps+12} premountFor={fps}><PaperScene index={33}/></TransitionSeries.Sequence>
<TransitionSeries.Transition presentation={wipe({direction:"from-bottom-left"})} timing={linearTiming({durationInFrames:12})}/>
<TransitionSeries.Sequence name="Scene 35" durationInFrames={13*fps+12} premountFor={fps}><PaperScene index={34}/></TransitionSeries.Sequence>
<TransitionSeries.Transition presentation={wipe({direction:"from-bottom-left"})} timing={linearTiming({durationInFrames:12})}/>
<TransitionSeries.Sequence name="Scene 36" durationInFrames={12*fps+12} premountFor={fps}><PaperScene index={35}/></TransitionSeries.Sequence>
<TransitionSeries.Transition presentation={wipe({direction:"from-bottom-left"})} timing={linearTiming({durationInFrames:12})}/>
<TransitionSeries.Sequence name="Scene 37" durationInFrames={14*fps+12} premountFor={fps}><PaperScene index={36}/></TransitionSeries.Sequence>
<TransitionSeries.Transition presentation={wipe({direction:"from-bottom-left"})} timing={linearTiming({durationInFrames:12})}/>
<TransitionSeries.Sequence name="Scene 38" durationInFrames={5*fps+12} premountFor={fps}><PaperScene index={37}/></TransitionSeries.Sequence>
<TransitionSeries.Transition presentation={wipe({direction:"from-bottom-left"})} timing={linearTiming({durationInFrames:12})}/>
<TransitionSeries.Sequence name="Scene 39" durationInFrames={11*fps+12} premountFor={fps}><PaperScene index={38}/></TransitionSeries.Sequence>
<TransitionSeries.Transition presentation={wipe({direction:"from-bottom-left"})} timing={linearTiming({durationInFrames:12})}/>
<TransitionSeries.Sequence name="Scene 40" durationInFrames={11*fps+12} premountFor={fps}><PaperScene index={39}/></TransitionSeries.Sequence>
<TransitionSeries.Transition presentation={wipe({direction:"from-bottom-left"})} timing={linearTiming({durationInFrames:12})}/>
<TransitionSeries.Sequence name="Scene 41" durationInFrames={14*fps+12} premountFor={fps}><PaperScene index={40}/></TransitionSeries.Sequence>
<TransitionSeries.Transition presentation={wipe({direction:"from-bottom-left"})} timing={linearTiming({durationInFrames:12})}/>
<TransitionSeries.Sequence name="Scene 42" durationInFrames={15*fps+12} premountFor={fps}><PaperScene index={41}/></TransitionSeries.Sequence>
<TransitionSeries.Transition presentation={wipe({direction:"from-bottom-left"})} timing={linearTiming({durationInFrames:12})}/>
<TransitionSeries.Sequence name="Scene 43" durationInFrames={12*fps+12} premountFor={fps}><PaperScene index={42}/></TransitionSeries.Sequence>
<TransitionSeries.Transition presentation={wipe({direction:"from-bottom-left"})} timing={linearTiming({durationInFrames:12})}/>
<TransitionSeries.Sequence name="Scene 44" durationInFrames={10*fps+12} premountFor={fps}><PaperScene index={43}/></TransitionSeries.Sequence>
<TransitionSeries.Transition presentation={wipe({direction:"from-bottom-left"})} timing={linearTiming({durationInFrames:12})}/>
<TransitionSeries.Sequence name="Scene 45" durationInFrames={30*fps} premountFor={fps}><PaperScene index={44}/></TransitionSeries.Sequence>
</TransitionSeries>
<Sequence name="Voice / Scene 01" from={0*fps} durationInFrames={7*fps} premountFor={fps}><Audio src={staticFile("voice-01.wav")} from={Math.round(.15*fps)} premountFor={fps}/></Sequence>
<Sequence name="Voice / Scene 02" from={7*fps} durationInFrames={6*fps} premountFor={fps}><Audio src={staticFile("voice-02.wav")} from={Math.round(.15*fps)} premountFor={fps}/></Sequence>
<Sequence name="Voice / Scene 03" from={13*fps} durationInFrames={6*fps} premountFor={fps}><Audio src={staticFile("voice-03.wav")} from={Math.round(.15*fps)} premountFor={fps}/></Sequence>
<Sequence name="Voice / Scene 04" from={19*fps} durationInFrames={8*fps} premountFor={fps}><Audio src={staticFile("voice-04.wav")} from={Math.round(.15*fps)} premountFor={fps}/></Sequence>
<Sequence name="Voice / Scene 05" from={27*fps} durationInFrames={9*fps} premountFor={fps}><Audio src={staticFile("voice-05.wav")} from={Math.round(.15*fps)} premountFor={fps}/></Sequence>
<Sequence name="Voice / Scene 06" from={36*fps} durationInFrames={8*fps} premountFor={fps}><Audio src={staticFile("voice-06.wav")} from={Math.round(.15*fps)} premountFor={fps}/></Sequence>
<Sequence name="Voice / Scene 07" from={44*fps} durationInFrames={8*fps} premountFor={fps}><Audio src={staticFile("voice-07.wav")} from={Math.round(.15*fps)} premountFor={fps}/></Sequence>
<Sequence name="Voice / Scene 08" from={52*fps} durationInFrames={16*fps} premountFor={fps}><Audio src={staticFile("voice-08.wav")} from={Math.round(.15*fps)} premountFor={fps}/></Sequence>
<Sequence name="Voice / Scene 09" from={68*fps} durationInFrames={15*fps} premountFor={fps}><Audio src={staticFile("voice-09.wav")} from={Math.round(.15*fps)} premountFor={fps}/></Sequence>
<Sequence name="Voice / Scene 10" from={83*fps} durationInFrames={16*fps} premountFor={fps}><Audio src={staticFile("voice-10.wav")} from={Math.round(.15*fps)} premountFor={fps}/></Sequence>
<Sequence name="Voice / Scene 11" from={99*fps} durationInFrames={14*fps} premountFor={fps}><Audio src={staticFile("voice-11.wav")} from={Math.round(.15*fps)} premountFor={fps}/></Sequence>
<Sequence name="Voice / Scene 12" from={113*fps} durationInFrames={18*fps} premountFor={fps}><Audio src={staticFile("voice-12.wav")} from={Math.round(.15*fps)} premountFor={fps}/></Sequence>
<Sequence name="Voice / Scene 13" from={131*fps} durationInFrames={18*fps} premountFor={fps}><Audio src={staticFile("voice-13.wav")} from={Math.round(.15*fps)} premountFor={fps}/></Sequence>
<Sequence name="Voice / Scene 14" from={149*fps} durationInFrames={13*fps} premountFor={fps}><Audio src={staticFile("voice-14.wav")} from={Math.round(.15*fps)} premountFor={fps}/></Sequence>
<Sequence name="Voice / Scene 15" from={162*fps} durationInFrames={15*fps} premountFor={fps}><Audio src={staticFile("voice-15.wav")} from={Math.round(.15*fps)} premountFor={fps}/></Sequence>
<Sequence name="Voice / Scene 16" from={177*fps} durationInFrames={15*fps} premountFor={fps}><Audio src={staticFile("voice-16.wav")} from={Math.round(.15*fps)} premountFor={fps}/></Sequence>
<Sequence name="Voice / Scene 17" from={192*fps} durationInFrames={12*fps} premountFor={fps}><Audio src={staticFile("voice-17.wav")} from={Math.round(.15*fps)} premountFor={fps}/></Sequence>
<Sequence name="Voice / Scene 18" from={204*fps} durationInFrames={15*fps} premountFor={fps}><Audio src={staticFile("voice-18.wav")} from={Math.round(.15*fps)} premountFor={fps}/></Sequence>
<Sequence name="Voice / Scene 19" from={219*fps} durationInFrames={16*fps} premountFor={fps}><Audio src={staticFile("voice-19.wav")} from={Math.round(.15*fps)} premountFor={fps}/></Sequence>
<Sequence name="Voice / Scene 20" from={235*fps} durationInFrames={16*fps} premountFor={fps}><Audio src={staticFile("voice-20.wav")} from={Math.round(.15*fps)} premountFor={fps}/></Sequence>
<Sequence name="Voice / Scene 21" from={251*fps} durationInFrames={18*fps} premountFor={fps}><Audio src={staticFile("voice-21.wav")} from={Math.round(.15*fps)} premountFor={fps}/></Sequence>
<Sequence name="Voice / Scene 22" from={269*fps} durationInFrames={15*fps} premountFor={fps}><Audio src={staticFile("voice-22.wav")} from={Math.round(.15*fps)} premountFor={fps}/></Sequence>
<Sequence name="Voice / Scene 23" from={284*fps} durationInFrames={12*fps} premountFor={fps}><Audio src={staticFile("voice-23.wav")} from={Math.round(.15*fps)} premountFor={fps}/></Sequence>
<Sequence name="Voice / Scene 24" from={296*fps} durationInFrames={10*fps} premountFor={fps}><Audio src={staticFile("voice-24.wav")} from={Math.round(.15*fps)} premountFor={fps}/></Sequence>
<Sequence name="Voice / Scene 25" from={306*fps} durationInFrames={13*fps} premountFor={fps}><Audio src={staticFile("voice-25.wav")} from={Math.round(.15*fps)} premountFor={fps}/></Sequence>
<Sequence name="Voice / Scene 26" from={319*fps} durationInFrames={16*fps} premountFor={fps}><Audio src={staticFile("voice-26.wav")} from={Math.round(.15*fps)} premountFor={fps}/></Sequence>
<Sequence name="Voice / Scene 27" from={335*fps} durationInFrames={17*fps} premountFor={fps}><Audio src={staticFile("voice-27.wav")} from={Math.round(.15*fps)} premountFor={fps}/></Sequence>
<Sequence name="Voice / Scene 28" from={352*fps} durationInFrames={12*fps} premountFor={fps}><Audio src={staticFile("voice-28.wav")} from={Math.round(.15*fps)} premountFor={fps}/></Sequence>
<Sequence name="Voice / Scene 29" from={364*fps} durationInFrames={14*fps} premountFor={fps}><Audio src={staticFile("voice-29.wav")} from={Math.round(.15*fps)} premountFor={fps}/></Sequence>
<Sequence name="Voice / Scene 30" from={378*fps} durationInFrames={13*fps} premountFor={fps}><Audio src={staticFile("voice-30.wav")} from={Math.round(.15*fps)} premountFor={fps}/></Sequence>
<Sequence name="Voice / Scene 31" from={391*fps} durationInFrames={16*fps} premountFor={fps}><Audio src={staticFile("voice-31.wav")} from={Math.round(.15*fps)} premountFor={fps}/></Sequence>
<Sequence name="Voice / Scene 32" from={407*fps} durationInFrames={17*fps} premountFor={fps}><Audio src={staticFile("voice-32.wav")} from={Math.round(.15*fps)} premountFor={fps}/></Sequence>
<Sequence name="Voice / Scene 33" from={424*fps} durationInFrames={15*fps} premountFor={fps}><Audio src={staticFile("voice-33.wav")} from={Math.round(.15*fps)} premountFor={fps}/></Sequence>
<Sequence name="Voice / Scene 34" from={439*fps} durationInFrames={14*fps} premountFor={fps}><Audio src={staticFile("voice-34.wav")} from={Math.round(.15*fps)} premountFor={fps}/></Sequence>
<Sequence name="Voice / Scene 35" from={453*fps} durationInFrames={13*fps} premountFor={fps}><Audio src={staticFile("voice-35.wav")} from={Math.round(.15*fps)} premountFor={fps}/></Sequence>
<Sequence name="Voice / Scene 36" from={466*fps} durationInFrames={12*fps} premountFor={fps}><Audio src={staticFile("voice-36.wav")} from={Math.round(.15*fps)} premountFor={fps}/></Sequence>
<Sequence name="Voice / Scene 37" from={478*fps} durationInFrames={14*fps} premountFor={fps}><Audio src={staticFile("voice-37.wav")} from={Math.round(.15*fps)} premountFor={fps}/></Sequence>
<Sequence name="Voice / Scene 38" from={492*fps} durationInFrames={5*fps} premountFor={fps}><Audio src={staticFile("voice-38.wav")} from={Math.round(.15*fps)} premountFor={fps}/></Sequence>
<Sequence name="Voice / Scene 39" from={497*fps} durationInFrames={11*fps} premountFor={fps}><Audio src={staticFile("voice-39.wav")} from={Math.round(.15*fps)} premountFor={fps}/></Sequence>
<Sequence name="Voice / Scene 40" from={508*fps} durationInFrames={11*fps} premountFor={fps}><Audio src={staticFile("voice-40.wav")} from={Math.round(.15*fps)} premountFor={fps}/></Sequence>
<Sequence name="Voice / Scene 41" from={519*fps} durationInFrames={14*fps} premountFor={fps}><Audio src={staticFile("voice-41.wav")} from={Math.round(.15*fps)} premountFor={fps}/></Sequence>
<Sequence name="Voice / Scene 42" from={533*fps} durationInFrames={15*fps} premountFor={fps}><Audio src={staticFile("voice-42.wav")} from={Math.round(.15*fps)} premountFor={fps}/></Sequence>
<Sequence name="Voice / Scene 43" from={548*fps} durationInFrames={12*fps} premountFor={fps}><Audio src={staticFile("voice-43.wav")} from={Math.round(.15*fps)} premountFor={fps}/></Sequence>
<Sequence name="Voice / Scene 44" from={560*fps} durationInFrames={10*fps} premountFor={fps}><Audio src={staticFile("voice-44.wav")} from={Math.round(.15*fps)} premountFor={fps}/></Sequence>
<Sequence name="Voice / Scene 45" from={570*fps} durationInFrames={30*fps} premountFor={fps}><Audio src={staticFile("voice-45.wav")} from={Math.round(.15*fps)} premountFor={fps}/></Sequence>
<Captions/><Audio src={staticFile("sound-design.wav")} volume={.5} premountFor={fps}/></AbsoluteFill>};