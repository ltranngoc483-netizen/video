import React from 'react';
import {AbsoluteFill,Interactive,interpolate,useCurrentFrame,useVideoConfig,staticFile} from 'remotion';
import story from './story.json';
import headings from './headings.json';
import {Graphic} from './Graphic';
export const PaperScene:React.FC<{index:number}>=({index})=>{
 const frame=useCurrentFrame();const {fps}=useVideoConfig();const scene=story[index];const h=headings[index];
 const enter={opacity:interpolate(frame,[3,18],[0,1],{extrapolateLeft:'clamp',extrapolateRight:'clamp'}),translate:interpolate(frame,[3,24],['0px 65px','0px 0px'],{extrapolateLeft:'clamp',extrapolateRight:'clamp'})};
 return <AbsoluteFill style={{background:'#0a192f',color:'#f2ecdd',fontFamily:'Anton',overflow:'hidden'}}>
 <AbsoluteFill style={{backgroundImage:`url(${staticFile('grain.png')})`,opacity:.075,pointerEvents:'none'}}/>
 <div style={{position:'absolute',top:45,left:80,right:80,display:'flex',justifyContent:'space-between',alignItems:'center',font:'22px Mono',letterSpacing:3,borderBottom:'2px solid #f2ecdd50',paddingBottom:18}}><span>THE INVISIBLE WORLD</span><span>CONTACTLESS / FIELD NOTES {String(scene.id).padStart(2,'0')}—45</span></div>
 <Interactive.Div name="Chapter and headline" style={{position:'absolute',left:90,top:175,width:620,...enter}}>
  <div style={{font:'21px Mono',letterSpacing:3,color:'#00f0ff',marginBottom:30}}>{h.act}</div>
  <div style={{fontSize:101,lineHeight:1.05,letterSpacing:-1}}>{h.title}</div>
  <div style={{height:8,width:100,background:'#00f0ff',marginTop:38,marginBottom:30}}/>
  <div style={{font:'italic 35px Liberation Serif',lineHeight:1.4,color:'#ded9cb'}}>{h.note}</div>
 </Interactive.Div>
 <Interactive.Div name="Layered paper technical diagram" style={{position:'absolute',left:790,top:160,width:1040,height:700,rotate:interpolate(frame,[8,30],['-5deg','-1deg'],{extrapolateLeft:'clamp',extrapolateRight:'clamp'}),opacity:interpolate(frame,[8,25],[0,1],{extrapolateLeft:'clamp',extrapolateRight:'clamp'}),translate:interpolate(frame,[8,30],['90px 35px','0px 0px'],{extrapolateLeft:'clamp',extrapolateRight:'clamp'}),filter:'drop-shadow(15px 18px 0 #0004)'}}>
  <div style={{position:'absolute',inset:0,background:'#f2ecdd',clipPath:'polygon(1% 1%,18% 0,33% 1%,49% 0,68% 1%,83% 0,100% 1%,99% 99%,80% 100%,61% 99%,44% 100%,24% 99%,0 100%)'}}/>
  <div style={{position:'absolute',left:25,top:20}}><Graphic kind={h.kind} id={scene.id}/></div>
  <div style={{position:'absolute',left:400,top:-22,width:220,height:55,background:'#d4c99bb0',rotate:'-7deg'}}/>
 </Interactive.Div>
 <div style={{position:'absolute',left:87,bottom:150,font:'19px Mono',color:'#9bafa9',letterSpacing:2}}>ENGINEERING DIAGRAMS / EXPLANATORY METAPHORS</div>
 <div style={{position:'absolute',left:80,right:80,bottom:53,display:'flex',justifyContent:'space-between',font:'20px Mono',color:'#b7c3c5'}}><span>WHAT REALLY HAPPENS WHEN YOU TAP YOUR CREDIT CARD?</span><span>{Math.floor(scene.start/60)}:{String(scene.start%60).padStart(2,'0')} / 10:00</span></div>
 <div style={{position:'absolute',bottom:96,left:80,right:80,height:3,background:'#ffffff30'}}><div style={{height:3,background:'#00f0ff',width:`${interpolate(frame,[0,scene.duration*fps],[scene.start/6,(scene.start+scene.duration)/6],{extrapolateLeft:'clamp',extrapolateRight:'clamp'})}%`}}/></div>
 </AbsoluteFill>;
};
