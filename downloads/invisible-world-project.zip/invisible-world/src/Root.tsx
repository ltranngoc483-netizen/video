import React from 'react';
import {Composition,Folder} from 'remotion';
import {Video} from './Video';
import {PaperScene} from './PaperScene';
export const Root=()=> <><Composition id="InvisibleWorld" component={Video} width={1920} height={1080} fps={30} durationInFrames={18000}/><Folder name="Scenes">
<Composition id="Scene01" component={PaperScene} width={1920} height={1080} fps={30} durationInFrames={210} defaultProps={{index:0}}/>
<Composition id="Scene02" component={PaperScene} width={1920} height={1080} fps={30} durationInFrames={180} defaultProps={{index:1}}/>
<Composition id="Scene03" component={PaperScene} width={1920} height={1080} fps={30} durationInFrames={180} defaultProps={{index:2}}/>
<Composition id="Scene04" component={PaperScene} width={1920} height={1080} fps={30} durationInFrames={240} defaultProps={{index:3}}/>
<Composition id="Scene05" component={PaperScene} width={1920} height={1080} fps={30} durationInFrames={270} defaultProps={{index:4}}/>
<Composition id="Scene06" component={PaperScene} width={1920} height={1080} fps={30} durationInFrames={240} defaultProps={{index:5}}/>
<Composition id="Scene07" component={PaperScene} width={1920} height={1080} fps={30} durationInFrames={240} defaultProps={{index:6}}/>
<Composition id="Scene08" component={PaperScene} width={1920} height={1080} fps={30} durationInFrames={480} defaultProps={{index:7}}/>
<Composition id="Scene09" component={PaperScene} width={1920} height={1080} fps={30} durationInFrames={450} defaultProps={{index:8}}/>
<Composition id="Scene10" component={PaperScene} width={1920} height={1080} fps={30} durationInFrames={480} defaultProps={{index:9}}/>
<Composition id="Scene11" component={PaperScene} width={1920} height={1080} fps={30} durationInFrames={420} defaultProps={{index:10}}/>
<Composition id="Scene12" component={PaperScene} width={1920} height={1080} fps={30} durationInFrames={540} defaultProps={{index:11}}/>
<Composition id="Scene13" component={PaperScene} width={1920} height={1080} fps={30} durationInFrames={540} defaultProps={{index:12}}/>
<Composition id="Scene14" component={PaperScene} width={1920} height={1080} fps={30} durationInFrames={390} defaultProps={{index:13}}/>
<Composition id="Scene15" component={PaperScene} width={1920} height={1080} fps={30} durationInFrames={450} defaultProps={{index:14}}/>
<Composition id="Scene16" component={PaperScene} width={1920} height={1080} fps={30} durationInFrames={450} defaultProps={{index:15}}/>
<Composition id="Scene17" component={PaperScene} width={1920} height={1080} fps={30} durationInFrames={360} defaultProps={{index:16}}/>
<Composition id="Scene18" component={PaperScene} width={1920} height={1080} fps={30} durationInFrames={450} defaultProps={{index:17}}/>
<Composition id="Scene19" component={PaperScene} width={1920} height={1080} fps={30} durationInFrames={480} defaultProps={{index:18}}/>
<Composition id="Scene20" component={PaperScene} width={1920} height={1080} fps={30} durationInFrames={480} defaultProps={{index:19}}/>
<Composition id="Scene21" component={PaperScene} width={1920} height={1080} fps={30} durationInFrames={540} defaultProps={{index:20}}/>
<Composition id="Scene22" component={PaperScene} width={1920} height={1080} fps={30} durationInFrames={450} defaultProps={{index:21}}/>
<Composition id="Scene23" component={PaperScene} width={1920} height={1080} fps={30} durationInFrames={360} defaultProps={{index:22}}/>
<Composition id="Scene24" component={PaperScene} width={1920} height={1080} fps={30} durationInFrames={300} defaultProps={{index:23}}/>
<Composition id="Scene25" component={PaperScene} width={1920} height={1080} fps={30} durationInFrames={390} defaultProps={{index:24}}/>
<Composition id="Scene26" component={PaperScene} width={1920} height={1080} fps={30} durationInFrames={480} defaultProps={{index:25}}/>
<Composition id="Scene27" component={PaperScene} width={1920} height={1080} fps={30} durationInFrames={510} defaultProps={{index:26}}/>
<Composition id="Scene28" component={PaperScene} width={1920} height={1080} fps={30} durationInFrames={360} defaultProps={{index:27}}/>
<Composition id="Scene29" component={PaperScene} width={1920} height={1080} fps={30} durationInFrames={420} defaultProps={{index:28}}/>
<Composition id="Scene30" component={PaperScene} width={1920} height={1080} fps={30} durationInFrames={390} defaultProps={{index:29}}/>
<Composition id="Scene31" component={PaperScene} width={1920} height={1080} fps={30} durationInFrames={480} defaultProps={{index:30}}/>
<Composition id="Scene32" component={PaperScene} width={1920} height={1080} fps={30} durationInFrames={510} defaultProps={{index:31}}/>
<Composition id="Scene33" component={PaperScene} width={1920} height={1080} fps={30} durationInFrames={450} defaultProps={{index:32}}/>
<Composition id="Scene34" component={PaperScene} width={1920} height={1080} fps={30} durationInFrames={420} defaultProps={{index:33}}/>
<Composition id="Scene35" component={PaperScene} width={1920} height={1080} fps={30} durationInFrames={390} defaultProps={{index:34}}/>
<Composition id="Scene36" component={PaperScene} width={1920} height={1080} fps={30} durationInFrames={360} defaultProps={{index:35}}/>
<Composition id="Scene37" component={PaperScene} width={1920} height={1080} fps={30} durationInFrames={420} defaultProps={{index:36}}/>
<Composition id="Scene38" component={PaperScene} width={1920} height={1080} fps={30} durationInFrames={150} defaultProps={{index:37}}/>
<Composition id="Scene39" component={PaperScene} width={1920} height={1080} fps={30} durationInFrames={330} defaultProps={{index:38}}/>
<Composition id="Scene40" component={PaperScene} width={1920} height={1080} fps={30} durationInFrames={330} defaultProps={{index:39}}/>
<Composition id="Scene41" component={PaperScene} width={1920} height={1080} fps={30} durationInFrames={420} defaultProps={{index:40}}/>
<Composition id="Scene42" component={PaperScene} width={1920} height={1080} fps={30} durationInFrames={450} defaultProps={{index:41}}/>
<Composition id="Scene43" component={PaperScene} width={1920} height={1080} fps={30} durationInFrames={360} defaultProps={{index:42}}/>
<Composition id="Scene44" component={PaperScene} width={1920} height={1080} fps={30} durationInFrames={300} defaultProps={{index:43}}/>
<Composition id="Scene45" component={PaperScene} width={1920} height={1080} fps={30} durationInFrames={900} defaultProps={{index:44}}/>
</Folder></>;