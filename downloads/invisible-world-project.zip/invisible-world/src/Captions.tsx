import React from 'react';
import {useCurrentFrame,useVideoConfig} from 'remotion';
import type {Caption} from '@remotion/captions';
import data from './captions.json';
export const Captions=()=>{const f=useCurrentFrame();const {fps}=useVideoConfig();const t=f/fps*1000;const c=(data as Caption[]).find(x=>t>=x.startMs&&t<x.endMs);return c?<div style={{position:'absolute',left:140,right:140,bottom:195,display:'flex',justifyContent:'center',pointerEvents:'none'}}><div style={{padding:'13px 27px',background:'#f2ecdd',color:'#0a192f',boxShadow:'6px 7px 0 #007986',fontFamily:'Anton',fontSize:39,lineHeight:1.3,maxWidth:1510,textAlign:'center',rotate:'-.4deg'}}>{c.text}</div></div>:null;};
