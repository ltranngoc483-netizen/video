import {staticFile,delayRender,continueRender,cancelRender} from 'remotion';
if(typeof document!=='undefined'){
 const handle=delayRender('Loading local editorial fonts');
 Promise.all([
  new FontFace('Anton',`url(${staticFile('Anton.ttf')})`).load(),
  new FontFace('Mono',`url(${staticFile('Mono.ttf')})`).load(),
 ]).then(fonts=>{fonts.forEach(font=>document.fonts.add(font));continueRender(handle);}).catch(cancelRender);
}
