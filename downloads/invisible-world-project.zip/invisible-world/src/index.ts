import {registerRoot} from 'remotion';
import './fonts';
import './style.css';
import {Root} from './Root';
registerRoot(Root);
