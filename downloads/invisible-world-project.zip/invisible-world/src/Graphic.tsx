import React from 'react';
import {useCurrentFrame,interpolate} from 'remotion';
const ink='#0a192f',paper='#f2ecdd',cyan='#00f0ff',copper='#b67b42';
const Card=({x=150,y=60,scale=1,open=false}:{x?:number;y?:number;scale?:number;open?:boolean})=><g transform={`translate(${x} ${y}) scale(${scale}) rotate(-9 270 150)`}>
 <path d="M0 8L539 0 551 300 9 312Z" fill={paper} stroke={paper} strokeWidth="20"/>
 <path d="M0 8L539 0 551 300 9 312Z" fill={open?'#dcd9cc':ink} stroke={ink} strokeWidth="3"/>
 {open?<><path d="M35 50L491 39 504 254 47 267Z M48 64L477 53 489 240 62 252Z M62 79L463 68 475 226 76 238Z" fill="none" stroke={copper} strokeWidth="7"/><path d="M155 169H230V245M160 182H215V245" fill="none" stroke={copper} strokeWidth="6"/></>:<><text x="40" y="62" fill={paper} fontSize="21">CONTACTLESS / EMV</text><path d="M440 62Q477 99 440 136M455 48Q505 100 455 151" stroke={cyan} strokeWidth="7" fill="none"/></>}
 <rect x="107" y="122" width="85" height="65" rx="8" fill={copper} stroke={paper} strokeWidth="3"/><path d="M116 143H184M116 166H184M138 126V182M162 126V182" stroke={ink} strokeWidth="3"/>
 <text x="45" y="278" fontSize="18" fill={open?ink:paper}>PROTECTED PAYMENT CREDENTIAL</text>
 </g>;
const Pos=({x=430,y=275,scale=1}:{x?:number;y?:number;scale?:number})=><g transform={`translate(${x} ${y}) scale(${scale}) rotate(10 150 120)`}><path d="M25 0H284L323 264 0 279Z" fill="#bcbcaf" stroke={paper} strokeWidth="16"/><path d="M25 0H284L323 264 0 279Z" fill="none" stroke={ink} strokeWidth="3"/><path d="M57 28H258L266 116 47 126Z" fill={ink}/><text x="150" y="82" textAnchor="middle" fill={cyan} fontSize="25">TAP HERE</text>{Array.from({length:9},(_,i)=><rect key={i} x={64+i%3*65} y={151+Math.floor(i/3)*30} width="43" height="18" fill={paper} stroke={ink} strokeWidth="2"/>)}</g>;
const Server=({x=0,y=0,label='ISSUER',scale=1}:{x?:number;y?:number;label?:string;scale?:number})=><g transform={`translate(${x} ${y}) scale(${scale})`}><path d="M0 35L140 0 212 40 212 291 70 327 0 284Z" fill="#a8b0b2" stroke={paper} strokeWidth="13"/><path d="M0 35L70 76 212 40M70 76V327" fill="none" stroke={ink} strokeWidth="3"/>{[0,1,2,3].map(i=><g key={i}><path d={`M83 ${92+i*53}L196 ${63+i*53}V${97+i*53}L83 ${127+i*53}Z`} fill={ink}/><circle cx="180" cy={84+i*53} r="4" fill={cyan}/></g>)}<text x="105" y="382" fontSize="27" textAnchor="middle" fill={ink}>{label}</text></g>;
const Chip=()=> <g><rect x="320" y="100" width="350" height="350" fill={ink} stroke={paper} strokeWidth="20"/>{Array.from({length:10},(_,i)=><g key={i} stroke={copper} strokeWidth="12"><path d={`M${340+i*34} 75V105M${340+i*34} 445V480M290 ${120+i*33}H320M670 ${120+i*33}H705`}/></g>)}<rect x="385" y="165" width="220" height="220" fill="none" stroke={cyan} strokeWidth="6"/><text x="494" y="290" fill={cyan} fontSize="52" textAnchor="middle">EMV</text><text x="495" y="550" fill={ink} fontSize="27" textAnchor="middle">SECURE CHIP / SECRET KEY STAYS INSIDE</text></g>;
export const Graphic:React.FC<{kind:string;id:number}>=({kind,id})=>{
 const f=useCurrentFrame();
 return <svg width="1020" height="660" viewBox="0 0 1020 660" style={{overflow:'visible',filter:'drop-shadow(8px 12px 0 #0002)'}}>
 <defs><pattern id="graph-grid" width="40" height="40" patternUnits="userSpaceOnUse"><path d="M40 0H0V40" fill="none" stroke="#0a192f" strokeOpacity=".09"/></pattern><marker id="route-head" markerWidth="10" markerHeight="10" refX="8" refY="5" orient="auto"><path d="M0 0L8 5 0 10" fill="none" stroke="#007986" strokeWidth="2"/></marker></defs><rect width="1020" height="660" fill="url(#graph-grid)"/>
 {['tap','radio','card'].includes(kind)&&<>
 <g style={{translate:`0px ${interpolate(f,[0,32],[-55,0],{extrapolateRight:'clamp'})}px`}}><Card open={kind!=='tap'}/></g><Pos/>
 {[0,1,2].map(i=><ellipse key={i} cx="600" cy="300" rx={70+i*32+(f%40)*.65} ry={22+i*13} fill="none" stroke="#007986" strokeWidth="4" opacity={.7-i*.14}/>)}
 <text x="50" y="600" fill={ink} fontSize="25">{kind==='radio'?'13.56 MHz / SHORT-RANGE MAGNETIC FIELD':kind==='card'?'ANTENNA → POWER CIRCUIT → CHIP':'A FEW CENTIMETERS. AN INVISIBLE EXCHANGE.'}</text>
 </>}
 {kind==='chip'&&<Chip/>}
 {kind==='token'&&<><g transform="translate(-90 120) scale(.72)"><Card open/></g><g transform="translate(670 65) rotate(8)"><rect width="245" height="435" rx="18" fill={ink} stroke={paper} strokeWidth="18"/><rect x="22" y="30" width="201" height="365" fill="#d4ded9"/><path d="M120 120L183 156 170 249 120 290 70 249 57 156Z" fill={ink}/><text x="120" y="214" fill={cyan} textAnchor="middle" fontSize="24">TOKEN</text></g><text x="115" y="550" fill={ink} fontSize="28">CARD: DYNAMIC CRYPTOGRAM</text><text x="630" y="550" fill={ink} fontSize="28">WALLET: TOKENIZED CREDENTIAL</text><path d="M500 210V480" stroke={ink} strokeDasharray="9 14" strokeWidth="3"/></>}
 {kind==='packet'&&<>{['CREDENTIAL','TRANSACTION DATA','CRYPTOGRAPHIC PROOF'].map((t,i)=><g key={t} transform={`translate(${120+i*70} ${100+i*130}) rotate(${i*3-4})`}><path d="M0 0L660 8 651 117 9 124Z" fill={i===2?ink:paper} stroke={ink} strokeWidth="3"/><text x="40" y="76" fill={i===2?'#00c7d7':ink} fontSize="34">{t}</text><rect x="565" y="40" width="43" height="43" fill="none" stroke={i===2?cyan:'#007986'} strokeWidth="4"/></g>)}</>}
 {['network','bank','settle'].includes(kind)&&<>
 <g transform="translate(40 160) scale(.57)"><Pos x={0} y={0}/><text x="160" y="355" fill={ink} fontSize="40" textAnchor="middle">MERCHANT</text></g><Server x={340} y={150} scale={.72} label="ACQUIRER"/><Server x={750} y={150} scale={.86} label="ISSUER"/>
 <path d="M215 295H335M500 295H750" fill="none" stroke="#007986" strokeWidth="9" markerEnd="url(#route-head)" strokeDasharray="18 13" strokeDashoffset={-f*2}/>
 <g transform="translate(570 245)"><path d="M0 0L100 -20 140 45 80 110 -5 85Z" fill={ink} stroke={paper} strokeWidth="8"/><text x="60" y="50" fill={cyan} textAnchor="middle" fontSize="20">NETWORK</text></g>
 <text x="80" y="75" fontSize="33" fill={ink}>{kind==='settle'?'APPROVAL NOW ≠ FINAL MONEY MOVEMENT':id===26?'THE RESPONSE RETURNS THROUGH THE CHAIN':'AUTHORIZATION REQUEST → ISSUER DECISION'}</text>
 {kind==='settle'&&<><path d="M120 550H875" stroke={copper} strokeWidth="13" strokeDasharray="30 15" strokeDashoffset={-f*.3}/><text x="200" y="620" fontSize="26" fill={ink}>LATER: CLEARING & SETTLEMENT</text></>}
 </>}
 {['risk','decision'].includes(kind)&&<>
 <Server x={45} y={170} scale={.75}/>
 {['ACCOUNT STATUS','FUNDS / CREDIT','AUTHENTICATION','RISK SIGNALS'].map((t,i)=><g key={t} transform={`translate(320 ${80+i*120})`}><rect width="555" height="86" fill={paper} stroke={ink} strokeWidth="3"/><text x="25" y="54" fontSize="27" fill={ink}>{t}</text><path d="M470 42L490 62 526 23" fill="none" stroke={id===35?'#b06a25':'#007986'} strokeWidth="8" opacity={interpolate(f,[i*15,i*15+8],[0,1],{extrapolateLeft:'clamp',extrapolateRight:'clamp'})}/></g>)}
 <text x="510" y="625" textAnchor="middle" fontSize="30" fill={ink}>{id===35?'DECLINED':id===25?'APPROVE / DECLINE / TIMEOUT':id===33?'APPROVE / CHALLENGE / DECLINE':kind==='decision'?'APPROVED':'CHECK. EVALUATE. RESPOND.'}</text>
 </>}
 {kind==='offline'&&<><Pos x={80} y={150} scale={1.15}/><Server x={740} y={185} scale={.9}/><path d="M470 340H570M655 340H730" stroke={ink} strokeWidth="8" strokeDasharray="18 14"/><path d="M580 275L635 390M635 275L580 390" stroke="#b06a25" strokeWidth="15"/><text x="500" y="80" textAnchor="middle" fontSize="40" fill={ink}>LOCAL NFC ≠ ONLINE AUTHORIZATION</text><text x="535" y="590" textAnchor="middle" fontSize="28" fill={ink}>{id===41?'OFFLINE PIN IS NOT PAYMENT APPROVAL':id===43?'DEFERRED SUBMISSION: PAYMENT NOT GUARANTEED':'OFFLINE OPTIONS DEPEND ON CARD + TERMINAL + RULES'}</text></>}
 {id===4&&<g transform="translate(55 440) rotate(-6)"><rect width="260" height="105" fill={ink} stroke={paper} strokeWidth="8"/><text x="130" y="51" textAnchor="middle" fill={cyan} fontSize="43">1.5 s</text><text x="130" y="85" textAnchor="middle" fill={paper} fontSize="17">ILLUSTRATIVE ONLY</text></g>}
 {id===34&&<g transform="translate(50 45) rotate(-5)"><rect width="390" height="70" fill={ink}/><text x="195" y="48" textAnchor="middle" fontSize="23" fill={cyan}>$25 / AUTHORIZATION HOLD</text></g>}
 </svg>;
};
