# The Invisible World — Paper Circuit

## Style Prompt
A 16:9 paper-engineering documentary. Miniature cut-paper cards, copper antenna loops, silicon chips, POS readers and server racks on a navy drafting desk. Cream torn sheets, visible paper edges, masking tape, stamped cyan annotations, precise black ink diagrams. Technical X-ray ideas become exploded paper layers. Keep the physics distinct from the data-routing metaphors. No people or stock shopping footage.

## Colors
- #0a192f: navy desk and dark ink
- #f2ecdd: cream paper
- #00f0ff: cyan data on navy
- #007986: readable cyan ink on cream
- #b67b42: copper antenna

## Typography
Anton for display; IBM Plex Mono for labels; Liberation Serif for explanatory notes. Local fonts only.

## Motion
Paper slides and diagonal wipes, staggered diagram assembly, stamped decisions, animated dotted data routes and short-range radio rings. Use frame-driven deterministic animation. 1920x1080 at 30 fps, 600 seconds.

## What NOT to Do
- No photo-real 3D, glossy dashboards or people.
- No suggestion that a plastic card creates a new token every tap.
- No conflation of authorization and settlement, or offline PIN and offline approval.
- No claim that a beep guarantees completed issuer authorization.
- No literal objects travelling inside banking networks; diagrams are labeled metaphors.
