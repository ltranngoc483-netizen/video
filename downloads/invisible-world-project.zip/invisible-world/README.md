# The Invisible World — Paper Circuit

**What Really Happens When You Tap Your Credit Card?**

A 16:9 cut-paper documentary composition: 1920 × 1080, 30 fps, 45 scenes, 600 seconds. This is a new project; the First Brands project is preserved separately.

## View and edit

```sh
cd /workspace/video/invisible-world
npm ci
npm run dev
```

Inside the cloud environment, Studio runs at `http://localhost:3001/InvisibleWorld`. This localhost URL is not a public link for another computer. The Scenes folder contains 45 individually registered scenes. Each scene, voice clip and transition has its own authored JSX timeline node.

`out/invisible-world-opening.mp4` is the 20-second opening preview when its export completes. It is a preview excerpt, not the entire ten-minute film. The complete composition is editable in Studio; no full-length MP4 is claimed here.

## Script and adaptation

The supplied script is preserved in `production-script.txt`; `src/story.json` holds its 45 narration and visual entries. `src/headings.json` owns the display headlines, summaries and illustration modes. `DESIGN.md` defines the paper style.

The supplied durations totaled 610 seconds despite the 10:00 target. The first timing pass compressed scenes 38–44 to 60 seconds but made several technical lines too fast. The final timing allocates exactly 600 seconds across all 45 scenes using measured speech lengths, keeping the delivery close to its natural rate. Chapter boundaries therefore differ from the source timecodes. All supplied voiceover wording is retained. The opening MP4 is an earlier style-proof excerpt; minor layout and timing changes were made afterward in the editable composition. The source's original 3D X-ray direction is replaced by layered paper cutaways at the user's request.

Technical distinctions retained: reader-powered NFC at 13.56 MHz; protected credentials versus dynamic cryptograms; tokenization versus cryptography; acquirer/network/issuer roles; authorization versus clearing and settlement; offline PIN versus offline approval; conditional deferred processing. Diagrams represent explanatory metaphors rather than literal objects inside networks. The 1.5-second example is not presented as guaranteed issuer response time. No independent technical sourcing was added beyond the supplied script.

## Audio and captions

The draft voice is **Kokoro am_michael**, a US male voice, using the local TTS backend used by HyperFrames. It is not ElevenLabs Marcus and is not a cloned voice. To replace it with Marcus, provide licensed narration through an appropriate workflow; do not rename this generated voice as Marcus.

`public/voice-01.wav` through `voice-45.wav` are generated individually. `scripts/voice.py` is resumable and skips complete voice/caption pairs. It uses the official model and voices cached at `../.models` and the separate Python venv at `../.tts-venv`. Local audio playback requires no model, API key or Internet connection. `src/captions.json` follows the Remotion Caption format. Sentence timing derives from synthesized chunks and their corresponding tempo adjustment; shorter pages within a sentence use proportional timing, not word-level forced alignment.

`scripts/sound.py` creates original paper flips, short electronic beeps, low impacts and a quiet ambient bed. They are synthesized approximations, not recorded foley. Anton and IBM Plex Mono fonts are local and their OFL licenses are in `public/licenses`.

## Checks and exports

```sh
npm run check
python scripts/verify-audio.py
node scripts/inspect.cjs
npx remotion render src/index.ts InvisibleWorld out/invisible-world-opening.mp4 --frames=0-599 --scale=0.5 --codec=h264 --crf=23 --concurrency=2 --timeout=120000 --browser-executable=/usr/bin/chromium
```

The preview export uses 960 × 540 while the source remains 1920 × 1080. `scripts/inspect.cjs` captures representative frames; captures made before audio generation finishes can log missing future voice assets. Repeat final readiness checks only after all 45 voice files exist.
