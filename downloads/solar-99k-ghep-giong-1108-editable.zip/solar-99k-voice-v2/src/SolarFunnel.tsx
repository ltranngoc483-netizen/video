import React from 'react';import {useCurrentFrame,useVideoConfig} from 'remotion';import {Art,Base,Tag,stepped,mix,C} from './RecorderVisuals';
export const SolarFunnel=()=>{const f=useCurrentFrame();const {fps}=useVideoConfig();const t=stepped(f,fps);const pulse=(t>1&&t<1.6)||(t>2.5&&t<3.1);return <Base chapter="04 / VIDEO LIÊN QUAN">
<Art file="cta" style={{scale:mix(t,0,.4,1.12,1),rotate:`${mix(t,0,.4,-3,0)}deg`}}/><Tag top={340} large at={.2}>TECH<br/>UNMASKED</Tag><Tag top={620} at={.5}>ĐO DUNG LƯỢNG THẬT</Tag>
<svg width="340" height="350" viewBox="0 0 340 350" style={{position:'absolute',left:300,top:1030,scale:mix(t,.6,.9,0,1)*(pulse?1.08:1),translate:`0 ${pulse?12:0}px`,filter:`drop-shadow(0 0 ${pulse?35:12}px ${C.cyan}88)`}}><path d="M112 10 L228 5 L229 197 L329 190 L172 337 L10 196 L114 200 Z" fill={C.cyan} stroke={C.cream} strokeWidth="3"/></svg><Tag top={1425} at={.9}>VIDEO LIÊN QUAN ↓</Tag>
</Base>};
