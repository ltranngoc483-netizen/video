import React from 'react';import {useCurrentFrame,useVideoConfig} from 'remotion';import {Art,Base,Title,Tag,Fine,stepped,mix,C} from './RecorderVisuals';
export const EnergyMath=()=>{const f=useCurrentFrame();const {fps}=useVideoConfig();const t=stepped(f,fps);const heat=t>=6.44;const shot=t<2.56?0:t<4.48?1:heat?3:2;return <Base chapter="03 / BÀI TOÁN VẬT LÝ">
<Art file="physics" style={{scale:shot===0?1.18:shot===1?1.13:shot===2?1.05:1.2,translate:shot===0?'90px 70px':shot===1?'-50px 10px':shot===3?'-80px 160px':'0 0'}}/>
<Title>{heat?<>PIN KÉM<br/>GẶP NÓNG?</>:<>NẾU DUNG<br/>LƯỢNG ĐÚNG…</>}</Title>
<div style={{position:'absolute',left:78,right:180,top:445,background:C.cream,color:C.navy,padding:'24px',fontFamily:'Display',fontSize:53,lineHeight:1.22,boxShadow:'9px 16px 12px #0007',rotate:'-1deg',opacity:heat?0:mix(t,.2,.5,0,1)}}>50.000mAh = 50Ah<br/>50Ah × 3,7V = 185Wh</div>
{!heat?<div style={{position:'absolute',left:90,right:180,top:640,fontFamily:'Body',fontSize:28,color:C.cyan,background:'#0A192FEF',padding:'12px 15px'}}>Ở điện áp danh định 3,7V · Không phải năng lượng USB đầu ra.</div>:null}
<svg width="1080" height="1920" style={{position:'absolute',inset:0,filter:'drop-shadow(0 0 6px #00F0FF66)'}}><path d="M240 1110Q390 1150 535 1090" stroke={C.cyan} fill="none" opacity=".25" strokeWidth="5"/><path d="M240 1110Q390 1150 535 1090" stroke={C.cyan} fill="none" opacity=".6" strokeWidth="7" strokeDasharray="8 180" strokeDashoffset={-t*33}/></svg>
{heat?<div style={{position:'absolute',left:625,top:690,width:180,height:180,background:C.red,clipPath:'polygon(50% 0,100% 96%,0 96%)',opacity:.65+.35*Math.sin(t*8)**2,filter:'drop-shadow(10px 15px 10px #000)'}}><div style={{position:'absolute',left:75,top:63,color:C.cream,fontFamily:'Display',fontSize:92}}>!</div></div>:null}
<Tag top={1390} key={shot} at={[.2,2.56,4.48,6.44][shot]} red={heat}>{['50Ah Ở ĐIỆN ÁP 3,7V','185Wh — NẾU NHÃN ĐÚNG','TẤM SOLAR NHỎ · SẠC CHẬM','NGUY CƠ QUÁ NHIỆT'][shot]}</Tag>
<Fine top={1555}>{heat?'Cảnh báo nguy cơ, không khẳng định pin sẽ cháy hoặc nổ.':'Khối pin và dòng sáng là minh họa; chưa đo công suất tấm solar của sản phẩm cụ thể.'}</Fine>
</Base>};
