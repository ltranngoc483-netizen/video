import React from 'react';import {CanvasImage,staticFile} from 'remotion';
export const ReconstructionProps=()=> <>
<CanvasImage src={staticFile('cell.png')} style={{position:'absolute',left:265,top:820,width:160,height:350,objectFit:'contain',rotate:'52deg',filter:'drop-shadow(12px 17px 8px #0008)'}}/>
<CanvasImage src={staticFile('cell.png')} style={{position:'absolute',left:415,top:750,width:160,height:350,objectFit:'contain',rotate:'52deg',filter:'drop-shadow(12px 17px 8px #0008)'}}/>
<CanvasImage src={staticFile('ballast.png')} style={{position:'absolute',left:540,top:860,width:430,height:360,objectFit:'contain',rotate:'-10deg',filter:'drop-shadow(12px 18px 9px #0007)'}}/>
<div style={{position:'absolute',left:250,top:1185,width:235,height:100,rotate:'-22deg',background:'#30745B',border:'7px solid #AAC0A1',boxShadow:'10px 14px 8px #0007'}}><div style={{position:'absolute',left:70,top:20,width:70,height:55,background:'#172A2B',border:'6px solid #8B9F9A'}}/><div style={{position:'absolute',left:12,top:20,width:30,height:25,background:'#C3AC72'}}/><div style={{position:'absolute',right:8,top:30,width:38,height:40,background:'#A7BCC1'}}/><CanvasImage src={staticFile('grain.png')} style={{width:'100%',height:'100%',opacity:.2,mixBlendMode:'multiply'}}/></div>
</>;
