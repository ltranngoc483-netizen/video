import React from 'react';import {CanvasImage,staticFile,useCurrentFrame,useVideoConfig} from 'remotion';import {Art,Base,Title,Tag,Fine,stepped,mix,C} from './RecorderVisuals';import {ReconstructionProps} from './ReconstructionProps';
export const BallastReconstruction=()=>{const f=useCurrentFrame();const {fps}=useVideoConfig();const t=stepped(f,fps);const shot=t<1.306667?0:t<2.026667?1:t<3.506667?2:t<5.706667?3:4;return <Base chapter="02 / TÁI DỰNG THỦ THUẬT">
<div style={{position:'absolute',inset:0,scale:shot===0?1+t*.025:shot===1?1.3:shot===2?1.18:shot===3?1.1:1.25,translate:shot===1?'-130px -40px':shot===2?'-80px -10px':shot===4?'90px -70px':'0 0'}}><Art file="teardown"/><ReconstructionProps/></div>
<Title>NẶNG CHƯA CHẮC<br/>NHIỀU PIN</Title>
<CanvasImage src={staticFile('cell.png')} style={{position:'absolute',left:150,top:860,width:210,height:410,objectFit:'contain',opacity:shot===3?mix(t,3.506667,3.756667,0,1):0,translate:`0 ${-16+Math.sin(t*2.6)*18}px`,rotate:`${-10+Math.sin(t*2)*5}deg`,filter:'drop-shadow(15px 20px 12px #0008)'}}/>
{shot===1?Array.from({length:18},(_,i)=>{const p=(t*1.4+i*.071)%1;return <div key={i} style={{position:'absolute',left:650+Math.sin(i*2.7)*85+p*40,top:930+p*350,width:9+i%5,height:7+i%4,background:['#D0B68C','#BEA37D','#E0CDA7'][i%3],rotate:`${i*29+p*90}deg`,boxShadow:'3px 5px 3px #0007',opacity:1-p*.4}}/>}):null}
<Tag top={1385} key={shot} at={[.1,1.306667,2.026667,3.506667,5.706667][shot]}>{['MỞ VỎ MINH HỌA','CÁT / VẬT LIỆU ĐỘN','THANH SẮT: TÁI DỰNG','CELL PIN BÊN TRONG','CẦN KIỂM TRA VÀ ĐO THẬT'][shot]}</Tag>
<Fine top={1545}>Tái dựng thủ thuật, không phải bằng chứng chiếc sạc 99K cụ thể có cát hoặc sắt.</Fine>
</Base>};
