import React from 'react';import {Composition,Still,Freeze} from 'remotion';import {Video} from './Video';import {SolarOffer} from './SolarOffer';import {BallastReconstruction} from './BallastReconstruction';import {EnergyMath} from './EnergyMath';import {SolarFunnel} from './SolarFunnel';
const Asset01=()=> <Freeze frame={70}><SolarOffer/></Freeze>;
const Asset02=()=> <Freeze frame={160}><BallastReconstruction/></Freeze>;
const Asset03=()=> <Freeze frame={140}><EnergyMath/></Freeze>;
const Asset04=()=> <Freeze frame={110}><SolarFunnel/></Freeze>;
export const Root=()=> <>
<Composition id="Solar99KVoice" component={Video} width={1080} height={1920} fps={30} durationInFrames={724}/>
<Composition id="SolarOffer" component={SolarOffer} width={1080} height={1920} fps={30} durationInFrames={130}/>
<Composition id="BallastReconstruction" component={BallastReconstruction} width={1080} height={1920} fps={30} durationInFrames={206}/>
<Composition id="EnergyMath" component={EnergyMath} width={1080} height={1920} fps={30} durationInFrames={264}/>
<Composition id="SolarFunnel" component={SolarFunnel} width={1080} height={1920} fps={30} durationInFrames={124}/>
<Still id="Scene01" component={Asset01} width={1080} height={1920}/>
<Still id="Scene02" component={Asset02} width={1080} height={1920}/>
<Still id="Scene03" component={Asset03} width={1080} height={1920}/>
<Still id="Scene04" component={Asset04} width={1080} height={1920}/>
</>;
