# TECH UNMASKED — Solar power bank99K
## Style
Photographed handcrafted tactile cardboard. Thick torn navy #0A192F, cream #F2ECDD paper, cyan #00F0FF circuit/solar light, beige masking tape, brass pins and deep macro shadows. Red #E55441 only for advertising questions and conditional heat risk. No flat dashboards or generic stock footage.
## Type
DejaVu Display Bold77px headings,37–65px paper labels,27px fine notes; Body/Mono local files with Vietnamese support. Right180px and bottom330px reserved for Shorts controls. Use mAh, V and Wh with correct case and voltage qualification.
## Motion
15pose/sec transforms,14 review/shot beats. Fast macro camera changes, independent floating paper cell and grains, weak abstract energy pulses, conditional heat indicator and two arrow pulses, consistent torn-page wipes. CTA25–30s.
## Do not
Do not imply this particular99K item was opened or contains sand. Persistent reconstruction labels. No numerical real measured capacity, solar wattage, guaranteed charge time or inevitable explosion.185Wh applies only if50,000mAh is true at3.7V nominal, not guaranteed USB output energy. No depicted real-cell puncturing, fire or dangerous practical teardown steps.
