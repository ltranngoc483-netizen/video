from pathlib import Path
import json,math,subprocess
r=Path(__file__).resolve().parents[1]
# Actual supplied MP3 ASR onsets. Numerals/units corrected from the known
# script; 50.000mAh/3,7V/185Wh are readable equivalents of spoken quantities.
phrases=[
('Chín mươi chín nghìn…',[0,.28,.52,.76],1.1),
('mà được 50.000mAh,',[1.2,1.44,1.64],3.1),
('kèm pin mặt trời?',[3.2,3.44,3.72,3.96],4.23),
('Một số pin giả từng bị nhét cát,',[4.32,4.56,4.8,5.04,5.24,5.44,5.64,5.88],6.24),
('thanh sắt để tăng trọng lượng.',[6.36,6.56,6.8,7,7.24,7.48],7.72),
('Pin thật bên trong thì ít hơn quảng cáo.',[7.84,8.08,8.28,8.48,8.68,8.88,9.12,9.36,9.6],9.92),
('Mở vỏ mới biết!',[10.04,10.32,10.6,10.84],11.11),
('50.000mAh ở 3,7V…',[11.2,12.48,12.64],13.6),
('là 185Wh!',[13.76,13.96],15.55),
('Tấm solar bé xíu sạc rất chậm.',[15.68,15.96,16.36,16.56,16.8,17.04,17.28],17.53),
('Pin kém chất lượng gặp nóng…',[17.64,17.92,18.16,18.36,18.56,18.8],19.06),
('càng nguy hiểm.',[19.16,19.44,19.72],19.93),
('Muốn thấy cách đo dung lượng thật?',[20,20.28,20.48,20.72,20.96,21.16,21.4],21.64),
('Xem Video liên quan…',[21.76,21.96,22.56,22.8],23.05),
('ngay bên dưới.',[23.16,23.44,23.76],24.08),
]
caps=[]
for text,times,end in phrases:
 words=text.split();assert len(words)==len(times),text
 caps.append(dict(text=text,startMs=round(times[0]*1000),endMs=round(end*1000),words=[dict(text=w,startMs=round(t*1000)) for w,t in zip(words,times)]))
(r/'src/captions.json').write_text(json.dumps(caps,ensure_ascii=False,indent=2))
duration=float(subprocess.check_output(['ffprobe','-v','error','-show_entries','format=duration','-of','default=nw=1:nk=1',str(r/'public/narration.mp3')]))
(r/'src/timing.json').write_text(json.dumps(dict(sourceDuration=duration,deliveryFrames=math.ceil(duration*30),sceneFrames=[0,130,336,600,math.ceil(duration*30)],hookCuts=[1.2,3.2],teardownCuts=[1.306667,2.026667,3.506667,5.706667],physicsCuts=[2.56,4.48,6.44]),indent=2))
def tc(ms):return f'{ms//3600000:02}:{ms//60000%60:02}:{ms//1000%60:02},{ms%1000:03}'
(r/'out/solar-99k-phu-de-1108.srt').write_text('\n\n'.join(f'{i+1}\n{tc(c["startMs"])} --> {tc(c["endMs"])}\n{c["text"]}' for i,c in enumerate(caps))+'\n',encoding='utf-8-sig')
print('15 MP3-aligned cues;source',duration,'seconds;delivery',math.ceil(duration*30),'frames')
