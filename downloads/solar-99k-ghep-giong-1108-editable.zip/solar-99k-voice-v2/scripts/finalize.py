from pathlib import Path
import subprocess
r=Path(__file__).resolve().parents[1]
subprocess.run(['ffmpeg','-y','-v','error','-filter_complex_threads','1','-i',str(r/'out/solar-99k-native.mp4'),'-i',str(r/'public/narration.mp3'),'-i',str(r/'public/sound-design.wav'),'-filter_complex','[1:a]aresample=48000[vo];[2:a]volume=0.12[sfx];[vo][sfx]amix=inputs=2:duration=longest:normalize=0,alimiter=limit=0.95:level=0:latency=1,apad[a]','-map','0:v:0','-map','[a]','-c:v','copy','-c:a','aac','-b:a','192k','-t','24.133333','-movflags','+faststart',str(r/'out/solar-99k-hoan-chinh-1108.mp4')],check=True)
print('Complete solar MP4 with supplied1108.MP3;724frames,original voice tempo/pitch')
