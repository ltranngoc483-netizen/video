from pathlib import Path
import json,soundfile as sf,sherpa_onnx
r=Path(__file__).resolve().parents[1];m=Path('/workspace/video/.models/asr/sherpa-onnx-zipformer-vi-30M-int8-2026-02-09')
rec=sherpa_onnx.OfflineRecognizer.from_transducer(encoder=str(m/'encoder.int8.onnx'),decoder=str(m/'decoder.onnx'),joiner=str(m/'joiner.int8.onnx'),tokens=str(m/'tokens.txt'),num_threads=3,modeling_unit='bpe',bpe_vocab=str(m/'bpe.model'))
x,sr=sf.read(r/'out/voice-16k.wav',dtype='float32');results=[]
for start in range(0,round(len(x)/sr),20):
 stream=rec.create_stream();stream.accept_waveform(sr,x[start*sr:min(len(x),(start+20)*sr)]);rec.decode_stream(stream);a=stream.result;results.append(dict(start=start,text=a.text,tokens=a.tokens,timestamps=a.timestamps));print(start,a.text,flush=True)
(r/'out/transcript.json').write_text(json.dumps(results,ensure_ascii=False,indent=2))
