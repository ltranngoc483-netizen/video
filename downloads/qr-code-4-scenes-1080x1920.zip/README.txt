THE INVISIBLE WORLD — QR
Four new 1080 x 1920 PNG assets. Scenes 01/02/03 are illustrative photographic papercraft artwork. Scene 04 is the complete branded CTA. Place at 0–5 / 5–15 / 15–25 / 25–30 seconds.
The MP4 adds independent object motion, captions and narration; these PNGs are still artwork for CapCut.
QR patterns are illustrative, not production scannable codes. Attach an actual matching Related Video before publishing.
