# THE UNSOLVED ARCHIVE — Kuchisake-onna

## Style Prompt
Tactile photographic papercraft horror. Thick torn cream corrugated cardboard, layered navy paper silhouettes, old real beige tape, slightly rusted metal pins, stark sidelight and deep practical miniature shadows. A cyan supernatural mouth is only a luminous paper seam: no blood, exposed tissue or realistic injury. A masked adult paper woman, a fictional samurai origin scroll and an illustrated 1979 rumor/patrol scene. Independent walking silhouettes, mask movement, unfolding scroll, paper stamp, flipping facsimile pages, escorted group silhouettes, closing scissors and final folded arrow. Stop-motion transforms sampled at 15 steps/second inside 30 fps delivery.

## Colors
#0A192F navy cardboard; #00F0FF supernatural cyan; #F2ECDD cream paper; #82745D aged tape/pins. No gore red.

## Typography
Display/DejaVu Sans Bold 64–94px headings, Body/DejaVu Sans 28–34px labels. Full subtitles, if narration is selected, 48px. Main text safe x80–900, y120–1530; avoid overlap with captions and logo. Reserve 25–30 for CTA.

## What NOT to Do
No flat SVG scenes in place of textured physical miniatures. No realistic facial wounds, blood or threatened/attacked children. No fabricated historical crime evidence, authentic-looking quotations or newspaper headlines. Archival pages are visibly labelled illustrated facsimiles. Samurai story is UNVERIFIED LEGEND. 1979 rumors/patrols are the history topic; no claim a ghost exists. No universal survival rule: SOME VERSIONS SAY must accompany DON'T ANSWER DIRECTLY. No unsupported exact victim, crime, street location, date or publisher branding.
