import React from 'react';import {Composition,Still,AbsoluteFill} from 'remotion';import {Video} from './Video';import {Encounter} from './Encounter';import {Origin} from './Origin';import {Panic} from './Panic';import {Funnel} from './Funnel';import {Photo} from './Visuals';
const Thumbnail=()=> <AbsoluteFill><Photo file="thumbnail"/></AbsoluteFill>;
export const Root=()=> <>
<Composition id="KuchisakeShort" component={Video} width={1080} height={1920} fps={30} durationInFrames={900}/>
<Composition id="Encounter" component={Encounter} width={1080} height={1920} fps={30} durationInFrames={150}/>
<Composition id="Origin" component={Origin} width={1080} height={1920} fps={30} durationInFrames={300}/>
<Composition id="Panic" component={Panic} width={1080} height={1920} fps={30} durationInFrames={300}/>
<Composition id="Funnel" component={Funnel} width={1080} height={1920} fps={30} durationInFrames={150}/>
<Still id="Scene01Asset" component={Encounter} width={1080} height={1920} defaultProps={{still:true}}/>
<Still id="Scene02Asset" component={Origin} width={1080} height={1920} defaultProps={{still:true}}/>
<Still id="Scene03Asset" component={Panic} width={1080} height={1920} defaultProps={{still:true}}/>
<Still id="Scene04Asset" component={Funnel} width={1080} height={1920} defaultProps={{still:true}}/>
<Still id="Thumbnail" component={Thumbnail} width={1080} height={1920}/>
</>;
