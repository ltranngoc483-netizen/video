import {delayRender,continueRender,cancelRender,staticFile} from 'remotion';
if(typeof document!=='undefined'){const h=delayRender('Phông tiếng Việt');Promise.all([new FontFace('Body',`url(${staticFile('Body.ttf')})`).load(),new FontFace('Display',`url(${staticFile('Display.ttf')})`,{weight:'700'}).load()]).then(fs=>{fs.forEach(f=>document.fonts.add(f));continueRender(h)}).catch(cancelRender)}
