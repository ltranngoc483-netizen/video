import React from 'react';import {AbsoluteFill,staticFile,useVideoConfig} from 'remotion';import {Audio} from '@remotion/media';import {TransitionSeries} from '@remotion/transitions';import {Encounter} from './Encounter';import {Origin} from './Origin';import {Panic} from './Panic';import {Funnel} from './Funnel';import {PaperTransition} from './Visuals';
export const Video=()=>{const {fps}=useVideoConfig();return <AbsoluteFill><TransitionSeries>
<TransitionSeries.Sequence name="01 The encounter" durationInFrames={5*fps} premountFor={fps}><Encounter/><Audio src={staticFile('hook.wav')} premountFor={fps}/></TransitionSeries.Sequence>
<TransitionSeries.Overlay durationInFrames={8} premountFor={fps}><PaperTransition/></TransitionSeries.Overlay>
<TransitionSeries.Sequence name="02 Unverified origin" durationInFrames={10*fps} premountFor={fps}><Origin/><Audio src={staticFile('origin.wav')} premountFor={fps}/></TransitionSeries.Sequence>
<TransitionSeries.Overlay durationInFrames={8} premountFor={fps}><PaperTransition/></TransitionSeries.Overlay>
<TransitionSeries.Sequence name="03 The 1979 rumor panic" durationInFrames={10*fps} premountFor={fps}><Panic/><Audio src={staticFile('panic.wav')} premountFor={fps}/></TransitionSeries.Sequence>
<TransitionSeries.Overlay durationInFrames={8} premountFor={fps}><PaperTransition/></TransitionSeries.Overlay>
<TransitionSeries.Sequence name="04 Versions and related video" durationInFrames={5*fps} premountFor={fps}><Funnel/><Audio src={staticFile('cta.wav')} premountFor={fps}/></TransitionSeries.Sequence>
</TransitionSeries><Audio src={staticFile('sound-design.wav')} volume={.25} premountFor={fps}/></AbsoluteFill>};
