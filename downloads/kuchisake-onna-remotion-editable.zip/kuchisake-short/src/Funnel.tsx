import React from 'react';import {AbsoluteFill,useCurrentFrame,useVideoConfig} from 'remotion';import {SceneBase,Photo,Captions,C,mix} from './Visuals';
export const Funnel=({still=false}:{still?:boolean})=>{const f=useCurrentFrame();const {fps}=useVideoConfig();const t=still?4:Math.floor(f/2)*2/fps;return <AbsoluteFill style={{color:C.cream,fontFamily:'Body'}}><SceneBase><div style={{position:'absolute',inset:0,transform:`perspective(1500px) rotateX(${mix(t,0,.4,24,0)}deg)`,transformOrigin:'50% 85%'}}><Photo file="cover"/></div></SceneBase>
<div style={{position:'absolute',left:100,right:180,top:205,color:C.cyan,fontFamily:'Display',fontSize:28,opacity:mix(t,.1,.3,0,1)}}>IN SOME VERSIONS:</div>
<div style={{position:'absolute',left:100,right:180,top:265,fontFamily:'Display',fontSize:54,lineHeight:1.08,opacity:mix(t,.1,.35,0,1)}}>{t>=1.35?"DON'T ANSWER DIRECTLY.":'THE RULE?'}</div>
{!still&&<Captions start={25} cta/>}
<div style={{position:'absolute',left:100,right:180,top:665,fontFamily:'Display',fontSize:83,lineHeight:1.03,textShadow:'7px 8px 0 #0008',translate:`0 ${mix(t,.1,.5,40,0)}px`,opacity:mix(t,.1,.4,0,1)}}>THE INVISIBLE WORLD</div>
<div style={{position:'absolute',left:100,right:180,top:890,fontSize:30,opacity:mix(t,.2,.5,0,1)}}>Understand What You Never See.</div>
<div style={{position:'absolute',left:100,right:180,top:1010,padding:'20px 15px',background:C.cyan,color:C.navy,fontFamily:'Display',fontSize:31,textAlign:'center',boxShadow:'8px 12px 0 #0006',opacity:mix(t,.15,.45,0,1)}}>WATCH THE FULL INVESTIGATION</div>
<svg width="1080" height="1920" style={{position:'absolute',inset:0,opacity:mix(t,.2,.5,0,1),translate:`0 ${Math.round(Math.sin(t*5)*7)}px`}}><path d="M 440 1150 L 590 1150 L 590 1270 L 685 1270 L 515 1400 L 345 1270 L 440 1270 Z" fill="#A68F6D" transform="translate(9 13)"/><path d="M 440 1150 L 590 1150 L 590 1270 L 685 1270 L 515 1400 L 345 1270 L 440 1270 Z" fill={C.cyan} stroke={C.cream} strokeWidth="6"/></svg>
<div style={{position:'absolute',left:100,right:180,top:1450,color:C.cyan,fontFamily:'Display',fontSize:34,textAlign:'center',opacity:mix(t,.2,.5,0,1)}}>RELATED VIDEO ↓</div>
</AbsoluteFill>};
