from pathlib import Path
import json,subprocess
import numpy as np
import soundfile as sf
r=Path(__file__).resolve().parents[1];sr=48000;n=30*sr;rng=np.random.default_rng(1979);vo=np.zeros(n);sfx=np.zeros(n)
for s in json.loads((r/'scripts/narration.json').read_text()):
 x,rate=sf.read(r/'public'/f'{s["id"]}.wav');assert rate==sr;i=round(s['start']*sr);k=min(len(x),n-i);vo[i:i+k]+=x[:k]
def add(at,x):
 i=round(at*sr);k=min(len(x),n-i)
 if k>0:sfx[i:i+k]+=x[:k]
def thud(at,amp=.35,d=.7):
 t=np.arange(round(d*sr))/sr;add(at,amp*np.sin(2*np.pi*(52*t-8*t*t))*np.exp(-t*6))
def click(at,amp=.23,freq=1200):
 t=np.arange(round(.085*sr))/sr;add(at,amp*(.55*rng.normal(size=len(t))+.45*np.sin(2*np.pi*freq*t))*np.exp(-t*70))
def paper(at,d=.25,amp=.18):
 t=np.arange(round(d*sr))/sr;x=rng.normal(size=len(t));x-=np.convolve(x,np.ones(24)/24,mode='same');add(at,amp*x*np.sin(np.pi*t/d)**2*np.exp(-t*5))
t=np.arange(n)/sr;bed=(.013*np.sin(2*np.pi*43*t)+.008*np.sin(2*np.pi*57.8*t)+.003*np.sin(2*np.pi*120*t))*(.65+.35*np.sin(2*np.pi*.23*t)**2);bed*=np.minimum(1,t/.6)*np.minimum(1,(30-t)/.65);sfx+=bed
for at in [.22,.74,1.27,1.82,2.4]:paper(at,.15,.13);thud(at,.08,.18)
for at in [4.94,5.18,6.23,8.04,10.4,14.94,16.55,18.86,19.4,20.1,24.94]:paper(at,.25,.2)
thud(3.09,.28);thud(5.18,.22);thud(10.4,.4);thud(15,.3)
for at in [15.1,15.3,15.52,15.75,16.0,16.22]:click(at,.14,1500)
tone=np.arange(round(1.1*sr))/sr;add(8.25,.07*(np.sin(2*np.pi*1800*tone)+.35*np.sin(2*np.pi*2500*tone))*np.exp(-tone*5))
add(21.2,.09*(np.sin(2*np.pi*880*tone)+.4*np.sin(2*np.pi*1320*tone))*np.exp(-tone*4))
for at in [21,21.45,21.9,22.4,22.85,23.3,23.8,24.2]:paper(at,.12,.07)
click(24.7,.32,700);thud(25,.4);paper(25.18,.3,.23);thud(26.6,.2,.4);thud(28.8,.24,.6);thud(29.5,.22,.5)
sf.write(r/'public/narration.wav',vo,sr);sf.write(r/'public/sound-design.wav',sfx,sr)
sf.write(r/'out/mix-raw.wav',vo+.25*sfx,sr,subtype='FLOAT')
subprocess.run(['ffmpeg','-y','-v','error','-i',str(r/'out/mix-raw.wav'),'-af','alimiter=limit=0.95:level=0:latency=1','-ar','48000',str(r/'out/final-audio.wav')],check=True)
caps=json.loads((r/'src/captions.json').read_text())
for c in caps:
 if c['text']=='Japan, nineteen seventy-nine.':c['text']='Japan, 1979.'
(r/'src/captions.json').write_text(json.dumps(caps,indent=2))
def tc(ms):
 ms=round(ms);return f'{ms//3600000:02}:{ms//60000%60:02}:{ms//1000%60:02},{ms%1000:03}'
(r/'out/kuchisake-onna-en.srt').write_text('\n\n'.join(f'{i+1}\n{tc(c["startMs"])} --> {tc(c["endMs"])}\n{c["text"]}' for i,c in enumerate(caps))+'\n')
print('Narration, original horror SFX/ambient bed, and 14-cue SRT ready')
