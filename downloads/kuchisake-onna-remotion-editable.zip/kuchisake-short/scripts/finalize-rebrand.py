from pathlib import Path
import subprocess,hashlib
r=Path(__file__).resolve().parents[1]
old=r/'out/kuchisake-onna-30s-draft.mp4';new=r/'out/kuchisake-onna-unsolved-archive-30s.mp4'
subprocess.run(['ffmpeg','-y','-v','warning','-i',str(r/'out/kuchisake-unsolved-native.mp4'),'-i',str(old),'-map','0:v:0','-map','1:a:0','-c','copy','-t','30','-movflags','+faststart',str(new)],check=True)
def audio_digest(p):
 b=subprocess.check_output(['ffmpeg','-v','error','-i',str(p),'-map','0:a:0','-c:a','copy','-f','adts','pipe:1'])
 return hashlib.sha256(b).hexdigest()
assert audio_digest(old)==audio_digest(new)
print('The Unsolved Archive MP4 ready; AAC audio packets unchanged')
