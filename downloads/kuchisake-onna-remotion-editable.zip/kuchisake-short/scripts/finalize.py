from pathlib import Path
import subprocess
r=Path(__file__).resolve().parents[1]
subprocess.run(['ffmpeg','-y','-v','warning','-i',str(r/'out/kuchisake-native.mp4'),'-i',str(r/'out/final-audio.wav'),'-map','0:v:0','-map','1:a:0','-c:v','copy','-c:a','aac','-b:a','192k','-t','30','-movflags','+faststart',str(r/'out/kuchisake-onna-30s-draft.mp4')],check=True)
print('Complete 30-second folklore MP4 ready')
