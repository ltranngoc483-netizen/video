"""Generate phrase-aligned narration using the Kokoro backend used by HyperFrames.
Run with ../.tts-venv/bin/python scripts/voice.py after downloading the official
Kokoro v1.0 ONNX model and voices to ../.models/. No API key is required.
"""
from pathlib import Path
import os
os.environ.setdefault('OMP_NUM_THREADS', '4')
import json, subprocess
import numpy as np
import soundfile as sf
import onnxruntime as ort
from kokoro_onnx import Kokoro

root=Path(__file__).resolve().parents[1]
data=json.loads((root/'scripts/narration.json').read_text())
options=ort.SessionOptions()
options.intra_op_num_threads=4
session=ort.InferenceSession(str(root.parent/'.models/kokoro.onnx'), sess_options=options,providers=['CPUExecutionProvider'])
engine=Kokoro.from_session(session, str(root.parent/'.models/voices.bin'))
sr=24000
all_captions=[]
for scene in data:
    chunks=[]
    lengths=[]
    for phrase in scene['phrases']:
        samples, rate=engine.create(phrase,voice='am_michael',speed=1.05,lang='en-us')
        # Keep the spoken phrase and a tiny breath. Remove long model padding.
        active=np.flatnonzero(np.abs(samples)>.006)
        if len(active): samples=samples[max(0,active[0]-500):min(len(samples),active[-1]+1200)]
        samples=np.concatenate([samples,np.zeros(int(.10*sr))])
        lengths.append(len(samples)/sr)
        chunks.append(samples)
    source=np.concatenate(chunks)
    # Leave the last second completely silent for the final question.
    available=scene['duration']-.15
    speed=max(.9,(len(source)/sr)/available)
    raw=root/'public'/f'{scene["id"]}-raw.wav'
    out=root/'public'/f'{scene["id"]}.wav'
    sf.write(raw,source,sr)
    subprocess.run(['ffmpeg','-y','-loglevel','error','-i',str(raw),'-af',f'atempo={speed:.8f},loudnorm=I=-17:TP=-2:LRA=7','-ar','48000',str(out)],check=True)
    cursor=scene['start']+.10
    for phrase, length in zip(scene['phrases'],lengths):
        duration=length/speed
        all_captions.append({'text':phrase,'startMs':round(cursor*1000),'endMs':round((cursor+duration)*1000),'timestampMs':round(cursor*1000),'confidence':None})
        cursor+=duration
    print(scene['id'], 'source',round(len(source)/sr,2),'seconds','tempo',round(speed,3),flush=True)
    raw.unlink()
(root/'src/captions.json').write_text(json.dumps(all_captions,indent=2))
print('Phrase-aligned captions saved.',flush=True)
